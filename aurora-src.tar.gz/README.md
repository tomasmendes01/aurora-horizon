# Aurora

**To play, you only need `aurora.hshader`:** put it in `%APPDATA%\horizon\shaderpacks` and pick it in the game. It is WGSL shaders plus a manifest that Horizon runs on the GPU; nothing else is installed. Everything else here (Python scripts, glslang, naga) is only for rebuilding the pack from the original GLSL and for testing it against the original.

A personal port of **Complementary Reimagined r5.9.3** (EminGT, https://www.complementary.dev) with
**Euphoria Patches 1.10.5** (SpacEagle17, https://www.euphoriapatches.com) to Horizon's native shader
API 0.1. Private, for personal use: the Complementary License 1.7 does not allow redistributing it in
this form (see LICENSE.txt). Not affiliated with or endorsed by EminGT or SpacEagle17.

## What's here

| Path | What it is |
| --- | --- |
| `aurora.hshader` | The built pack (drop into `%APPDATA%\horizon\shaderpacks`). |
| `aurora-src.tar.gz` | The whole source tree below, with its folders (the web upload flattens folders). |
| `source/shaders` | Complementary + Euphoria, patched by the Euphoria Patcher, with the port's own edits (marked `HZ_PORT` / "Horizon port"). |
| `crport/` | The translator: GLSL (preprocessed with Iris's defines) → SPIR-V (glslang) → WGSL (naga), then the Horizon adapters and generators. |
| `crport/adapter/` | WGSL emulating Iris for the post passes and the material stage (depth, shadow maps, shadowcolor1, colortex6/4, HDR scale). |
| `opts/` | The settings: which Complementary options become Horizon `[[options]]` (WGSL `override`s), their ranges, and the full build script. |
| `harness/` | The equivalence tests: the original GLSL run on OpenGL (moderngl) against the port's WGSL on wgpu, pass by pass. |
| `tools/hzcheck.py` | A local copy of Horizon's pack check (limits, expression counts). |

## Building

Needs Python 3, `cpp`, `glslangValidator`, `spirv-opt`, `naga` and a Horizon checkout for `hzcheck`.

```sh
opts/full_build.sh                     # translations of the three dimensions, merged terrain, pk_all/
python3 crport/tools/package.py pk_all aurora.hshader
```

## Port-only changes (not in the original)

- Settings are runtime `override`s (Horizon compiles a pack once): Profile (light shafts, FXAA, cloud
  quality), Shadow Distance, Lens Flare (on by default), Aurora Condition, Emissive Brightness, Portal Glow.
- Light-emitting blocks keep their HDR brightness through Horizon's 0..1 picture (scale stored in the surface data).
- Enderman eyes glow (Horizon draws entities itself); chorus plant light spots glow.
- Underwater light shafts' water noise computed in the post passes (Horizon's shadow pass has none).
- Light shafts averaged over two dithers from High up (no TAA).
- Nether biome colours recovered from the fog colour (Horizon gives no biome).
- Nether storm 0.36 and Nether/End border fog 0.90 (10% less than the original).
