// Complementary Reimagined r5.9.3 by EminGT (Complementary License 1.7), translated to Horizon's
// native shader API for personal use. Not to be redistributed.
//
// Iris's uniforms and textures, as Complementary reads them, from Horizon's frame. Iris draws with
// OpenGL's conventions: view space looks down -z, the projection maps depth to -1..1, and screen
// coordinates start at the bottom left. Horizon's projection reverses depth and its screen starts
// at the top left, so `hz_projection` is the GL projection with the same field of view, and screen
// reads flip y.

const hz_near: f32 = 0.05;

// The GL projection of this frame (Minecraft's near plane, Horizon's far plane).
fn hz_projection() -> mat4x4<f32> {
    let n = hz_near;
    let f = frame.far;
    let p = frame.projection;
    return mat4x4<f32>(
        vec4<f32>(p[0].x, 0.0, 0.0, 0.0),
        vec4<f32>(0.0, p[1].y, 0.0, 0.0),
        vec4<f32>(p[2].x, p[2].y, -(f + n) / (f - n), -1.0),
        vec4<f32>(0.0, 0.0, -2.0 * f * n / (f - n), 0.0));
}

fn hz_projection_inverse() -> mat4x4<f32> {
    let n = hz_near;
    let f = frame.far;
    let p = frame.projection;
    let c = -(f + n) / (f - n);
    let d = -2.0 * f * n / (f - n);
    return mat4x4<f32>(
        vec4<f32>(1.0 / p[0].x, 0.0, 0.0, 0.0),
        vec4<f32>(0.0, 1.0 / p[1].y, 0.0, 0.0),
        vec4<f32>(0.0, 0.0, 0.0, 1.0 / d),
        vec4<f32>(p[2].x / p[0].x, p[2].y / p[1].y, -1.0, c / d));
}

// Iris's shadow camera: looking from the sun (the moon by night) at the camera, orthographic over
// Horizon's shadow distance. Complementary's own shadow lookups use Horizon's map instead
// (`shadow_position`); these serve the code that only needs the light's axes.
fn hz_shadow_model_view() -> mat4x4<f32> {
    let z = normalize(frame.light_direction);
    let up = select(vec3<f32>(0.0, 1.0, 0.0), vec3<f32>(1.0, 0.0, 0.0), abs(z.y) > 0.99);
    let x = normalize(cross(up, z));
    let y = cross(z, x);
    return mat4x4<f32>(
        vec4<f32>(x.x, y.x, z.x, 0.0),
        vec4<f32>(x.y, y.y, z.y, 0.0),
        vec4<f32>(x.z, y.z, z.z, 0.0),
        vec4<f32>(0.0, 0.0, -256.0, 1.0));
}

fn hz_shadow_projection() -> mat4x4<f32> {
    let s = 1.0 / max(frame.shadow_distance, 1.0);
    return mat4x4<f32>(
        vec4<f32>(s, 0.0, 0.0, 0.0),
        vec4<f32>(0.0, s, 0.0, 0.0),
        vec4<f32>(0.0, 0.0, -2.0 / 512.0, 0.0),
        vec4<f32>(0.0, 0.0, -1.0, 1.0));
}

// Iris's shadowcolor0 at a shadow-map coordinate: Horizon's colour of the translucent terrain the
// light passes through.
fn hz_shadow_color(uv: vec2<f32>) -> vec4<f32> {
    let size = vec2<f32>(textureDimensions(shadow_color));
    return textureLoad(shadow_color, vec2<i32>(clamp(uv, vec2<f32>(0.0), vec2<f32>(0.9999)) * size), 0);
}

// Iris's shadow depth (Complementary's GetShadowPos: the ortho over ShadowMatrices.NEAR..FAR =
// -100.05..156 blocks around the camera, z * 0.2, then * 0.5 + 0.5) from Horizon's and back: the
// same scale a block, and the camera at the same depth, so Complementary's depth offsets and
// absolute thresholds (composite1.glsl's `salsSample < 0.55`) mean what they mean in Iris.
const hz_iris_shadow_depth_per_block: f32 = 2.0 / 256.05 * 0.2 * 0.5;
const hz_iris_shadow_camera_depth: f32 = 0.5 + 0.5 * 0.2 * (-(156.0 - 100.05) / (156.0 + 100.05));
fn hz_shadow_z_scale() -> f32 {
    let m = frame.shadow_view_proj;
    return length(vec3<f32>(m[0].z, m[1].z, m[2].z)) / hz_iris_shadow_depth_per_block;
}
fn hz_shadow_z_to_iris(z: f32) -> f32 {
    // nothing there: both maps are cleared to their far end
    if z >= 1.0 { return 1.0; }
    return (z - frame.shadow_view_proj[3].z) / hz_shadow_z_scale() + hz_iris_shadow_camera_depth;
}
fn hz_shadow_z_from_iris(z: f32) -> f32 {
    return (z - hz_iris_shadow_camera_depth) * hz_shadow_z_scale() + frame.shadow_view_proj[3].z;
}

// Iris's sunAngle: vanilla's celestial angle (its cosine ease of the day's time, as the sun moves)
// + 0.25, wrapped; frame.day_time is the day's time without the ease.
fn hz_sun_angle() -> f32 {
    let d = fract(frame.day_time - 0.25);
    let e = 0.5 - cos(d * 3.14159265358979) / 2.0;
    return fract((d * 2.0 + e) / 3.0 + 0.25);
}

// A 4x4 inverse (cofactors).
fn hz_inverse(m: mat4x4<f32>) -> mat4x4<f32> {
    let a00 = m[0][0]; let a01 = m[0][1]; let a02 = m[0][2]; let a03 = m[0][3];
    let a10 = m[1][0]; let a11 = m[1][1]; let a12 = m[1][2]; let a13 = m[1][3];
    let a20 = m[2][0]; let a21 = m[2][1]; let a22 = m[2][2]; let a23 = m[2][3];
    let a30 = m[3][0]; let a31 = m[3][1]; let a32 = m[3][2]; let a33 = m[3][3];
    let b00 = a00 * a11 - a01 * a10; let b01 = a00 * a12 - a02 * a10; let b02 = a00 * a13 - a03 * a10;
    let b03 = a01 * a12 - a02 * a11; let b04 = a01 * a13 - a03 * a11; let b05 = a02 * a13 - a03 * a12;
    let b06 = a20 * a31 - a21 * a30; let b07 = a20 * a32 - a22 * a30; let b08 = a20 * a33 - a23 * a30;
    let b09 = a21 * a32 - a22 * a31; let b10 = a21 * a33 - a23 * a31; let b11 = a22 * a33 - a23 * a32;
    let det = b00 * b11 - b01 * b10 + b02 * b09 + b03 * b08 - b04 * b07 + b05 * b06;
    let i = 1.0 / det;
    return mat4x4<f32>(
        vec4<f32>(a11 * b11 - a12 * b10 + a13 * b09, a02 * b10 - a01 * b11 - a03 * b09, a31 * b05 - a32 * b04 + a33 * b03, a22 * b04 - a21 * b05 - a23 * b03) * i,
        vec4<f32>(a12 * b08 - a10 * b11 - a13 * b07, a00 * b11 - a02 * b08 + a03 * b07, a32 * b02 - a30 * b05 - a33 * b01, a20 * b05 - a22 * b02 + a23 * b01) * i,
        vec4<f32>(a10 * b10 - a11 * b08 + a13 * b06, a01 * b08 - a00 * b10 - a03 * b06, a30 * b04 - a31 * b02 + a33 * b00, a21 * b02 - a20 * b04 - a23 * b00) * i,
        vec4<f32>(a11 * b07 - a10 * b09 - a12 * b06, a00 * b09 - a01 * b07 + a02 * b06, a31 * b01 - a30 * b03 - a32 * b00, a20 * b03 - a21 * b01 + a22 * b00) * i);
}


// Euphoria's in<Biome> uniforms come from the biome, which Horizon does not pass. In the Nether every
// biome has its own vanilla fog colour (and the fog colour blends across biome borders like the
// smoothed uniforms do), so the weights are recovered from the distance to those colours.
fn hz_nether_biome(i: i32) -> f32 {
    if frame.dimension != -1i { return 0.0; }
    let f = frame.fog_color;
    var c = array<vec3<f32>, 5>(
        vec3<f32>(51.0, 8.0, 8.0) / 255.0,    // nether_wastes
        vec3<f32>(51.0, 3.0, 3.0) / 255.0,    // crimson_forest
        vec3<f32>(26.0, 5.0, 26.0) / 255.0,   // warped_forest
        vec3<f32>(104.0, 95.0, 112.0) / 255.0, // basalt_deltas
        vec3<f32>(27.0, 71.0, 69.0) / 255.0); // soul_sand_valley
    var w = array<f32, 5>(0.0, 0.0, 0.0, 0.0, 0.0);
    var s = 0.0;
    for (var k = 0; k < 5; k++) {
        let d = f - c[k];
        w[k] = exp(-dot(d, d) * 2000.0);
        s += w[k];
    }
    return w[i] / max(s, 1e-6) * min(s, 1.0);
}
