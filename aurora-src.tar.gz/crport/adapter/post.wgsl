// Iris's buffers in a post pass, from Horizon's (Complementary's colortex formats are emulated
// where the pass writes them: hz_fmt_*).

// GL's texel (from the bottom left) → Horizon's (from the top left), clamped like a texelFetch.
fn hz_flip_texel(t: vec2<i32>, size: vec2<i32>) -> vec2<i32> {
    return clamp(vec2<i32>(t.x, size.y - 1 - t.y), vec2<i32>(0), size - 1);
}
fn hz_flip_uv(uv: vec2<f32>) -> vec2<f32> {
    return vec2<f32>(uv.x, 1.0 - uv.y);
}

// Out of range, GL's texelFetch reads 0 (llvmpipe and NVIDIA's drivers both; WGSL's textureLoad
// may clamp instead).
fn hz_outside(t: vec2<i32>, size: vec2<i32>) -> bool {
    return any(t < vec2<i32>(0)) || any(t >= size);
}

// The world's depth as GL's depthtex: 0..1, 1 at the far plane and the sky.
fn hz_gl_depth_texel(t: vec2<i32>) -> f32 {
    let size = vec2<i32>(textureDimensions(scene_depth));
    if hz_outside(t, size) { return 0.0; }
    let h = hz_flip_texel(t, size);
    let d = textureLoad(scene_depth, h, 0);
    if d <= 0.0 { return 1.0; }
    let uv = (vec2<f32>(h) + 0.5) / vec2<f32>(size);
    let v = frame.projection_inverse * vec4<f32>(uv.x * 2.0 - 1.0, 1.0 - uv.y * 2.0, d, 1.0);
    let c = hz_projection() * vec4<f32>(v.xyz / v.w, 1.0);
    return c.z / c.w * 0.5 + 0.5;
}
// A texture2D read of depthtex: the nearest texel (Iris's depth buffers filter nearest), clamped
// to the edge like any sampled read.
fn hz_gl_depth_uv(uv: vec2<f32>) -> f32 {
    let size = vec2<i32>(textureDimensions(scene_depth));
    return hz_gl_depth_texel(clamp(vec2<i32>(floor(uv * vec2<f32>(size))), vec2<i32>(0), size - 1));
}

// colortex6 (gbuffers_terrain.glsl:375): smoothnessD, materialMask, skyLightFactor, from the material
// stage's set_surface (8 bits each, as RGB8). Cleared (0) where no solid terrain shows.
fn hz_colortex6_texel(t: vec2<i32>) -> vec4<f32> {
    let size = vec2<i32>(textureDimensions(scene_depth));
    if hz_outside(t, size) { return vec4<f32>(0.0); }
    let s = surface_at(hz_flip_texel(t, size));
    if !s.present { return vec4<f32>(0.0, 0.0, 0.0, 1.0); }
    let a = floor(s.data / 256.0);
    let b = s.data - a * 256.0;
    let smoothness = s.smoothness - 2.0 * floor(s.smoothness / 2.0);  // without the HDR scale (gen_material.py)
    return vec4<f32>(floor(clamp(smoothness, 0.0, 1.0) * 255.0 + 0.5) / 255.0, a / 255.0, b / 255.0, 1.0);
}
// The material stage's HDR scale at a texel of the picture (top-left rows): 1 where it stored none.
fn hz_hdr_scale(t: vec2<i32>) -> f32 {
    let s = surface_at(t);
    if !s.present { return 1.0; }
    return 1.0 + (max(floor(s.smoothness / 2.0) / 8.0, 1.0) - 1.0) * HZ_EMISSIVE_BRIGHTNESS;
}
// colortex4 (gbuffers_terrain.glsl:379): the world normal, as RGBA8_SNORM.
fn hz_colortex4_texel(t: vec2<i32>) -> vec4<f32> {
    let size = vec2<i32>(textureDimensions(scene_depth));
    if hz_outside(t, size) { return vec4<f32>(0.0); }
    let s = surface_at(hz_flip_texel(t, size));
    if !s.present { return vec4<f32>(0.0); }
    return hz_fmt_snorm8(vec4<f32>(s.normal, 1.0));
}

fn hz_fmt_unorm8(v: vec4<f32>) -> vec4<f32> {
    return floor(clamp(v, vec4<f32>(0.0), vec4<f32>(1.0)) * 255.0 + 0.5) / 255.0;
}
fn hz_fmt_snorm8(v: vec4<f32>) -> vec4<f32> {
    return round(clamp(v, vec4<f32>(-1.0), vec4<f32>(1.0)) * 127.0) / 127.0;
}
// R11F_G11F_B10F: no sign, no alpha (reads 1).
fn hz_fmt_r11g11b10(v: vec4<f32>) -> vec4<f32> {
    return vec4<f32>(max(v.rgb, vec3<f32>(0.0)), 1.0);
}

fn hz_shadow_pos_iris(player_pos: vec3<f32>) -> vec3<f32> {
    let p = shadow_position(player_pos);
    return vec3<f32>(p.xy, hz_shadow_z_to_iris(p.z));
}

// shadowcolor1 (shadow.glsl:83-104, 214-224), which Horizon's shadow pass doesn't write, from what
// it does: shadow_color holds color1 before DoNaturalShadowCalculation (texture times vertex colour;
// alpha 1 on water), so the light shaft colour follows from it; water's waterNoise (the underwater
// light shafts) is computed here at the water's place, found from the translucent map's depth. The
// alpha is the scene-aware light shafts' height, 0.25 + max0(positionYM * 0.05), positionYM the
// water surface's camera-relative height + 3.5 (0 for the rest).
fn hz_shadowcolor1_texel(t: vec2<i32>) -> vec4<f32> {
    let size = vec2<i32>(textureDimensions(shadow_color));
    let tc = clamp(t, vec2<i32>(0), size - 1);
    let c = textureLoad(shadow_color, tc, 0);
    let translucent = textureLoad(shadow_map_translucent, tc, 0) < textureLoad(shadow_map, tc, 0);
    var color1 = c;
    var color2 = c * 0.25;
    var positionYM = 0.0;
    if translucent {
        if c.a >= 1.0 {
            // water (shadow.glsl:106-175, WATERCOLOR_MODE >= 2)
            // the underwater light shafts' noise (shadow.glsl:170-182): position is the water's
            // camera-relative place, syncedTimeDynamic Euphoria's (worldAgeSmooth + 5 days) * 0.05
            let position = hz_shadow_texel_position(tc, textureLoad(shadow_map_translucent, tc, 0));
            let worldPos = position + frame.camera_position;
            let waterWind = vec2<f32>((frame.day_time * 24000.0 + 120000.0) * 0.05 * 0.01, 0.0);
            var waterNoise = textureSampleLevel(noisetex, noisetex_sampler, worldPos.xz * 0.012 - waterWind, 0.0).g;
            waterNoise += textureSampleLevel(noisetex, noisetex_sampler, worldPos.xz * 0.05 + waterWind, 0.0).g;
            let factor = max(2.5 - 0.025 * length(position.xz), 0.8333) * 1.3;
            waterNoise = pow(waterNoise * 0.5, factor) * factor * 1.3;
            color2 = vec4<f32>(normalize(sqrt(clamp(c.rgb, vec3<f32>(0.0), vec3<f32>(1.0)))) * vec3<f32>(0.24, 0.22, 0.26)
                * waterNoise * (1.0 + hz_unnamed_sunVisibility() - frame.rain), c.a);
            positionYM = position.y + 3.5;
        } else {
            // DoNaturalShadowCalculation (shadow.glsl:35-42); glColor is already in c
            color1 = vec4<f32>(mix(vec3<f32>(1.0), c.rgb, pow(c.a, (1.0 - c.a) * 0.5) * 1.05) * 0.1, c.a);
            color2 = vec4<f32>(normalize(color1.rgb) * 0.5, color2.a);
        }
    }
    color2.a = 0.25 + max(positionYM * 0.05, 0.0);
    return hz_fmt_unorm8(color2);
}
fn hz_shadow_texel_position(t: vec2<i32>, depth: f32) -> vec3<f32> {
    let size = vec2<f32>(textureDimensions(shadow_map));
    let uv = (vec2<f32>(t) + 0.5) / size;
    // undo shadow_distort: d = xy / (|xy| k + 1 - k)  →  xy = d (1 - k) / (1 - |d| k)
    let d = vec2<f32>(uv.x * 2.0 - 1.0, 1.0 - uv.y * 2.0);
    let k = frame.shadow_distortion;
    let xy = d * (1.0 - k) / (1.0 - length(d) * k);
    let p = hz_inverse(frame.shadow_view_proj) * vec4<f32>(xy, depth, 1.0);
    return p.xyz / p.w;
}
// A level of colortex0's mipmaps (Iris generates them for composite4, colortex0MipmapEnabled):
// the `tb` target holds levels 2 to 8 side by side in its top left (the mip passes),
// each GL's box average; sampled bilinearly inside its level, clamped to its edges.
fn hz_mip_origin(level: i32) -> vec2<i32> {
    let size = vec2<i32>(frame.resolution);
    var x = 0;
    for (var l = 2; l < level; l++) { x += max(size.x >> u32(l), 1); }
    return vec2<i32>(x, 0);
}
fn hz_mip_size(level: i32) -> vec2<i32> {
    let size = vec2<i32>(frame.resolution);
    return max(vec2<i32>(size.x >> u32(level), size.y >> u32(level)), vec2<i32>(1));
}
fn hz_mip_texel(level: i32, t: vec2<i32>) -> vec4<f32> {
    let s = hz_mip_size(level);
    return textureLoad(tb, hz_mip_origin(level) + clamp(t, vec2<i32>(0), s - 1), 0);
}
fn hz_mip_bilinear(level: i32, gl_uv: vec2<f32>) -> vec4<f32> {
    let s = vec2<f32>(hz_mip_size(level));
    let p = hz_flip_uv(gl_uv) * s - 0.5;
    let f = fract(p);
    let i = vec2<i32>(floor(p));
    return mix(mix(hz_mip_texel(level, i), hz_mip_texel(level, i + vec2<i32>(1, 0)), f.x),
               mix(hz_mip_texel(level, i + vec2<i32>(0, 1)), hz_mip_texel(level, i + vec2<i32>(1, 1)), f.x), f.y);
}
fn hz_mip_sample(lod: f32, gl_uv: vec2<f32>) -> vec4<f32> {
    // GL_LINEAR_MIPMAP_LINEAR between the two levels around lod (levels 2..8 are kept)
    let l = clamp(lod, 2.0, 8.0);
    let l0 = i32(floor(l));
    let l1 = min(l0 + 1, 8);
    return mix(hz_mip_bilinear(l0, gl_uv), hz_mip_bilinear(l1, gl_uv), l - f32(l0));
}
