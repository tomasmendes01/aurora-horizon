#!/bin/sh
# usage: build.sh outdir [lite]   (HZ_WORK: the translated programs, make_all.sh's work dir)
set -e
C=$(cd $(dirname "$0") && pwd); T=$C/tools
W=${HZ_WORK:-$C}
mkdir -p "$1"
python3 $T/load_cse.py $W/merged.wgsl "$1/.merged.wgsl"
python3 $T/gen_material.py "$1/.merged.wgsl" "$1"
rm -f "$1/.merged.wgsl"
python3 $T/compact.py "$1/material.wgsl" "$1/material.wgsl"
python3 $T/load_cse.py ${HZ_SKY:-$W/sky/sky.wgsl} "$1/sky.wgsl"
HZ_POST_DIR=$W/post python3 $T/gen_post.py "$1" $2
python3 $T/assemble.py "$1" ${HZ_SRC:-$C/../cr_src/shaders} $2
rm -f "$1/post.toml"
