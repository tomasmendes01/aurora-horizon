#version 460
layout(location=0) out vec4 cr_out0;
layout(location=1) out vec4 cr_out1;
layout(location=2) out vec4 cr_out2;
layout(location=3) out vec4 cr_out3;
struct cr_FogParameters { vec4 color; float density; float start; float end; float scale; };
uniform cr_FogParameters cr_Fog;
#define gl_Fog cr_Fog
