#!/bin/bash
# Translates every program of a Complementary source tree and builds the Horizon pack.
# usage: make_all.sh <shaders dir> <work dir> <pack dir> [lite]
set -e
C=$(cd $(dirname $0) && pwd); T=$C/tools; S=$(cd $1 && pwd); W=$2; mkdir -p $W/post $W/sky
DIM=${HZ_DIM:-world0}
pp() { python3 $T/pp.py $S $DIM/$1; }
ppm() { HZ_OPTS=${HZ_OPTS_MAT:-$HZ_OPTS} python3 $T/pp.py $S $DIM/$1; }
# terrain, water, waving
ppm gbuffers_terrain.fsh > $W/terrain.fsh.glsl; $T/build_stage.sh $W/terrain.fsh.glsl frag $W/w_t.wgsl
ppm gbuffers_water.fsh > $W/water.fsh.glsl; $T/build_stage.sh $W/water.fsh.glsl frag $W/w_w.wgsl
ppm gbuffers_terrain.vsh > $W/terrain.vsh.glsl; python3 $T/vertex_wrap.py $W/terrain.vsh.glsl > $W/vwrap.glsl
$T/build_stage.sh $W/vwrap.glsl vert $W/w_v.wgsl
for x in t w v; do python3 $T/wgsl_slim.py $W/w_$x.wgsl $W/slim_$x.wgsl >/dev/null; python3 $T/hzify.py $W/slim_$x.wgsl ${x}_ $W/hz_$x.wgsl; done
python3 $T/dedupe.py $W/merged.wgsl t_:$W/hz_t.wgsl w_:$W/hz_w.wgsl v_:$W/hz_v.wgsl
# sky
pp gbuffers_skybasic.vsh > $W/sky/v.glsl; pp gbuffers_skybasic.fsh > $W/sky/f.glsl
python3 $C/sky/make_sky_glsl.py $W/sky/v.glsl $W/sky/f.glsl $W/sky/sky.glsl
$T/build_stage.sh $W/sky/sky.glsl frag $W/sky/w.wgsl; python3 $T/wgsl_slim.py $W/sky/w.wgsl $W/sky/s.wgsl >/dev/null
python3 $T/hzify.py $W/sky/s.wgsl s_ $W/sky/hz.wgsl; python3 $T/gen_sky.py $W/sky/hz.wgsl $W/sky/full.wgsl
python3 $T/compact.py $W/sky/full.wgsl $W/sky/sky.wgsl >/dev/null
# post
for p in deferred1 composite composite1 composite4 composite5 composite7 final; do
  pp $p.vsh > $W/post/$p.vsh.glsl; pp $p.fsh > $W/post/$p.fsh.glsl
  python3 $T/merge_vsh.py $W/post/$p.vsh.glsl $W/post/$p.fsh.glsl $W/post/$p.glsl
done
export HZ_POST_DIR=$W/post
if [ "$4" = litest ]; then SPECS=("deferred1 0 d1" "deferred1 1 d5" "composite1 0 c1" "composite5 0 c5" "final 0 fin"); elif [ -n "$4" ]; then SPECS=("deferred1 0 d1" "deferred1 1 d5" "composite1 0 c1" "composite4 0 c4" "composite5 0 c5" "final 0 fin"); else SPECS=("composite1 1 c1v" "deferred1 0 d1" "deferred1 1 d5" "deferred1 2 d4" "composite 0 c7" "composite1 0 c1" "composite4 0 c4" "composite5 0 c5" "composite7 0 c7f" "final 0 fin"); fi
for spec in "${SPECS[@]}"; do
  set -- $spec; $T/post_build.sh $1 $2 $3
done
