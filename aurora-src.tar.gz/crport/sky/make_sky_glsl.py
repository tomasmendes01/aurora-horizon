"""gbuffers_skybasic as one fragment program: the vertex shader's per-draw values (upVec and sunVec,
gbuffers_skybasic.glsl:205-206, the same expressions) are computed at the top of main, since Horizon's
sky stage has no vertex shader of its own. usage: make_sky_glsl.py vsh.glsl fsh.glsl out.glsl"""
import re, sys
vsh, fsh = open(sys.argv[1]).read(), open(sys.argv[2]).read()
up = re.search(r'^\s*upVec = .*;$', vsh, re.M).group(0).strip()
sun = re.search(r'^\s*sunVec = .*;$', vsh, re.M).group(0).strip()
assert fsh.count('flat in vec3 upVec, sunVec;') == 1
fsh = fsh.replace('flat in vec3 upVec, sunVec;', 'vec3 upVec, sunVec;')
i = fsh.index('void main() {') + len('void main() {')
fsh = fsh[:i] + f'\n    // gbuffers_skybasic.glsl:205-206 (vertex shader)\n    {up}\n    {sun}\n    // (fragment shader)\n' + fsh[i:]
import os; sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../tools'))
from defer_globals import defer
fsh, n = defer(fsh, '    // (fragment shader)', '    // gbuffers_skybasic.glsl:205-206 (vertex shader)')
open(sys.argv[3], 'w').write(fsh)
