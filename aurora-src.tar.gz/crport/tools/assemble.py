"""Splits each stage's generated WGSL into files under 256 KiB, and writes horizon-shaders.toml with
Complementary's block IDs as [[materials]] and its noise texture.
usage: assemble.py pack_dir cr_shaders_dir [lite]"""
import re, sys, os, shutil, hashlib, json
pack, src = sys.argv[1], sys.argv[2]
lite = len(sys.argv) > 3
litest = lite and sys.argv[3] == 'litest'
LIMIT = 250 * 1024

def items_of(text):
    # Top-level items start at brace depth 0 with a declaration; comments just above join it.
    items, depth, cur = [], 0, []
    for line in text.split('\n'):
        decl = re.match(r'(fn|struct|const|override|alias|var)\b', line)
        if depth == 0 and (decl or line.startswith('//')) and cur and not (decl and cur[-1].startswith('//')) \
                and not (line.startswith('//') and cur[-1].startswith('//')):
            items.append('\n'.join(cur)); cur = []
        cur.append(line)
        depth += line.count('{') - line.count('}')
    items.append('\n'.join(cur))
    return [i for i in items if i.strip()]

def item_name(it):
    for line in it.split('\n'):
        if line.startswith('//') or not line.strip(): continue
        m = re.match(r'(?:fn|struct|const|override|alias|var(?:<\w+>)?)\s+(\w+)', line)
        return m.group(1) if m else None

def pack_files(items, base):
    parts, cur = [], ''
    for it in items:
        if len(cur) + len(it) + 1 > LIMIT and cur:
            parts.append(cur); cur = ''
        cur += it + '\n'
    parts.append(cur)
    names = []
    for i, p in enumerate(parts):
        n = f'{base}{i}.wgsl' if len(parts) > 1 else f'{base}.wgsl'
        assert len(p.encode()) <= 256 * 1024, n
        open(f'{pack}/{n}', 'w').write(p); names.append(n)
    return names

# The vertex stage is also checked on its own (only its files), and its files join the material's
# module: what the vertex function needs goes in the vertex stage's files, the rest in the material's.
text = open(f'{pack}/material.wgsl').read()
vtext = open(f'{pack}/vertex.wgsl').read()
os.remove(f'{pack}/material.wgsl'); os.remove(f'{pack}/vertex.wgsl')
items = items_of(text)
byname = {item_name(i): i for i in items}
need, todo = set(), ['vertex_fn']
byname['vertex_fn'] = vtext
while todo:
    n = todo.pop()
    for w in set(re.findall(r'(?<![.\w])\w+\b', byname[n])):
        if w in byname and w not in need and w != n:
            need.add(w); todo.append(w)
vitems = [i for i in items if item_name(i) in need]
mitems = [i for i in items if item_name(i) not in need]
vfiles = pack_files(vitems, 'common')
open(f'{pack}/vertex.wgsl', 'w').write(vtext)
mnames = pack_files(mitems, 'material')
mfiles, mfile = mnames[:-1], mnames[-1]
materials = []
# block.properties has #if MC_VERSION branches (Iris preprocesses it): keep the lines Iris keeps for
# the version pp.py defines (12111).
def block_lines(path, mc_version=12111):
    """block.properties as Iris reads it: its preprocessor run with Iris's macros (MC_VERSION, no
    block tags: Horizon doesn't read `%tag`s, so IRIS_TAG_SUPPORT stays 0 and the explicit lists
    are what count)."""
    import subprocess
    keep = []
    for line in open(path, errors='replace'):
        t = line.lstrip()
        if t.startswith('#'):
            if re.match(r'#\s*(if|ifdef|ifndef|elif|else|endif|define|undef)\b', t):
                keep.append(line)
            else:
                keep.append('\n')
        else:
            keep.append(line)
    r = subprocess.run(['cpp', '-P', '-undef', '-nostdinc', '-x', 'c', '-w', f'-DMC_VERSION={mc_version}',
                        '-DIRIS_TAG_SUPPORT=0', '-DIS_IRIS', '-'], input=''.join(keep), capture_output=True, text=True)
    if r.returncode: raise SystemExit(r.stderr)
    return r.stdout.splitlines()
for line in block_lines(f'{src}/block.properties'):
    m = re.match(r'^block\.(\d+)\s*=\s*(.*)$', line.strip())
    if m and m.group(2).strip():
        # undefined tag macros (tags_*) and %tags: Horizon reads neither
        # undefined tag macros (tags_*), %tags (Horizon reads neither) and other mods' blocks
        # (namespace:name, Horizon is vanilla): the manifest must stay under 1 MiB
        def vanilla(b):
            if b.startswith(('tags_', '%')): return False
            parts = b.split(':')
            return len(parts) == 1 or '=' in parts[1] or parts[0] == 'minecraft'
        blocks = [b for b in m.group(2).split() if vanilla(b)]
        if not blocks: continue
        materials.append(f'[[materials]]\nid = {m.group(1)}\nblocks = [' + ', '.join(f'"{b}"' for b in blocks) + ']\n')

os.makedirs(f'{pack}/textures', exist_ok=True)
shutil.copyfile(f'{src}/lib/textures/noise.png', f'{pack}/textures/noise.png')
a = hashlib.sha256(open(f'{src}/lib/textures/noise.png', 'rb').read()).hexdigest()
b = hashlib.sha256(open(f'{pack}/textures/noise.png', 'rb').read()).hexdigest()
assert a == b
import glob
uses_cw = any('cloudwater' in open(f).read() for f in glob.glob(f'{pack}/post/*.wgsl'))
if uses_cw:
    shutil.copyfile(f'{src}/lib/textures/cloud-water.png', f'{pack}/textures/cloud-water.png')

SHADOW = f'''[shadow]
resolution = {1024 if lite else 2048}
distance = {64.0 if lite else 192.0}
{'distance_option = "SHADOW_DISTANCE"' if os.environ.get('HZ_OPTS') else ''}

'''
name = 'Aurora' + (' (litest)' if litest else ' (lite)' if lite else '')
toml = f'''schema = 1
id = "aurora{'_litest' if litest else '_lite' if lite else ''}"
name = "{name}"
version = "5.9.3"
api = "0.1"
description = "A personal, unpublished port of EminGT's Complementary Reimagined r5.9.3 with SpacEagle17's Euphoria Patches 1.10.5 to Horizon's native shaders."
authors = ["EminGT (Complementary Reimagined)", "SpacEagle17 (Euphoria Patches)", "iLoong (Horizon port)"]
license = "Complementary License 1.7; Euphoria Patches: MPL-2.0"
{{SHARED}}

[sky]
file = "sky.wgsl"
clouds = {'false' if os.path.exists(pack + '/post') else 'true'}
sun = true
stars = false

[material]
files = {json.dumps(mfiles)}
file = "{mfile}"
fog = false

[vertex]
files = {json.dumps(vfiles)}
file = "vertex.wgsl"

{'' if litest else SHADOW}[[textures]]
id = "noisetex"
file = "textures/noise.png"
filter = "linear"
wrap = "repeat"

''' + (f'''[[textures]]
id = "cloudwater"
file = "textures/cloud-water.png"
filter = "linear"
wrap = "repeat"

''' if uses_cw else '') + (open(f'{pack}/post.toml').read() + '\n' if os.path.exists(f'{pack}/post.toml') else '') + '\n'.join(materials)
if os.environ.get('HZ_OPTS'):
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import options_toml
    toml = toml.replace('{SHARED}', 'shared = ["options.wgsl"]') + '\n' + options_toml.build(pack, src, os.environ['HZ_OPTS'])
else:
    toml = toml.replace('{SHARED}', '')
open(f'{pack}/horizon-shaders.toml', 'w').write(toml)
print('material files', mfiles + [mfile], 'materials', len(materials), 'noise sha256', a)
