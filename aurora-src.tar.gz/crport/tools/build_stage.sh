#!/bin/bash
# GLSL (preprocessed) → SPIR-V (glslang) → WGSL (naga), keeping functions apart.
# usage: build_stage.sh in.glsl stage(frag|vert) out.wgsl
set -e
T=$(mktemp -d)
python3 "$(dirname $0)/specialize.py" < "$1" | python3 "$(dirname $0)/split_samplers.py" | python3 "$(dirname $0)/glsl_fix.py" > $T/s.glsl
if [ "$2" = frag ]; then cat "$(dirname $0)/../compat.glsl" $T/s.glsl > $T/a.glsl; else (echo '#version 460'; cat $T/s.glsl) > $T/a.glsl; fi
glslangValidator -V -R --amb --aml --target-env vulkan1.2 -S $2 -o $T/a.spv $T/a.glsl > $T/log 2>&1 || { grep -v WARNING $T/log; exit 1; }
if [ -n "$HZ_DCE" ]; then spirv-opt --merge-return --inline-entry-points-exhaustive --eliminate-dead-code-aggressive --eliminate-dead-functions $T/a.spv -o $T/b.spv; else spirv-opt --eliminate-dead-functions $T/a.spv -o $T/b.spv; fi
# naga can't read a texture passed to a function: inline everything then.
naga $T/b.spv "$3" 2>$T/naga.log || {
  spirv-opt --merge-return --inline-entry-points-exhaustive --eliminate-dead-functions --eliminate-dead-code-aggressive $T/b.spv -o $T/c.spv
  naga $T/c.spv "$3"
}
