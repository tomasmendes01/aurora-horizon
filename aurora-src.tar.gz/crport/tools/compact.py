"""Shrinks naga's WGSL without changing it: GLSL's mangled overload names (glslang's
`name(f1;vf3;` spelled `name_u0028_f1_u003b_vf3_u003b`) go back to the GLSL name (with the overload's
argument types only where two overloads share it), and indentation goes.
usage: compact.py in out"""
import re, sys, collections
s = open(sys.argv[1]).read()
mangled = sorted(set(re.findall(r'\b(\w+?)_u0028(\w*)', s)))
full = {b + '_u0028' + a for b, a in mangled}
bases = collections.Counter(b for b, a in mangled)
words = set(re.findall(r'\b\w+\b', s))
ren = {}
for b, a in mangled:
    name = b + '_u0028' + a
    if bases[b] == 1 and b not in words:
        new = b
    else:
        args = '_'.join(x for x in a.split('_u003b') if x).replace('__', '_').strip('_')
        new = f'{b}_{args}' if args else b + '_v'
    assert new not in words or new == name, new
    ren[name] = new
s = re.sub(r'\b\w+_u0028\w*', lambda m: ren.get(m.group(0), m.group(0)), s)
s = '\n'.join(l.lstrip() for l in s.split('\n'))
open(sys.argv[2], 'w').write(s)
print(len(ren), 'names;', len(s), 'bytes')
