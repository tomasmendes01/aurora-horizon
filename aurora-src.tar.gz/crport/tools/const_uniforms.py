"""Uniforms Horizon gives no value for (uniforms.py maps them to fixed literals: no held light,
no biome, renderStage NONE...) become constants of that value, so glslang and spirv-opt fold the
code that tests them, exactly as the GPU would compute it with those values. stdin → stdout."""
import re, sys, os
sys.path.insert(0, os.path.dirname(__file__))
from uniforms import MAP
s = sys.stdin.read()
LIT = re.compile(r'^(-?\d+(\.\d+)?)(i|u)?$')
def glsl_value(ty, v):
    m = LIT.match(v.strip())
    if m:
        x = float(m.group(1))
        if ty == 'bool': return 'true' if x != 0 else 'false'
        if ty == 'int': return str(int(x))
        if ty == 'uint': return f'{int(x)}u'
        if ty == 'float': return repr(x)
        return None
    m = re.match(r'^vec(\d)<f32>\(0\.0\)$', v.strip())
    if m and ty == f'vec{m.group(1)}': return f'{ty}(0.0)'
    m = re.match(r'^vec(\d)<i32>\((-?\d+)i\)$', v.strip())
    if m and ty == f'ivec{m.group(1)}': return f'{ty}({m.group(2)})'
    return None
n = 0
def repl(m):
    global n
    ty, names = m.group(1), [x.strip() for x in m.group(2).split(',')]
    keep, consts = [], []
    for name in names:
        key = name if name in MAP else name + '_'
        v = glsl_value(ty, MAP[key]) if key in MAP else None
        if v is None: keep.append(name)
        else: consts.append(f'const {ty} {name} = {v};'); n += 1
    out = (f'uniform {ty} {", ".join(keep)};' if keep else '') + ''.join(consts)
    return out
s = re.sub(r'^uniform\s+(bool|int|uint|float|vec[234]|ivec[234])\s+([\w\s,]+);', repl, s, flags=re.M)
sys.stderr.write(f'{n} constant uniforms\n')
sys.stdout.write(s)
