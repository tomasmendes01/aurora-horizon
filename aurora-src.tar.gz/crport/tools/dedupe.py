"""Merges prefixed programs (hzify) into one module, sharing every function that is the same in
two of them and reads none of their globals: the later copies go and their calls go to the first.
usage: dedupe.py out.wgsl prefix:file ..."""
import re, sys
out_path, parts = sys.argv[1], [a.split(':', 1) for a in sys.argv[2:]]
texts = {p: open(f).read() for p, f in parts}
FN = re.compile(r'^fn (\w+)\((.*?)\)( -> [^{]+)? \{\n(.*?)^\}\n', re.S | re.M)
prefixes = [p for p, _ in parts]
def norm(p, text):
    text = re.sub(r'^fn \w+', 'fn F', text)
    # The function's own names (parameters, `var`s, `let`s), numbered in order.
    m = re.match(r'fn F\((.*?)\)', text, re.S)
    own = re.findall(r'(\w+):', m.group(1)) + re.findall(r'\b(?:var|let) (\w+)', text)
    seen = {}
    for n in own:
        seen.setdefault(n, f'L{len(seen)}')
    if seen:
        text = re.sub(r'(?<![\w.])(' + '|'.join(sorted(map(re.escape, seen), key=len, reverse=True)) + r')\b',
                      lambda mm: seen[mm.group(1)], text)
    return re.sub(r'(?<![\w.])' + re.escape(p), '§', text)
# Pure functions: reading no global of their program and calling only pure functions.
globs = {p: set(re.findall(r'^var(?:<\w+>)? (\w+):', t, re.M)) for p, t in texts.items()}
fns = {p: {m.group(1): m.group(0) for m in FN.finditer(t)} for p, t in texts.items()}
pure = {p: set() for p in prefixes}
for p in prefixes:
    changed = True
    while changed:
        changed = False
        for name, body in fns[p].items():
            if name in pure[p] or name.endswith('entry'): continue
            if any(re.search(r'\b' + g + r'\b', body) for g in globs[p]): continue
            calls = set(re.findall(r'\b(' + re.escape(p) + r'\w+)\(', body)) - {name}
            if all(c in pure[p] for c in calls if c in fns[p]):
                pure[p].add(name); changed = True
shared, first = {}, {}
for p in prefixes:
    for name in fns[p]:
        if name not in pure[p]: continue
        key = norm(p, fns[p][name])
        if key in first: shared[name] = first[key]
        else: first[key] = name
merged = []
for p in prefixes:
    t = texts[p]
    t = FN.sub(lambda m: '' if m.group(1) in shared else m.group(0), t)
    if shared:
        t = re.sub(r'\b(' + '|'.join(map(re.escape, shared)) + r')\b', lambda m: shared[m.group(1)], t)
    merged.append(t)
open(out_path, 'w').write('\n'.join(merged))
print(f'shared {len(shared)} functions', file=sys.stderr)
