"""GLSL runs a global's non-constant initializer at the start of main, before main's own code.
Once the vertex shader's body is moved into main (merge_vsh.py, make_sky_glsl.py), globals
initialized from what it sets (SdotU = dot(sunVec, upVec), sunVisibility, lightColor...) must be
initialized after it: this keeps each declaration where it is, without its initializer, and puts
the initializers, in order, where `marker` stands in main."""
import re

TYPES = r'(?:float|int|uint|bool|[bi]?vec[234]|u?vec[234]|mat[234](?:x[234])?)'

def split_top(s, sep):
    out, d, cur = [], 0, ''
    for c in s:
        if c in '([{': d += 1
        if c in ')]}': d -= 1
        if c == sep and d == 0: out.append(cur); cur = ''
        else: cur += c
    out.append(cur)
    return out

def defer(src, marker, before=None):
    """With `before` (the line main starts with), the initializers also run there: the vertex
    shader ran its own copies of them (common.glsl's) before setting its varyings."""
    # top-level statements: text between ';' or '}' at brace depth 0
    out, inits, i, depth, start = [], [], 0, 0, 0
    res = []
    while i < len(src):
        c = src[i]
        if c == '{': depth += 1
        elif c == '}':
            depth -= 1
            if depth == 0: res.append(src[start:i + 1]); start = i + 1
        elif c == ';' and depth == 0:
            res.append(src[start:i + 1]); start = i + 1
        i += 1
    res.append(src[start:])
    for st in res:
        body = st.strip()
        m = re.match(r'(' + TYPES + r')\s+(.*);$', body, re.S)
        if m and '{' not in body and not body.startswith(('const', 'uniform')) and '=' in body:
            ty, decls = m.group(1), split_top(m.group(2), ',')
            names, assigns = [], []
            for d in decls:
                parts = split_top(d, '=')
                if len(parts) == 1:
                    names.append(d.strip()); continue
                lhs, rhs = parts[0].strip(), '='.join(parts[1:]).strip()
                am = re.match(r'(\w+)\s*\[\s*\]$', lhs)
                if am:  # an unsized array: its size from the initializer
                    sm = re.match(r'\w+\s*\[\s*(\d*)\s*\]\s*\((.*)\)$', rhs, re.S)
                    n = sm.group(1) or str(len(split_top(sm.group(2), ',')))
                    lhs = f'{am.group(1)}[{n}]'
                names.append(lhs)
                assigns.append(re.sub(r'\[.*\]', '', lhs) + ' = ' + rhs + ';')
            lead = st[:len(st) - len(st.lstrip())]
            out.append(f'{lead}{ty} {", ".join(names)};')
            inits.extend(assigns)
        else:
            out.append(st)
    text = ''.join(out)
    assert text.count(marker) == 1
    if before:
        assert text.count(before) == 1
        text = text.replace(before, before + '\n    // (global initializers, as the vertex shader runs them)\n    ' + '\n    '.join(inits) + '\n')
    return text.replace(marker, marker + '\n    // (global initializers, after the vertex shader)\n    ' + '\n    '.join(inits) + '\n'), len(inits)
