// Counts a WGSL module's naga expressions over all its functions (Horizon's per-stage limit is
// 20000) and its texture reads; with `--per-fn`, each function's count.
fn main() {
    let args: Vec<String> = std::env::args().collect();
    let path = &args[1];
    let per_fn = args.iter().any(|a| a == "--per-fn");
    let text = std::fs::read_to_string(path).unwrap();
    let module = match naga::front::wgsl::parse_str(&text) {
        Ok(m) => m,
        Err(e) => { eprintln!("{}", e.emit_to_string(&text)); std::process::exit(1) }
    };
    let mut exprs = 0; let mut reads = 0;
    let mut count = |name: &str, f: &naga::Function| {
        exprs += f.expressions.len();
        if per_fn { println!("{} {}", f.expressions.len(), name); }
        for (_, e) in f.expressions.iter() {
            if matches!(e, naga::Expression::ImageSample { .. } | naga::Expression::ImageLoad { .. }) { reads += 1; }
        }
    };
    for (_, f) in module.functions.iter() { count(f.name.as_deref().unwrap_or("?"), f); }
    for ep in &module.entry_points { count(&ep.name, &ep.function); }
    println!("expressions {exprs} texture_reads {reads} functions {}", module.functions.len());
}
