"""Builds the pack's material stage (terrain and water) and vertex stage from the translated
programs: material.wgsl (adapter, uniforms, programs) and vertex.wgsl.
usage: gen_material.py merged.wgsl outdir"""
import re, sys
sys.path.insert(0, __import__('os').path.dirname(__file__))
from uniforms import fill
merged, outdir = open(sys.argv[1]).read(), sys.argv[2]

# Complementary's shadow coordinates (its own distorted map) → Horizon's map.
def replace_body(src, fn_prefix, body):
    m = re.search(r'^fn (' + fn_prefix + r'\w*)\((\w+): vec3<f32>\) -> vec3<f32> \{\n.*?^\}\n', src, re.S | re.M)
    if not m:
        raise SystemExit('no ' + fn_prefix)
    return src[:m.start()] + f'fn {m.group(1)}({m.group(2)}: vec3<f32>) -> vec3<f32> {{\n    return {body.format(m.group(2))};\n}}\n' + src[m.end():]
# shadowSampling.glsl:1-8 GetShadowPos: Horizon's map and distortion (the API fixes both), with z
# in Iris's units (Complementary's depth offsets, mainLighting.glsl:245-253, are in them):
# Iris's shadow ortho spans ShadowMatrices.NEAR..FAR = -100.05..156 blocks, and Complementary
# keeps 0.2 of it (shadowPos.z *= 0.2), then * 0.5 + 0.5: 2 / 256.05 * 0.2 * 0.5 a block.
for p in ('t_', 'w_') if 'GetShadowPos_u0028' in merged else ():
    merged = replace_body(merged, p + 'GetShadowPos_u0028',
        'vec3<f32>(shadow_position({0}).xy, hz_shadow_z_to_iris(shadow_position({0}).z))')
n = 0
def zscale(m):
    global n; n += 1
    return re.sub(r', (_e\d+\.z)$', r', hz_shadow_z_from_iris(\1)', m.group(1)) + ')'
merged = re.sub(r'(textureSampleCompareLevel\(shadow_map\w*, shadow_sampler, _e\d+\.xy, _e\d+\.z)\)', zscale, merged)
assert n in (0, 2), n
# Iris's shadowtex0 holds everything that casts (solid, entities, translucents); Horizon draws the
# entities into shadow_map only ("after the translucent map was copied"), so shadowtex0 is the
# nearer of the two maps: lit where both are.
merged = re.sub(r'textureSampleCompareLevel\(shadow_map_translucent, shadow_sampler, ([^,]+), (hz_shadow_z_from_iris\(\w+\.z\))\)',
    r'min(textureSampleCompareLevel(shadow_map_translucent, shadow_sampler, \1, \2), textureSampleCompareLevel(shadow_map, shadow_sampler, \1, \2))', merged)

def entry_params(prefix):
    m = re.search(r'^fn ' + prefix + r'entry\((.*?)\) -> ', merged, re.M)
    return [a.split(':')[0].strip() for a in m.group(1).split(',')]

# What each varying of the programs is, from MaterialInput.
VARY = {
    'gl_FragCoord': 'frag', 'normal': 'view_normal', 'glColorRaw': 'gl_color', 'glColor': 'gl_color',
    'absMidCoordPos': 'vec2<f32>(0.5)', 'midCoord': 'vec2<f32>(0.5)',
    'signMidCoordPos': 'clamp((input.uv - 0.5) * 2.0, vec2<f32>(-1.0), vec2<f32>(1.0))',
    'texCoord': 'input.uv', 'lmCoord': 'input.light', 'mat': 'i32(input.material)',
    'vertexPos': 'input.position', 'playerPos': 'input.position', 'viewVector': 'view_vector',
    # Iris's at_midBlock (the block's centre from the corner, in 64ths) as Euphoria reads it
    # (gbuffers_terrain.glsl's blockUV = 0.5 - at_midBlock.xyz / 64.0): the point in its block.
    'blockUV': 'block_uv', 'atMidBlock': '(0.5 - block_uv) * 64.0', 'blockLightEmission': '0i',
}
def call(prefix):
    args = []
    for a in entry_params(prefix):
        if a not in VARY:
            raise SystemExit(f'{prefix}: no value for the varying {a}')
        args.append(VARY[a])
    return f'{prefix}entry(' + ', '.join(args) + ')'

# Iris reads Complementary's `tex` (the block atlas) with vanilla's filtering: nearest texels, the
# mip levels blended (GL_NEAREST_MIPMAP_LINEAR); Horizon's block sampler is linear (and
# anisotropic), which blurs texels up close. The programs' reads go through the GL emulation.
merged = re.sub(r'\bblock_texture\(', 'hz_block_texture(', merged)
merged = re.sub(r'\bblock_texture_level\(', 'hz_block_texture_level(', merged)

material = f'''
fn hz_block_texel_level(uv: vec2<f32>, level: f32) -> vec4<f32> {{
    let s = max(block_texture_size() / exp2(level), vec2<f32>(1.0));
    return block_texture_level((floor(uv * s) + 0.5) / s, level);
}}
fn hz_block_texture_level(uv: vec2<f32>, lod: f32) -> vec4<f32> {{
    let l = max(lod, 0.0);
    let l0 = floor(l);
    let a = hz_block_texel_level(uv, l0);
    if l - l0 <= 0.0 {{ return a; }}
    return mix(a, hz_block_texel_level(uv, l0 + 1.0), l - l0);
}}
fn hz_block_texture(uv: vec2<f32>) -> vec4<f32> {{
    return hz_block_texture_level(uv, block_texture_lod());
}}

// Iris's depth and colour reads in the translucent pass (water): Horizon's world before
// translucent terrain, at a GL screen coordinate (from the bottom left), as GL depth.
fn hz_texel(uv: vec2<f32>) -> vec2<i32> {{
    let size = vec2<f32>(textureDimensions(opaque_depth));
    return vec2<i32>(clamp(vec2<f32>(uv.x, 1.0 - uv.y), vec2<f32>(0.0), vec2<f32>(0.9999)) * size);
}}
fn hz_gl_depth(texel: vec2<i32>) -> f32 {{
    let d = textureLoad(opaque_depth, texel, 0);
    if d <= 0.0 {{ return 1.0; }}
    let size = vec2<f32>(textureDimensions(opaque_depth));
    let ndc = vec2<f32>((f32(texel.x) + 0.5) / size.x * 2.0 - 1.0, 1.0 - (f32(texel.y) + 0.5) / size.y * 2.0);
    let v = frame.projection_inverse * vec4<f32>(ndc, d, 1.0);
    let c = hz_projection() * vec4<f32>(v.xyz / v.w, 1.0);
    return c.z / c.w * 0.5 + 0.5;
}}
fn hz_depth_uv(uv: vec2<f32>) -> vec4<f32> {{
    return vec4<f32>(hz_gl_depth(hz_texel(uv)));
}}
fn hz_depth_texel(texel: vec2<i32>) -> vec4<f32> {{
    let size = vec2<i32>(textureDimensions(opaque_depth));
    return vec4<f32>(hz_gl_depth(vec2<i32>(texel.x, size.y - 1 - texel.y)));
}}
fn hz_opaque_uv(uv: vec2<f32>) -> vec4<f32> {{
    return textureLoad(opaque_color, hz_texel(uv), 0);
}}
fn hz_opaque_texel(texel: vec2<i32>) -> vec4<f32> {{
    let size = vec2<i32>(textureDimensions(opaque_color));
    return textureLoad(opaque_color, vec2<i32>(texel.x, size.y - 1 - texel.y), 0);
}}

// Vanilla's directional shade of a face (up 1, down 0.5, north and south 0.8, east and west 0.6),
// which Horizon's vertex colour holds and Iris's doesn't (Complementary sets oldLighting=false).
fn hz_face_shade(n: vec3<f32>) -> f32 {{
    let a = abs(n);
    if a.y > 0.999 {{ return select(0.5, 1.0, n.y > 0.0); }}
    if a.z > 0.999 {{ return 0.8; }}
    if a.x > 0.999 {{ return 0.6; }}
    return 1.0;
}}

// Two 0..1 values in `set_surface`'s data: 8 bits each.
fn hz_pack2(a: f32, b: f32) -> f32 {{
    return floor(clamp(a, 0.0, 1.0) * 255.0 + 0.5) * 256.0 + floor(clamp(b, 0.0, 1.0) * 255.0 + 0.5);
}}


fn material(input: MaterialInput) -> Surface {{
    let view_pos = (frame.view * vec4<f32>(input.position, 1.0)).xyz;
    let clip = hz_projection() * vec4<f32>(view_pos, 1.0);
    let frag = vec4<f32>(input.screen.x * frame.resolution.x, (1.0 - input.screen.y) * frame.resolution.y,
        clip.z / clip.w * 0.5 + 0.5, 1.0 / clip.w);
    let view_normal = normalize((frame.view * vec4<f32>(input.normal, 0.0)).xyz);
    let gl_color = vec4<f32>(input.tint.rgb / hz_face_shade(input.normal), 1.0);
    let t = normalize((frame.view * vec4<f32>(input.tangent.xyz, 0.0)).xyz);
    let b = cross(view_normal, t) * input.tangent.w;
    let view_vector = vec3<f32>(dot(t, view_pos), dot(b, view_pos), dot(view_normal, view_pos));
    let in_block = fract(frame.camera_position) + input.position;
    let block_uv = in_block - floor(in_block - input.normal * 0.5);
    if input.translucent {{
        hz_fill();
        let o = {call('w_')};
        return Surface(o.member);
    }}
    hz_fill();
    let o = {call('t_')};
    // gl_FragData[1]: smoothnessD, materialMask, skyLightFactor; gl_FragData[2]: the world normal.
    // Horizon's picture is 0..1 (API 0.1) and Complementary's colortex0 goes past 1 where a block
    // shines: such a colour is stored divided by its scale (its brightest channel, in steps of 1/8,
    // up to 32) and the scale rides in set_surface's smoothness (+ 2 * scale * 8), which the post
    // passes take back out (hz_hdr_scale).
    let c = o.member;
    let peak = max(max(c.r, c.g), c.b);
    let hdr = select(0.0, min(ceil(peak * 8.0), 255.0), peak > 1.0);
    set_surface(normalize(o.member_2.xyz), o.member_1.x + 2.0 * hdr, hz_pack2(o.member_1.y, o.member_1.z));
    return Surface(vec4<f32>(c.rgb / max(hdr / 8.0, 1.0), c.a));
}}
'''
# One uniform block for the three programs (Iris gives them the same uniforms): the union of
# their fields, filled once a pixel or corner.
from uniforms import fields
union = {}
for p in ('t_', 'w_', 'v_'):
    for name, ty in fields(merged, p):
        ty = re.sub(r'^[tvw]_cr_FogParameters$', 'hz_FogParameters', re.sub(r'^@\w+\(\d+\)\s*', '', ty))
        assert union.setdefault(name, ty) == ty, (name, ty, union[name])
fog = re.search(r'^struct t_cr_FogParameters \{\n.*?^\}\n', merged, re.S | re.M).group(0)
for p in ('t_', 'w_', 'v_'):
    merged = re.sub(r'^struct ' + p + r'gl_DefaultUniformBlock \{\n.*?^\}\n', '', merged, flags=re.S | re.M)
    merged = re.sub(r'^struct ' + p + r'cr_FogParameters \{\n.*?^\}\n', '', merged, flags=re.S | re.M)
    merged = re.sub(r'^var<private> ' + p + r'unnamed: \w+;\n', '', merged, flags=re.M)
merged = re.sub(r'\b[tvw]_cr_FogParameters\b', 'hz_FogParameters', merged)
merged = re.sub(r'\b[tvw]_unnamed\b', 'hz_unnamed', merged)
merged = re.sub(r'\b[tvw]_fill\(\)', 'hz_fill()', merged)
from uniforms import used
union = {n: t for n, t in union.items() if used(merged, 'hz_', n)}
ustruct = fog.replace('t_cr_FogParameters', 'hz_FogParameters') + 'struct hz_gl_DefaultUniformBlock {\n' + \
    ''.join(f'    {n}: {t},\n' for n, t in union.items()) + '}\nvar<private> hz_unnamed: hz_gl_DefaultUniformBlock;\n'
uniform_fill = ustruct + fill(ustruct, 'hz_', usage=merged)
open(outdir + '/material.wgsl', 'w').write(open(__import__('os').path.dirname(__file__) + '/../adapter/iris.wgsl').read()
    + '\n' + uniform_fill + merged + material)

# The vertex stage: Complementary's waving (DoWave) on a corner.
vparams = entry_params('v_')
VV = {'hz_uv': 'input.uv', 'hz_light': 'input.light', 'hz_pos': 'input.position', 'hz_mat': 'i32(input.material)',
      'gl_VertexIndex': '0u', 'gl_InstanceIndex': '0u'}
vcall = 'v_entry(' + ', '.join(VV[a] for a in vparams) + ')'
open(outdir + '/vertex.wgsl', 'w').write(f'''// Complementary's waving plants, leaves and lava (gbuffers_terrain.vsh's DoWave).
fn vertex(input: VertexInput) -> vec3<f32> {{
    hz_fill();
    let o = {vcall};
    return o.member;
}}
''')
