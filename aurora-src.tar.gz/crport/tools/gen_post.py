"""The pack's post passes from the translated deferred1, composite, composite1, composite4,
composite5, composite7 and final (post/hz_<name>.wgsl), plus the passes Horizon needs for what Iris
does by itself (colortex0's mipmaps). Writes <pack>/post/*.wgsl and prints the [[post]] entries.
usage: gen_post.py pack_dir"""
import re, sys, os, json
D = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, D)
from uniforms import fill
from wgsl_items import prune
pack = sys.argv[1]
ADAPTER = open(D + '/../adapter/iris.wgsl').read() + open(D + '/../adapter/post.wgsl').read()

# Where each Iris texture a pass reads comes from. Kinds:
#   ('target', name)  a Horizon post target (or scene_color), as written
#   'depth'           depthtex0/1: the world's depth (Horizon has no depth without translucents)
#   'c6', 'c4'        the material stage's set_surface
#   'noise', 'cloudwater'  the pack's [[textures]]
#   'shadow0', 'shadow1'   shadowtex0/1 (with / without translucents)
#   'shadowcolor1'    emulated from shadow_color
#   'zero'            cleared or never written in Horizon (see the report)
#   'mip'             colortex0 with its mipmaps (composite4)
#   ('vl', name)      colortex5's corner (vlFactor): the equilibrium pass
COMMON = {'depthtex0': 'depth', 'depthtex1': 'depth', 'noisetex': 'noise', 'shadowtex0': 'shadow0',
          'shadowtex1': 'shadow1', 'shadowcolor1': 'shadowcolor1', 'colortex12': 'zero', 'colortex13': 'zero'}
# Horizon lets a pack write 4 targets of its own (by name, each at one scale), plus the chain
# (passes without an output, read by the next as `previous`). Complementary's buffers are given
# out by when each is live:
#   vl (1/4): the light shafts factor            ta: colortex0 after deferred1, then mipmaps 2-4,
#   tb: colortex5, then the mipmap atlas             then the bloom tiles (colortex3)
#   tc: colortex4 (and colortex1, its copy)      chain: composite's colortex7, composite1's
#                                                colortex0, composite5's and composite7's colortex3
PASSES = [
    # name, prefix (post/hz_<prefix>.wgsl), output target (None: the chain), the colortex format, sources
    dict(name='vl', src='c1v', out='vl', scale=0.25, fmt='unorm8',
         reads=dict(COMMON, colortex0=('target', 'scene_color'), colortex1='c4', colortex3='zero',
                    colortex4='c4', colortex5='zero', colortex6='c6', colortex7='zero'),
         label='Light shafts factor (composite1)'),
    dict(name='d1', src='d1', out='ta', fmt='r11g11b10',
         reads=dict(COMMON, colortex0=('target', 'scene_color'), colortex3='cloudwater', colortex4='c4',
                    colortex5=('vl', 'vl'), colortex6='c6'), label='Clouds, sky fog (deferred1)'),
    dict(name='d5', src='d5', out='tb', fmt='unorm8',
         reads=dict(COMMON, colortex0=('target', 'scene_color'), colortex3='cloudwater', colortex4='c4',
                    colortex5=('vl', 'vl'), colortex6='c6'), label='Reflection image (deferred1)'),
    dict(name='d4', src='d4', out='tc', fmt='snorm8',
         reads=dict(COMMON, colortex0=('target', 'scene_color'), colortex3='cloudwater', colortex4='c4',
                    colortex5=('vl', 'vl'), colortex6='c6'), label='Reflection normals (deferred1)'),
    dict(name='c7', src='c7', out=None, fmt='rgba16f',
         reads=dict(COMMON, colortex0=('target', 'ta'), colortex1=('target', 'tc'), colortex4=('target', 'tc'),
                    colortex5=('target', 'tb'), colortex6='c6', colortex7='zero'), label='Reflections (composite)'),
    dict(name='c1', src='c1', out=None, fmt='r11g11b10',
         reads=dict(COMMON, colortex0=('target', 'ta'), colortex1=('target', 'tc'), colortex3='zero',
                    colortex4=('target', 'tc'), colortex5=('target', 'tb'), colortex6='c6', colortex7=('target', 'previous')),
         label='Volumetric light, water fog (composite1)'),
    dict(name='mipa', special='mipa', out='ta', label='colortex0 mipmaps 2-4'),
    dict(name='mipb', special='mipb', out='tb', label='colortex0 mipmaps 5-8'),
    dict(name='c4', src='c4', out='tc', fmt='unorm8', reads=dict(COMMON, colortex0='mip'), label='Bloom tiles (composite4)'),
    dict(name='c5', src='c5', out=None, fmt='unorm8',
         reads=dict(COMMON, colortex0=('target', 'previous'), colortex3=('target', 'tc'), colortex5='zero'), label='Bloom, tonemap (composite5)'),
    dict(name='c7f', src='c7f', out=None, fmt='unorm8',
         reads=dict(COMMON, colortex2='zero', colortex3=('target', 'previous')), label='FXAA (composite7)'),
    dict(name='fin', src='fin', out=None, fmt=None, reads=dict(COMMON, colortex3=('target', 'previous')), label='Final'),
]

# The lite pack (Complementary's own lower settings, see assemble.py): no light shafts, so no vl
# pass; no SSR/block reflections, so neither deferred1's colortex4 nor composite (composite1 doesn't
# read its colortex7); FXAA off, so composite7 only copies colortex3 (left out, the same picture).
LITE_PASSES = [
    dict(name='d1', src='d1', out='ta', fmt='r11g11b10',
         reads=dict(COMMON, colortex0=('target', 'scene_color'), colortex3='cloudwater', colortex4='c4',
                    colortex6='c6'), label='Clouds, sky fog (deferred1)'),
    dict(name='d5', src='d5', out='tb', fmt='unorm8',
         reads=dict(COMMON, colortex0=('target', 'scene_color'), colortex3='cloudwater', colortex4='c4',
                    colortex6='c6'), label='Cloud depth (deferred1)'),
    dict(name='c1', src='c1', out=None, fmt='r11g11b10',
         reads=dict(COMMON, colortex0=('target', 'ta'), colortex3='zero', colortex5=('target', 'tb'), colortex6='c6'),
         label='Fog (composite1)'),
    dict(name='mipa', special='mipa', out='ta', label='colortex0 mipmaps 2-4'),
    dict(name='mipb', special='mipb', out='tb', label='colortex0 mipmaps 5-8'),
    dict(name='c4', src='c4', out='tc', fmt='unorm8', reads=dict(COMMON, colortex0='mip'), label='Bloom tiles (composite4)'),
    dict(name='c5', src='c5', out=None, fmt='unorm8',
         reads=dict(COMMON, colortex0=('target', 'previous'), colortex3=('target', 'tc')), label='Bloom, tonemap (composite5)'),
    dict(name='fin', src='fin', out=None, fmt=None, reads=dict(COMMON, colortex3=('target', 'previous')), label='Final'),
]
# litest: no shadows, clouds or bloom either, so composite4 (its tiles) goes too.
LITEST_PASSES = [p for p in LITE_PASSES if p['name'] in ('d1', 'd5', 'c1', 'fin')]
LITEST_PASSES.insert(3, dict(name='c5', src='c5', out=None, fmt='unorm8',
    reads=dict(COMMON, colortex0=('target', 'previous')), label='Tonemap (composite5)'))
LITEST_PASSES[1] = dict(LITEST_PASSES[1], label='Reflection image (deferred1)')
if len(sys.argv) > 2 and sys.argv[2] == 'litest':
    PASSES = LITEST_PASSES
elif len(sys.argv) > 2 and sys.argv[2] == 'lite':
    PASSES = LITE_PASSES

def helper(P, kind, tex, src):
    """WGSL for hz_<kind>_<tex> reading `src`."""
    sig = {'load': '(t: vec2<i32>) -> vec4<f32>', 'sample': '(uv: vec2<f32>) -> vec4<f32>',
           'lod': '(uv: vec2<f32>, lod: f32) -> vec4<f32>', 'cmp': '(uv: vec2<f32>, z: f32) -> f32'}[kind]
    head = f'fn hz_{kind}_{tex}{sig} {{\n'
    if isinstance(src, tuple) and src[0] == 'target':
        n = src[1]
        if kind == 'load' and n == 'scene_color':  # with the material stage's HDR scale back in
            b = ('let size = vec2<i32>(textureDimensions(scene_color));\n    if hz_outside(t, size) { return vec4<f32>(0.0); }\n    '
                 'let ft = hz_flip_texel(t, size);\n    let c = textureLoad(scene_color, ft, 0);\n    '
                 'return vec4<f32>(c.rgb * hz_hdr_scale(ft), c.a);')
        elif kind == 'load':
            b = (f'let size = vec2<i32>(textureDimensions({n}));\n    if hz_outside(t, size) {{ return vec4<f32>(0.0); }}\n    '
                 f'return textureLoad({n}, hz_flip_texel(t, size), 0);')
        elif n == 'scene_color':
            b = ('let c = textureSampleLevel(scene_color, linear_sampler, hz_flip_uv(uv), 0.0);\n    '
                 'let size = vec2<i32>(textureDimensions(scene_color));\n    '
                 'let ft = clamp(vec2<i32>(floor(hz_flip_uv(uv) * vec2<f32>(size))), vec2<i32>(0), size - 1);\n    '
                 'return vec4<f32>(c.rgb * hz_hdr_scale(ft), c.a);')
        else:  # Iris's colortex: linear, clamped (no mipmaps but colortex0's; see the report)
            b = f'return textureSampleLevel({n}, linear_sampler, hz_flip_uv(uv), 0.0);'
    elif isinstance(src, tuple) and src[0] == 'vl':
        b = f'return textureLoad({src[1]}, vec2<i32>(0), 0);'
    elif src == 'depth':
        b = {'load': 'return vec4<f32>(hz_gl_depth_texel(t));'}.get(kind, 'return vec4<f32>(hz_gl_depth_uv(uv));')
    elif src in ('c6', 'c4'):
        b = {'load': f'return hz_colortex{src[1]}_texel(t);'}.get(kind,
            f'return hz_colortex{src[1]}_texel(clamp(vec2<i32>(floor(uv * frame.resolution)), vec2<i32>(0), vec2<i32>(frame.resolution) - 1));')
    elif src == 'noise':
        b = {'load': 'return textureLoad(noisetex, t, 0);', 'lod': 'return textureSampleLevel(noisetex, noisetex_sampler, uv, lod);'}.get(
            kind, 'return textureSampleLevel(noisetex, noisetex_sampler, uv, 0.0);')
    elif src == 'cloudwater':
        b = 'return textureSampleLevel(cloudwater, cloudwater_sampler, uv, 0.0);'
    elif src in ('shadow0', 'shadow1'):
        m = 'shadow_map_translucent' if src == 'shadow0' else 'shadow_map'
        # shadowtex0 (everything that casts) is the nearer of Horizon's two maps: its entities are
        # in shadow_map only (see gen_material.py).
        if src == 'shadow0':
            b = {'cmp': 'return min(textureSampleCompareLevel(shadow_map_translucent, shadow_sampler, uv, hz_shadow_z_from_iris(z)), '
                        'textureSampleCompareLevel(shadow_map, shadow_sampler, uv, hz_shadow_z_from_iris(z)));',
                 'load': 'return vec4<f32>(hz_shadow_z_to_iris(min(textureLoad(shadow_map_translucent, t, 0), textureLoad(shadow_map, t, 0))));'}.get(kind,
                 'let t = vec2<i32>(uv * vec2<f32>(textureDimensions(shadow_map)));\n    '
                 'return vec4<f32>(hz_shadow_z_to_iris(min(textureLoad(shadow_map_translucent, t, 0), textureLoad(shadow_map, t, 0))));')
        else:
            b = {'cmp': f'return textureSampleCompareLevel({m}, shadow_sampler, uv, hz_shadow_z_from_iris(z));',
                 'load': f'return vec4<f32>(hz_shadow_z_to_iris(textureLoad({m}, t, 0)));'}.get(kind,
                 f'return vec4<f32>(hz_shadow_z_to_iris(textureLoad({m}, vec2<i32>(uv * vec2<f32>(textureDimensions({m}))), 0)));')
    elif src == 'shadowcolor1':
        b = {'load': 'return hz_shadowcolor1_texel(t);'}.get(kind,
            'return hz_shadowcolor1_texel(vec2<i32>(uv * vec2<f32>(textureDimensions(shadow_color))));')
    elif src == 'zero':
        b = 'return vec4<f32>(0.0);'
    elif src == 'mip':
        assert kind == 'sample'
        # composite4.glsl:28-40 BloomTile samples with GL's implicit level of detail, which is
        # its `lod` where scaledCoord isn't stretched (up to 1920x1080) and more beyond.
        b = 'return hz_mip_sample(hz_bloom_lod, uv);'
    else:
        raise SystemExit(f'{tex}: {src}')
    return head + '    ' + b + '\n}\n'

MIPA = '''
// Levels 2 to 4 of the colortex0 mipmaps Iris makes for composite4: each texel the box average of
// the 2^L × 2^L block of the full picture under it (what glGenerateMipmap's 2×2 boxes add up to).
fn post(input: PostInput) -> vec4<f32> {
    let t = vec2<i32>(input.pixel);
    for (var level = 2; level <= 4; level++) {
        let o = hz_mip_origin(level);
        let s = hz_mip_size(level);
        let q = t - o;
        if all(q >= vec2<i32>(0)) && all(q < s) {
            let n = 1 << u32(level);
            var sum = vec4<f32>(0.0);
            for (var y = 0; y < n; y++) {
                for (var x = 0; x < n; x++) {
                    sum += textureLoad(previous, q * n + vec2<i32>(x, y), 0);
                }
            }
            return sum / f32(n * n);
        }
    }
    return vec4<f32>(0.0);
}
'''
MIPB = '''
// Levels 5 to 8 from level 4 (ta, the pass before), and levels 2 to 4 passed through.
fn post(input: PostInput) -> vec4<f32> {
    let t = vec2<i32>(input.pixel);
    for (var level = 2; level <= 8; level++) {
        let o = hz_mip_origin(level);
        let s = hz_mip_size(level);
        let q = t - o;
        if all(q >= vec2<i32>(0)) && all(q < s) {
            if level <= 4 { return textureLoad(ta, t, 0); }
            let n = 1 << u32(level - 4);
            let o4 = hz_mip_origin(4);
            var sum = vec4<f32>(0.0);
            for (var y = 0; y < n; y++) {
                for (var x = 0; x < n; x++) {
                    sum += textureLoad(ta, o4 + q * n + vec2<i32>(x, y), 0);
                }
            }
            return sum / f32(n * n);
        }
    }
    return vec4<f32>(0.0);
}
'''

def shadow_overrides(src, P):
    for fn, body in ((f'{P}GetShadowPos_u0028_vf3_u003b', 'return hz_shadow_pos_iris({a0});'),
                     (f'{P}GetShadowOnCloudPosition_u0028_vf3_u003b_vf3_u003b', 'return hz_shadow_pos_iris({a0} - {a1});')):
        m = re.search(r'^fn ' + re.escape(fn) + r'\((.*?)\) -> vec3<f32> \{\n.*?^\}\n', src, re.S | re.M)
        if m:
            args = [a.split(':')[0].strip() for a in m.group(1).split(',')]
            src = src[:m.start()] + f'fn {fn}({m.group(1)}) -> vec3<f32> {{\n    ' + \
                body.format(a0=args[0], a1=args[-1]) + '\n}\n' + src[m.end():]
    return src

def output_member(src, P, k):
    m = re.search(r'^fn ' + P + r'entry\(.*?\{\n(.*?)^\}', src, re.S | re.M)
    body = m.group(1)
    lets = dict(re.findall(r'let (_e\d+) = ' + P + r'cr_out(\d)_;', body))
    args = re.search(r'return ' + P + r'FragmentOutput\((.*?)\);', body).group(1).split(', ')
    i = [lets[a] for a in args].index(str(k))
    return 'member' if i == 0 else f'member_{i}'

# The dimensions: Horizon runs one set of passes everywhere, so each pass holds Complementary's
# program of each dimension folder (world0, world-1, world1) and runs the one frame.dimension names
# (any other dimension: the Overworld's, as Iris falls back to world0).
DIMS = [d.split(':', 1) for d in os.environ.get('HZ_POST_DIRS', 'o:' + os.environ.get('HZ_POST_DIR', D + '/../post')).split(',')]
DIM_ID = {'o': None, 'n': -1, 'e': 1}

def load_variant(path, P, Q):
    """The translated program (prefix P) as prefix Q, its loads deduplicated."""
    import subprocess, tempfile
    tmp = tempfile.mktemp(suffix='.wgsl')
    subprocess.run([sys.executable, D + '/load_cse.py', path, tmp], check=True)
    src = open(tmp).read(); os.remove(tmp)
    return re.sub(r'(?<![\w.])' + re.escape(P), Q, src)

def has_output(src, P, k):
    try:
        output_member(src, P, k); return True
    except (ValueError, AttributeError):
        return False

POST_FN = """
fn post(input: PostInput) -> vec4<f32> {
    // gl_FragCoord and texCoord: GL's, from the bottom left.
    let frag = FRAG;
    let tc = TC;
BODY}
"""

entries = []
os.makedirs(pack + '/post', exist_ok=True)
for i, ps in enumerate(PASSES):
    name = ps['name']
    if ps.get('special'):
        text = ADAPTER + (MIPA if ps['special'] == 'mipa' else MIPB)
    else:
        import subprocess, tempfile
        k = {'d5': 1, 'vl': 1, 'd4': 2}.get(name, 0)
        variants = []
        for tag, path in DIMS:
            P0, Q = ps['src'] + '_', ps['src'] + tag + '_'
            f = path + f'/hz_{ps["src"]}.wgsl'
            if not os.path.exists(f): continue
            src = shadow_overrides(load_variant(f, P0, Q), Q)
            if name == 'c4':
                src, n = re.subn(r'(fn ' + Q + r'BloomTile\w*\(lod: f32, [^)]*\) -> vec3<f32> \{\n)',
                    r'\1    hz_bloom_lod = lod + log2(max(max(frame.resolution.x / 1920.0, frame.resolution.y / 1080.0), 1.0));\n', src)
                assert n == 1
            variants.append((tag, Q, src))
        # one module: the variants' identical pure functions shared
        tmps = []
        for tag, Q, src in variants:
            t = tempfile.mktemp(suffix='.wgsl'); open(t, 'w').write(src); tmps.append(f'{Q}:{t}')
        merged_path = tempfile.mktemp(suffix='.wgsl')
        subprocess.run([sys.executable, D + '/dedupe.py', merged_path] + tmps, check=True, stdout=subprocess.DEVNULL)
        merged = open(merged_path).read()
        for t in tmps: os.remove(t.split(':', 1)[1])
        os.remove(merged_path)
        used = sorted(set(re.findall(r'\bhz_(load|sample|lod|cmp)_(\w+?)\(', merged)))
        helpers = ''.join(helper('', kk, t, ps['reads'][t]) for kk, t in used)
        fmt = {'unorm8': 'hz_fmt_unorm8', 'snorm8': 'hz_fmt_snorm8', 'r11g11b10': 'hz_fmt_r11g11b10',
               'rgba16f': '', None: ''}[ps['fmt']]
        fills, branches = '', []
        for tag, Q, src in variants:
            fills += fill(merged, Q)
            if not has_output(merged, Q, k):
                call = "return vec4<f32>(0.0);  // this dimension's program doesn't write it"
            else:
                params = [a.split(':')[0].strip() for a in re.search(r'^fn ' + Q + r'entry\((.*?)\) ->', merged, re.M).group(1).split(',')]
                args = ', '.join({'gl_FragCoord': 'frag', 'texCoord': 'tc'}[a] for a in params)
                call = f'{Q}fill();\n        let o = {Q}entry({args});\n        return {fmt}(o.{output_member(merged, Q, k)});'
            branches.append((DIM_ID[tag], call))
        frag_y = 'f32(textureDimensions(scene_color).y) - input.pixel.y' if name == 'fin' else 'frame.resolution.y - input.pixel.y'
        frag = f'vec4<f32>(input.pixel.x, {frag_y}, 0.5, 1.0)'
        tc = 'hz_flip_uv(input.uv)'
        if name == 'vl':
            # vl: the equilibrium of Complementary's scene-aware light shafts factor (composite1.glsl:
            # 932-934), which Iris keeps in colortex5's top-right texel and moves by one 8-bit step
            # a frame; post_build.sh makes the step 1, so it's reached at once (Horizon keeps
            # nothing from frame to frame). The pass runs composite1 for that texel only.
            frag = 'vec4<f32>(frame.resolution.x - 0.5, frame.resolution.y - 0.5, 0.5, 1.0)'
            tc = '(vec2<f32>(1.0, 1.0) - 0.5 / frame.resolution)'
        default = [c for d, c in branches if d is None][0]
        body = ''
        for d, c in branches:
            if d is not None:
                body += f'    if frame.dimension == {d}i {{\n        {c}\n    }}\n'
        body += '    {\n        ' + default + '\n    }\n'
        post = POST_FN.replace('FRAG', frag).replace('TC', tc).replace('BODY', body)
        bloom = 'var<private> hz_bloom_lod: f32;\n' if name == 'c4' else ''
        text = ADAPTER + fills + merged + helpers + bloom + post
        # the light shaft colour's sunVisibility (adapter/post.wgsl): the running program's
        if 'hz_unnamed_sunVisibility()' in text:
            sv = 'fn hz_sun_visibility() -> f32 {\n'
            for tag, Q, src in variants:
                v = Q + 'sunVisibility' if re.search(r'^var<private> ' + Q + r'sunVisibility:', merged, re.M) else '0.0'
                if DIM_ID[tag] is not None:
                    sv += f'    if frame.dimension == {DIM_ID[tag]}i {{ return {v}; }}\n'
            vo = [Q + 'sunVisibility' for tag, Q, src in variants if DIM_ID[tag] is None][0]
            sv += f'    return {vo};\n}}\n'
            text = text.replace('hz_unnamed_sunVisibility()', 'hz_sun_visibility()') + sv
    out = f'post/{i:02d}_{name}.wgsl'
    open(f'{pack}/{out}', 'w').write(prune(text, ['post']))
    e = f'[[post]]\nfile = "{out}"\nname = "{ps["label"]}"\n'
    if ps['out']:
        e += f'output = "{ps["out"]}"\n'
        if ps.get('scale', 1) != 1: e += f'scale = {ps["scale"]}\n'
    entries.append(e)
open(pack + '/post.toml', 'w').write('\n'.join(entries))
print(len(entries), 'passes')
