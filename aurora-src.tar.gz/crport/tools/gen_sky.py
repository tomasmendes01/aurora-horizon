"""The pack's sky stage from the translated gbuffers_skybasic (prefix s_).
usage: gen_sky.py hz.wgsl out.wgsl"""
import re, sys, os
D = os.path.dirname(__file__)
sys.path.insert(0, D)
from uniforms import fill
from wgsl_items import prune
src = open(sys.argv[1]).read()
adapter = open(D + '/../adapter/iris.wgsl').read()
# gbuffers_skybasic.glsl:74-77 finds the view ray from gl_FragCoord through
# gbufferProjectionInverse; Horizon gives the ray. This matrix takes any screen position to the
# ray (as a point, w 1), so the code runs unchanged for every direction, behind the camera too.
u = fill(src, 's_', {'gbufferProjectionInverse':
    'mat4x4<f32>(vec4<f32>(0.0), vec4<f32>(0.0), vec4<f32>(0.0), vec4<f32>(hz_sky_view_ray, 1.0))'})
sky = '''
var<private> hz_sky_view_ray: vec3<f32>;

fn sky(input: SkyInput) -> vec4<f32> {
    // Iris draws no gbuffers_skybasic in the Nether and the End (vanilla draws no sky dome there);
    // deferred1 paints their sky pixels over the world's picture (world-1/world1 deferred1.glsl).
    if frame.dimension != 0i { return input.color; }
    hz_sky_view_ray = (frame.view * vec4<f32>(input.direction, 0.0)).xyz;
    // gl_FragCoord, for Bayer8's dither: the pixel the ray lands on (GL's, from the bottom left).
    let clip = hz_projection() * vec4<f32>(hz_sky_view_ray, 1.0);
    let ndc = clip.xy / max(abs(clip.w), 1e-6);
    let frag = vec4<f32>((ndc * 0.5 + 0.5) * frame.resolution, 1.0, 1.0);
    s_fill();
    // glColor is vanilla's sky colour (gl_Color of the sky disc); vanillaStars 0, Horizon's stars are off.
    let o = s_entry(frag, input.color, 0.0);
    return o.member;
}
'''
text = adapter + '\n' + u + src + sky
open(sys.argv[2], 'w').write(prune(text, ['sky']))
