# Small GLSL rewrites for naga's SPIR-V reader: isnan, and modf's out parameter.
import re, sys
s = sys.stdin.read()
s = re.sub(r'gl_FragData\[([0-9])\]', r'cr_out\1', s)
s = re.sub(r'any\(isnan\(([a-zA-Z_]\w*)\)\)', r'any(notEqual(\1, \1))', s)
s = re.sub(r'isnan\(([a-zA-Z_]\w*)\)', r'(\1 != \1)', s)
s = re.sub(r'(vec[234]|float) (\w+), (\w+) = modf\(([^,;]+), \2\);', r'\1 \2 = trunc(\4), \3 = \4 - \2;', s)
sys.stdout.write(s)
