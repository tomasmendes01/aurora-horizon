"""naga's WGSL of one Complementary program → a fragment of a Horizon stage:
- every top-level name gets the program's prefix (two programs share a stage);
- the uniform block becomes a private variable the adapter fills (`{p}unnamed`);
- textures and samplers lose their bindings and each read becomes Horizon's resource or an
  adapter helper (see READS);
- the entry point `main` becomes `{p}entry(...)`, a plain function returning `{p}FragmentOutput`.
usage: hzify.py in.wgsl prefix out.wgsl
"""
import re, sys
src, P = open(sys.argv[1]).read(), sys.argv[2]

# Top-level names.
names = set(re.findall(r'^(?:struct|fn|var(?:<\w+>)?|const|override|alias) (\w+)', src, re.M))
names |= {'gl_DefaultUniformBlock', 'FragmentOutput'}
names.discard('main')
# Renaming: longest first, at word boundaries, not after a `.` (fields keep their names).
pat = re.compile(r'(?<![\w.])(' + '|'.join(sorted(map(re.escape, names), key=len, reverse=True)) + r')\b')
src = pat.sub(lambda m: P + m.group(1), src)

# Bindings off; the uniform block private.
src = re.sub(r'@group\(\d+\) @binding\(\d+\)\s*\n', '', src)
src = re.sub(r'^var<uniform> (\w+): ', r'var<private> \1: ', src, flags=re.M)
# Texture and sampler declarations go: their reads are rewritten below.
src = re.sub(r'^var \w+: (texture\w*(<[^>]*>)?|sampler(_comparison)?);\n', '', src, flags=re.M)

def T(n): return P + n + '_t'
def S(n): return P + n + '_s'
def args_of(text, i):
    depth, j = 1, i
    while depth:
        depth += {'(': 1, ')': -1}.get(text[j], 0); j += 1
    out, depth, cur = [], 0, ''
    for c in text[i:j - 1]:
        if c in '([': depth += 1
        if c in ')]': depth -= 1
        if c == ',' and depth == 0: out.append(cur.strip()); cur = ''
        else: cur += c
    out.append(cur.strip())
    return out, j

# (function, texture) → how the read is written in Horizon. `a` are the call's arguments.
READS = {
    ('textureSampleCompare', 'shadowtex0'): lambda a: f'textureSampleCompareLevel(shadow_map_translucent, shadow_sampler, {a[2]}, {a[3]})',
    ('textureSampleCompare', 'shadowtex1'): lambda a: f'textureSampleCompareLevel(shadow_map, shadow_sampler, {a[2]}, {a[3]})',
    ('textureSampleCompareLevel', 'shadowtex0'): lambda a: f'textureSampleCompareLevel(shadow_map_translucent, shadow_sampler, {a[2]}, {a[3]})',
    ('textureSampleCompareLevel', 'shadowtex1'): lambda a: f'textureSampleCompareLevel(shadow_map, shadow_sampler, {a[2]}, {a[3]})',
    ('textureSample', 'shadowcolor0'): lambda a: f'hz_shadow_color({a[2]})',
    ('textureSampleLevel', 'shadowcolor0'): lambda a: f'hz_shadow_color({a[2]})',
    ('textureSample', 'tex'): lambda a: f'block_texture({a[2]})',
    ('textureSampleLevel', 'tex'): lambda a: f'block_texture_level({a[2]}, {a[3]})',
    ('textureSampleGrad', 'tex'): lambda a: f'block_texture({a[2]})',
    ('textureSample', 'noisetex'): lambda a: f'textureSampleLevel(noisetex, noisetex_sampler, {a[2]}, 0.0)',
    ('textureSampleLevel', 'noisetex'): lambda a: f'textureSampleLevel(noisetex, noisetex_sampler, {a[2]}, {a[3]})',
    ('textureSample', 'depthtex1'): lambda a: f'hz_depth_uv({a[2]})',
    ('textureLoad', 'depthtex1'): lambda a: f'hz_depth_texel({a[1]})',
    ('textureSample', 'gaux2'): lambda a: f'hz_opaque_uv({a[2]})',
    ('textureLoad', 'gaux2'): lambda a: f'hz_opaque_texel({a[1]})',
    # Buffers the material stage can't see: colortex13 (entities' depth, cleared to 0 where none) and
    # colortex5's corner (the light shafts factor, a post pass's): 0.
    ('textureSample', 'colortex13'): lambda a: 'vec4<f32>(0.0)',
    ('textureLoad', 'colortex5'): lambda a: 'vec4<f32>(0.0)',
}
import os
if os.environ.get('HZ_GENERIC'):
    # Post passes: every read becomes a helper the pass's adapter defines, named by the texture.
    def generic(fn, tex):
        kind = {'textureLoad': 'load', 'textureSample': 'sample', 'textureSampleLevel': 'lod',
                'textureSampleCompare': 'cmp', 'textureSampleCompareLevel': 'cmp',
                'textureSampleGrad': 'sample', 'textureSampleBias': 'sample'}[fn]
        if kind == 'load':
            return lambda a: f'hz_load_{tex}({a[1]})'
        if kind == 'lod':
            return lambda a: f'hz_lod_{tex}({a[2]}, {a[3]})'
        if kind == 'cmp':
            return lambda a: f'hz_cmp_{tex}({a[2]}, {a[3]})'
        return lambda a: f'hz_sample_{tex}({a[2]})'
    class G(dict):
        def __contains__(self, k): return True
        def __getitem__(self, k): return generic(*k)
    READS = G()
missing = set()
out, pos = [], 0
for m in re.finditer(r'\b(texture\w+)\(', src):
    if m.start() < pos: continue
    a, j = args_of(src, m.end())
    tm = re.fullmatch(re.escape(P) + r'(\w+)_t', a[0]) if a else None
    if not tm:
        continue
    key = (m.group(1), tm.group(1))
    if key not in READS:
        missing.add(key); continue
    out.append(src[pos:m.start()] + READS[key](a)); pos = j
out.append(src[pos:]); src = ''.join(out)
if missing:
    sys.exit(f'hzify {P}: no mapping for {sorted(missing)}')

# The entry point: attributes off, a plain function.
src = re.sub(r'@fragment\s*\nfn main\(', f'fn {P}entry(', src)
src = re.sub(r'@vertex\s*\nfn main\(', f'fn {P}entry(', src)
src = re.sub(r'@(builtin\(\w+\)|location\(\d+\)|interpolate\(\w+\))\s*', '', src)
# A setting is read straight from its `override` (no copy in the uniform block).
import json as _json
_choice = {n for n, o in (_json.load(open(os.environ['HZ_OPTS'])).items() if os.environ.get('HZ_OPTS') else []) if o['type'] == 'choice'}
src = re.sub(r'\b\w*unnamed\.hzopt_(\w+)\b', lambda m: f'i32({m.group(1)})' if m.group(1) in _choice else m.group(1), src)
open(sys.argv[3], 'w').write(src)
