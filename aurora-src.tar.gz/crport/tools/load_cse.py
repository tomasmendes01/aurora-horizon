"""Redundant load elimination on naga's WGSL: a `let _eN = x;` that reads a variable already read
into a `let` in scope, with no write to it in between, reuses that let. The same values, fewer
expressions (each load is a pointer and a Load in naga's count). Conservative: any call to a
function of the module forgets every global; a variable whose address is taken is never reused;
a loop forgets everything at its start; writes inside a block are forgotten after it too.
usage: load_cse.py in out"""
import re, sys
src = open(sys.argv[1]).read()
fn_names = set(re.findall(r'^\s*fn (\w+)\(', src, re.M))
globals_ = set(re.findall(r'^\s*var<private> (\w+)', src, re.M))
FN_RE = re.compile(r'^\s*fn (\w+)\(.*?\n\s*\}\s*$', re.S | re.M)
def fn_bodies(text):
    out, cur, depth, name = {}, None, 0, None
    for line in text.split('\n'):
        if cur is None:
            m = re.match(r'^\s*fn (\w+)\(', line)
            if m:
                name, cur, depth = m.group(1), [line], line.count('{') - line.count('}')
                if depth == 0 and '{' in line: out[name] = '\n'.join(cur); cur = None
        else:
            cur.append(line); depth += line.count('{') - line.count('}')
            if depth == 0: out[name] = '\n'.join(cur); cur = None
    return out
BODIES = fn_bodies(src)
WRITES = {}
for n, b in BODIES.items():
    WRITES[n] = {g for g in re.findall(r'^\s*([A-Za-z_]\w*)\s*(?:\.|\[|=(?!=)|[-+*/%&|^]=)', b, re.M)} | \
                {g for g in re.findall(r'&(\w+)', b)}
    WRITES[n] &= set(re.findall(r'^\s*var<private> (\w+)', src, re.M))
CALLS = {n: set(re.findall(r'\b([A-Za-z_]\w*)\(', b)) & set(BODIES) for n, b in BODIES.items()}
changed = True
while changed:
    changed = False
    for n in BODIES:
        for c in CALLS[n]:
            if not WRITES[c] <= WRITES[n]:
                WRITES[n] |= WRITES[c]; changed = True
LOAD = re.compile(r'^(\s*)let (_e\d+) = ([A-Za-z_]\w*);\s*$')
CALL = re.compile(r'\b([A-Za-z_]\w*)\(')

def process_fn(lines):
    locals_ = {m.group(1) for l in lines for m in [re.match(r'\s*var (\w+)', l)] if m}
    lets = {m.group(1) for l in lines for m in [re.match(r'\s*let (\w+) =', l)] if m}
    addr = set(re.findall(r'&(\w+)', '\n'.join(lines)))
    scopes = [dict()]          # per open block: name -> let available (defined in this block)
    dirty = [set()]            # per open block: names written in it
    alias = {}
    out = []
    def avail(name):
        for sc in reversed(scopes):
            if name in sc: return sc[name]
        return None
    def invalidate(name):
        for sc in scopes: sc.pop(name, None)
        dirty[-1].add(name)
    def invalidate_globals():
        for g in [n for sc in scopes for n in sc if n in globals_]: invalidate(g)
    for line in lines:
        s = line.strip()
        m = LOAD.match(line)
        if m:
            e, name = m.group(2), m.group(3)
            if name in lets and name not in alias:  # a let: just another name for it
                alias[e] = name; continue
            if (name in locals_ or name in globals_) and name not in addr:
                a = avail(name)
                if a is not None:
                    alias[e] = a; continue
                scopes[-1][name] = e
            out.append(line); continue
        # writes
        w = re.match(r'^\s*([A-Za-z_]\w*)\s*(\.|\[|=(?!=)|[-+*/%&|^]=)', line)
        if w and not s.startswith(('let ', 'var ')):
            invalidate(w.group(1))
        for c in CALL.findall(s):
            if c in WRITES:
                for g in WRITES[c]: invalidate(g)
        # a store of a let: later loads of it are that let
        st = re.match(r'^\s*([A-Za-z_]\w*) = (_e\d+|[A-Za-z_]\w*);\s*$', line)
        if st and st.group(1) in (locals_ | globals_) and st.group(1) not in addr and (st.group(2) in lets or st.group(2).startswith('_e')):
            out.append(line)
            scopes[-1][st.group(1)] = alias.get(st.group(2), st.group(2))
            continue
        closes = s.startswith('}')
        opens = s.endswith('{')
        if closes:
            sc, d = scopes.pop(), dirty.pop()
            for n in d: invalidate(n)
        if opens:
            if re.match(r'^(\}\s*)?(loop|continuing)\b', s) or s.startswith('loop'):
                # a loop body runs again after its own writes: start it knowing nothing
                for n in [n for sc in scopes for n in sc]: invalidate(n)
            scopes.append(dict()); dirty.append(set())
        out.append(line)
    text = '\n'.join(out)
    if alias:
        def res(n):
            while n in alias: n = alias[n]
            return n
        text = re.sub(r'\b_e\d+\b', lambda m: res(m.group(0)), text)
    return text

out, cur, depth = [], None, 0
for line in src.split('\n'):
    if cur is None:
        if re.match(r'^\s*fn \w+\(', line):
            cur = [line]; depth = line.count('{') - line.count('}')
            if depth == 0 and '{' in line:
                out.append(process_fn(cur)); cur = None
        else:
            out.append(line)
    else:
        cur.append(line); depth += line.count('{') - line.count('}')
        if depth == 0:
            out.append(process_fn(cur)); cur = None
open(sys.argv[2], 'w').write('\n'.join(out))
