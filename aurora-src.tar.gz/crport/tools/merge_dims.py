"""One program for every dimension: the Overworld's preprocessed GLSL with, where the Nether's or
the End's differs, both versions under a runtime test of the dimension (uniform hzDimension), so
each dimension runs exactly its own code. Global initializers first move into main (GLSL runs them
there anyway, in order), so every difference is inside a function body.
usage: merge_dims.py out.glsl world0.glsl [-1:world-1.glsl] [1:world1.glsl]"""
import re, sys, difflib, os
sys.path.insert(0, os.path.dirname(__file__))
from defer_globals import defer, split_top

MARK = '    // (hz: global initializers)'
def prepare(path):
    s = open(path).read()
    m = re.search(r'\bvoid main\s*\(\s*\)\s*\{', s)
    s = s[:m.end()] + '\n' + MARK + '\n' + s[m.end():]
    s, n = defer(s, MARK)
    return s.split('\n')

base = prepare(sys.argv[2])
others = []
for a in sys.argv[3:]:
    d, p = a.split(':', 1)
    others.append((int(d), prepare(p)))

def key(l): return re.sub(r'\s+', ' ', l.strip())
bk = [key(l) for l in base]

# brace depth before each base line, and statement ends
depth = []
d = 0
for l in base:
    depth.append(d)
    d += l.count('{') - l.count('}')

def opcodes(o):
    sm = difflib.SequenceMatcher(None, bk, [key(l) for l in o], autojunk=False)
    return sm.get_opcodes()

ops = [(dim, o, opcodes(o)) for dim, o in others]
# changed base intervals (insertions are empty intervals at i1)
iv = []
for dim, o, oc in ops:
    for tag, i1, i2, j1, j2 in oc:
        if tag != 'equal':
            iv.append([i1, i2])

def stmt_boundary_before(i):
    # back to a line after which a statement starts (prev line ends with ; { } or blank)
    while i > 0 and not re.search(r'[;{}]\s*$', base[i - 1].strip() + ';' if base[i - 1].strip() == '' else base[i - 1].rstrip()):
        i -= 1
    return i
def stmt_boundary_after(i):
    while i < len(base) and i > 0 and not re.search(r'[;{}]\s*$', base[i - 1].rstrip()) and base[i - 1].strip():
        i += 1
    return i

def map_index(oc, i, side):
    """the other's line index for base boundary i: a hunk's edge when one starts (start) or ends
    (end) there, so an insertion at i is inside the range"""
    for tag, i1, i2, j1, j2 in oc:
        if tag != 'equal' and side == 'start' and i1 == i: return j1
        if tag != 'equal' and side == 'end' and i2 == i: return j2
    for tag, i1, i2, j1, j2 in oc:
        if tag == 'equal' and i1 <= i <= i2: return j1 + (i - i1)
    return None

def balanced(lines):
    return sum(l.count('{') - l.count('}') for l in lines) == 0

# merge overlapping/adjacent intervals and grow them to statement and brace boundaries
iv.sort()
changed = True
while changed:
    changed = False
    iv.sort(); m = []
    for a, b in iv:
        a2, b2 = stmt_boundary_before(a), stmt_boundary_after(b)
        if (a2, b2) != (a, b): changed = True
        a, b = a2, b2
        if m and a <= m[-1][1]:
            m[-1][1] = max(m[-1][1], b)
        else:
            m.append([a, b])
    iv = m
    for x in iv:
        segs = [base[x[0]:x[1]]]
        ok = all(map_index(oc, x[0], 'start') is not None and map_index(oc, x[1], 'end') is not None for _, _, oc in ops)
        if ok:
            for dim, o, oc in ops:
                segs.append(o[map_index(oc, x[0], 'start'):map_index(oc, x[1], 'end')])
        if not ok or not all(balanced(sg) for sg in segs) or depth[x[0]] == 0 and any(l.strip() for sg in segs[1:] for l in sg) and depth[x[0]] == 0 and False:
            # grow by a line each side
            x[0] = max(0, x[0] - 1); x[1] = min(len(base), x[1] + 1); changed = True

def hoist(lines):
    """declarations at the segment's top level: (declarations, statements)"""
    text = '\n'.join(lines)
    stmts, cur, d = [], '', 0
    for ch in text:
        cur += ch
        if ch == '{': d += 1
        if ch == '}':
            d -= 1
            if d == 0: stmts.append(cur); cur = ''
        if ch == ';' and d == 0: stmts.append(cur); cur = ''
    if cur.strip(): stmts.append(cur)
    decls, body = [], []
    for st in stmts:
        m = DECL.match(st.strip('\n')) if '{' not in st else None
        if m and not m.group(2).startswith('const'):
            names = []
            for part in split_top(m.group(3), ','):
                p = part.split('=', 1)
                names.append(p[0].strip())
                if len(p) == 2:
                    body.append(f'{m.group(1)}{re.sub(r"\[.*\]", "", p[0].strip())} = {p[1].strip()};')
            decls.append((m.group(2), names))
        else:
            body.append(st.strip('\n'))
    return decls, body

DECL = re.compile(r'^(\s*)((?:flat\s+|const\s+)?(?:float|int|uint|bool|[biu]?vec[234]|mat[234](?:x[234])?))\s+(.*);\s*$', re.S)
out, pos = [], 0
declared_global = set()
for a, b in iv:
    out.extend(base[pos:a])
    variants = [(None, base[a:b])] + [(dim, o[map_index(oc, a, 'start'):map_index(oc, b, 'end')]) for dim, o, oc in ops]
    if depth[a] == 0:
        # global scope: the Overworld's lines, and whatever the others declare or define that the
        # Overworld's program doesn't name at all
        out.extend(base[a:b])
        base_text = '\n'.join(l for l, dd in zip(base, depth) if dd == 0)  # its global scope
        for dim, seg in variants[1:]:
            text_ = '\n'.join(seg)
            items, cur, dd = [], '', 0
            for ch in text_:
                cur += ch
                if ch == '{': dd += 1
                if ch == '}':
                    dd -= 1
                    if dd == 0: items.append(cur); cur = ''
                if ch == ';' and dd == 0: items.append(cur); cur = ''
            for it in items:
                dm = DECL.match(it.strip('\n')) if '{' not in it else None
                if dm:
                    for part in split_top(dm.group(3), ','):
                        nn = part.split('=', 1)[0].strip()
                        if not re.search(r'\b' + re.sub(r'\[.*\]', '', nn) + r'\b', base_text):
                            out.append(f'{dm.group(2)} {nn};')
                    continue
                mm = re.search(r'(\w+)\s*(\(|\[|;|=)', it.strip())
                nm = re.match(r'^(?:uniform\s+|const\s+|flat\s+|in\s+)*\w+\s+(\w+)', it.strip())
                n_ = nm.group(1) if nm else None
                if n_ and not re.search(r'\b' + n_ + r'\b', base_text):
                    out.append(it.strip('\n'))
        pos = b; continue
    hoisted, names = [], {}
    branches = []
    for dim, seg in variants:
        decls, body = hoist(seg)
        for ty, ns in decls:
            for n in ns:
                nn = re.sub(r'\[.*\]', '', n)
                if nn in names:
                    if names[nn][0] != ty: raise SystemExit(f'{nn}: {names[nn][0]} or {ty}')
                    continue
                names[nn] = (ty, n); hoisted.append(f'    {ty} {n};')
        branches.append((dim, body))
    out.extend(hoisted)
    first = True
    for dim, body in branches[1:]:
        out.append(f'    {"if" if first else "else if"} (hzDimension == {dim}) {{')
        out.extend(body); out.append('    }'); first = False
    out.append('    else {'); out.extend(branches[0][1]); out.append('    }')
    pos = b
out.extend(base[pos:])
text = '\n'.join(out)
text = text.replace(MARK, MARK, 1)
# the dimension, from the frame
m = re.search(r'^\s*uniform\s', text, re.M)
text = text[:m.start()] + 'uniform int hzDimension;\n' + text[m.start():]
open(sys.argv[1], 'w').write(text)
print(f'{len(iv)} merged differences')
