"""A fullscreen program as one fragment program: the vertex shader's main body (after the
preprocessor, so the same code) runs at the top of the fragment's main, except gl_Position and
texCoord (the pixel's, given by Horizon). Varyings it sets become plain globals; declarations
(uniforms, functions) the vertex shader has and the fragment lacks are added.
usage: merge_vsh.py vsh.glsl fsh.glsl out.glsl"""
import re, sys
vsh, fsh = open(sys.argv[1]).read(), open(sys.argv[2]).read()

def body(src, start):
    i = src.index('{', start) + 1; d = 1; j = i
    while d:
        d += {'{': 1, '}': -1}.get(src[j], 0); j += 1
    return i, j - 1

vm = re.search(r'\bvoid main\s*\(\s*\)', vsh)
a, b = body(vsh, vm.end())
vbody = vsh[a:b]
vbody = re.sub(r'^\s*gl_Position\s*=.*?;\s*$', '', vbody, flags=re.M)
vbody = re.sub(r'^\s*texCoord\s*=.*?;\s*$', '', vbody, flags=re.M)
assigned = set(re.findall(r'\b(\w+)\s*=[^=]', vbody))
# varyings of the fragment shader the vertex body sets → globals
def deflat(m):
    names = [n.strip() for n in m.group(3).split(',')]
    if all(n in assigned for n in names):
        return f'{m.group(2)} {m.group(3)};'
    assert not any(n in assigned for n in names), m.group(0)
    return m.group(0)
fsh = re.sub(r'^\s*((?:flat|noperspective|smooth)\s+)?in\s+(\w+)\s+([\w\s,]+);', deflat, fsh, flags=re.M)
# uniforms the vertex shader declares and the fragment shader doesn't
for m in re.finditer(r'^uniform\s+\w+\s+(\w+)\s*;', vsh, re.M):
    if not re.search(r'^uniform\s+\w+\s+' + m.group(1) + r'\b', fsh, re.M):
        fsh = m.group(0) + '\n' + fsh
fm = re.search(r'\bvoid main\s*\(\s*\)', fsh)
i = fsh.index('{', fm.end()) + 1
fsh = fsh[:i] + '\n    // (vertex shader)\n' + vbody + '\n    // (fragment shader)\n' + fsh[i:]
import os; sys.path.insert(0, os.path.dirname(__file__))
from defer_globals import defer
fsh, n = defer(fsh, '    // (fragment shader)', '    // (vertex shader)')
open(sys.argv[3], 'w').write(fsh)
