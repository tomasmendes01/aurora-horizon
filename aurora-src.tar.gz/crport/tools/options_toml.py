"""The pack's settings: options.wgsl (one `override` per option, shared by every stage) and the
[[options]] / [[pages]] of the manifest, laid out like Complementary's own settings screens, with its
names and descriptions (pt_BR, else en_US)."""
import json, os, re
PAGES = [
    ('main', 'Aurora', 2, ['PROFILE', 'SHADOW_DISTANCE', 'page:camera', 'page:lighting', 'page:atmosphere']),
    ('camera', 'CAMERA_SETTINGS', 2, ['page:tonemap', 'BLOOM_STRENGTH', 'LENSFLARE_MODE', 'LENSFLARE_I']),
    ('tonemap', 'TONEMAP_SETTINGS', 2, ['TM_EXPOSURE', 'TM_CONTRAST', 'T_SATURATION', 'T_VIBRANCE', 'TM_DARK_DESATURATION', 'TM_WHITE_PATH']),
    ('lighting', 'LIGHTING_SETTINGS', 2, ['page:blocklight', 'HZ_EMISSIVE_BRIGHTNESS', 'SSAO_I', 'VANILLAAO_I']),
    ('blocklight', 'BLOCKLIGHT_SETTINGS', 2, ['XLIGHT_I', 'XLIGHT_CURVE', '', '', 'XLIGHT_R', 'XLIGHT_G', 'XLIGHT_B']),
    ('atmosphere', 'ATMOSPHERE_SETTINGS', 2, ['page:clouds', 'page:fog', 'page:aurora', 'page:nether', 'page:end', 'STAR_BRIGHTNESS']),
    ('clouds', 'CLOUD_SETTINGS', 2, ['CLOUD_TRANSPARENCY', 'CLOUD_STRETCH', 'CLOUD_ROUNDNESS', 'CLOUD_NARROWNESS',
                                     'CLOUD_LIGHT_MULTIPLIER', 'CLOUD_AMBIENT_MULTIPLIER', '', '', 'CLOUD_R', 'CLOUD_G', 'CLOUD_B']),
    ('fog', 'FOG_SETTINGS', 2, ['ATM_FOG_MULT', 'ATM_FOG_ALTITUDE', 'ATMOSPHERIC_FOG_DENSITY', 'CAVE_FOG_DENSITY',
                                'BORDER_FOG_DENSITY_OVERWORLD', 'BORDER_FOG_DENSITY_NETHER', 'BORDER_FOG_DENSITY_END', '',
                                'LIGHTSHAFT_SUNSET_SATURATION', '', 'LIGHTSHAFT_NOON_I', 'LIGHTSHAFT_SUNSET_I',
                                'LIGHTSHAFT_NIGHT_I', 'LIGHTSHAFT_RAIN_I']),
    ('aurora', 'AURORA_SETTINGS', 2, ['AURORA_SNOWY_ONLY', '', 'AURORA_UP_I', 'AURORA_DOWN_I', 'AURORA_SIZE', 'AURORA_DRAW_DISTANCE', 'AURORA_NOISE_SCALE']),
    ('nether', 'NETHER_SETTINGS', 2, ['NETHER_VIEW_LIMIT', 'NETHER_BRIGHTNESS', 'NETHER_STORM_I', 'NETHER_STORM_LOWER_ALT', 'NETHER_STORM_HEIGHT']),
    ('end', 'END_SETTINGS', 2, ['END_BEAM_INTENSITY', 'END_BEAM_SCALE', 'END_BEAM_CENTER_ALT', 'END_BEAM_HEIGHT',
                                'END_STAR_INTENSITY', 'END_AMBIENT_I', 'END_SKY_FOG_INFLUENCE', 'E_SKY_COLORI', 'END_PORTAL_FOG_I']),
]
NAMES = {'END_PORTAL_FOG_I': 'Portal Glow', 'PROFILE': 'Profile', 'SHADOW_DISTANCE': 'Shadow Distance', 'AURORA_SNOWY_ONLY': 'Aurora Condition',
         'HZ_EMISSIVE_BRIGHTNESS': 'Emissive Brightness'}
DESCS = {
    'END_PORTAL_FOG_I': 'A faint orange fog around the exit portal at the centre of the End (not in the original; 0 turns it off).',
    'AURORA_SNOWY_ONLY': 'When the Aurora Borealis appears (at night only). The original also checks the moon phase, '
                         'which Horizon does not give shaders, so here it is every night or in snowy biomes.',
    'HZ_EMISSIVE_BRIGHTNESS': 'How far past white light-emitting blocks (glowstone, lava, torches...) shine, and so how much '
                              'they bloom. 1 is the original; 0 stops them at white.',
    'PROFILE': 'Complementary\'s quality presets. Here they set the light shaft quality (off below Medium), FXAA (off below '
               'Medium) and the cloud quality (lower on Potato and Very Low, higher on Ultra). Shadow Distance is its own setting.',
    'SHADOW_DISTANCE': 'How far shadows reach, in blocks. The original profiles use 64 (Potato, Very Low), 96 (Low), '
                       '128 (Medium), 192 (High, Very High) and 224 (Ultra).',
}

def lang(src):
    out = {}
    for f in ('en_US',):
        for l in open(f'{src}/lang/{f}.lang', encoding='utf-8', errors='replace'):
            if '=' in l and not l.startswith('#'):
                k, v = l.rstrip('\n').split('=', 1)
                v = re.sub('§.', '', v).strip()
                if v: out[k.strip()] = v
    return out

def q(s): return json.dumps(s, ensure_ascii=False)

def num(x, isint): return str(int(round(x))) if isint else repr(round(x, 6))

def build(pack, src, opts_path):
    opts = json.load(open(opts_path)); L = lang(src)
    on_page = [i for _, _, _, items in PAGES for i in items if i and not i.startswith('page:')]
    assert sorted(on_page) == sorted(opts), set(opts) ^ set(on_page)
    wgsl = ['// The pack settings (Complementary\'s own options, same names); each stage reads the ones it uses.']
    toml = []
    for n, o in opts.items():
        if o['type'] == 'choice':
            wgsl.append(f"override {n}: u32 = {o['default']}u;")
            toml.append('[[options]]\nid = ' + q(n) + '\nname = ' + q(L.get(f'option.{n}', NAMES.get(n, n))) +
                        (('\ndescription = ' + q(DESCS.get(n) or L.get(f'option.{n}.comment', ''))) if (DESCS.get(n) or L.get(f'option.{n}.comment')) else '') +
                        '\ntype = "choice"\nvalues = [' + ', '.join(q(v) for v in o['values']) + ']\ndefault = ' + q(o['values'][o['default']]) + '\n')
            continue
        isint = o['type'] == 'int'
        wgsl.append(f"override {n}: {'i32' if isint else 'f32'} = {num(o['default'], isint) if isint else num(o['default'], False) if '.' in num(o['default'], False) else num(o['default'], False) + '.0'};")
        desc = DESCS.get(n) or L.get(f'option.{n}.comment', '')
        if o['type'] != 'choice' and abs(o['default'] - o['original_default']) > 1e-9:
            desc = (desc + ' ' if desc else '') + f"(Complementary/Euphoria default: {num(o['original_default'], isint)})"
        toml.append('[[options]]\nid = ' + q(n) + '\nname = ' + q(NAMES.get(n) or L.get(f'option.{n}', n)) +
                    ('\ndescription = ' + q(desc[:400]) if desc else '') +
                    f"\ntype = \"{o['type']}\"\ndefault = {num(o['default'], isint)}\nmin = {num(o['min'], isint)}\nmax = {num(o['max'], isint)}" +
                    ('' if isint else f"\nstep = {num(o['step'], False)}") + '\n')
    for pid, key, cols, items in PAGES:
        name = L.get(f'screen.{key}', key)
        desc = L.get(f'screen.{key}.comment', '')
        toml.append(f'[[pages]]\nid = "{pid}"\nname = {q(name)}' + (f'\ndescription = {q(desc[:300])}' if desc else '') +
                    f'\ncolumns = {cols}\nitems = [' + ', '.join(q(i) for i in items) + ']\n')
    open(f'{pack}/options.wgsl', 'w').write('\n'.join(wgsl) + '\n')
    return '\n'.join(toml)
