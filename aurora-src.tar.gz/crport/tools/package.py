"""Zips a pack folder as Horizon does: files in path order, fixed dates. usage: package.py dir out"""
import zipfile, sys, os
d, out = sys.argv[1], sys.argv[2]
files = sorted(os.path.relpath(os.path.join(r, f), d).replace(os.sep, '/') for r, _, fs in os.walk(d) for f in fs)
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
    for f in files:
        i = zipfile.ZipInfo(f, (1980, 1, 1, 0, 0, 0)); i.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(i, open(os.path.join(d, f), 'rb').read())
print(out, os.path.getsize(out))
