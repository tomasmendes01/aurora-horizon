#!/bin/bash
# One post pass: program <p> (post/<p>.glsl), keeping only its output <k>, to post/hz_<name>.wgsl
# with the prefix <name>_. usage: post_build.sh p k name
set -e
D=$(dirname $0)/..
P=${HZ_POST_DIR:-$D/post}
python3 - "$P/$1.glsl" "$2" "$P/k_$3.glsl" <<'PY'
import re, sys
s = open(sys.argv[1]).read(); k = sys.argv[2]
s = re.sub(r'^(\s*)gl_FragData\[(\d)\]\s*=.*?;\s*$', lambda m: m.group(0) if m.group(2) == k else m.group(1) + '// (another pass writes this output)', s, flags=re.M)
if sys.argv[3].endswith('k_c1v.glsl'):
    # The light shafts factor's equilibrium (see gen_post.py's vl pass): every frame, one step of 1.
    for a, b in (('if (frameCounter % int(0.06666 / frameTimeSmooth + 0.5) == 0) {', 'if (true) {'),
                 ('vlFactor = min(vlFactor + OSIEBCA, 1.0);', 'vlFactor = min(vlFactor + 1.0, 1.0);'),
                 ('vlFactor = max(vlFactor - OSIEBCA * reduceAmount, 0.0);', 'vlFactor = max(vlFactor - 1.0 * reduceAmount, 0.0);')):
        assert s.count(a) <= 1, a
        s = s.replace(a, b)
open(sys.argv[3], 'w').write(s)
PY
$D/tools/build_stage.sh $P/k_$3.glsl frag $P/w_$3.wgsl
python3 $D/tools/wgsl_slim.py $P/w_$3.wgsl $P/s_$3.wgsl > /dev/null
HZ_GENERIC=1 python3 $D/tools/hzify.py $P/s_$3.wgsl $3_ $P/hz_$3.wgsl
