# Inline Iris "#include /..." and run the C preprocessor with Iris's defines: the GLSL a
# program actually compiles to with the pack's default settings.
import re, subprocess, sys, pathlib
ROOT = pathlib.Path(sys.argv[1])          # .../shaders
prog = sys.argv[2]                         # e.g. world0/gbuffers_terrain.fsh
extra = sys.argv[3:]                       # -DNAME=VAL ...
seen_once = set()
import os, json
# HZ_OPTS: the settings the pack exposes. Their #define becomes a uniform (hzopt_<NAME>, filled from the
# Horizon option of that name); a test of one in #if sees a non-default value, so the general code is kept.
OPTS = json.load(open(os.environ['HZ_OPTS'])) if os.environ.get('HZ_OPTS') else {}
def opt_line(line):
    m = re.match(r'(\s*#define\s+)(\w+)(\s+)(-?[\d.]+)(.*)', line)
    if m and m.group(2) in OPTS:
        return f'{m.group(1)}{m.group(2)}{m.group(3)}hzopt_{m.group(2)}{m.group(5)}'
    if re.match(r'\s*#\s*(if|elif)\b', line):
        for n, o in OPTS.items():
            if re.search(r'\b' + n + r'\b', line):
                if o.get('sentinel') is None: raise SystemExit(f'{n} is tested by #if: {line.strip()}')
                line = re.sub(r'\b' + n + r'\b', str(o['sentinel']), line)
    return line
def inline(path, depth=0):
    out = []
    for line in path.read_text(errors='replace').splitlines():
        if OPTS: line = opt_line(line)
        m = re.match(r'\s*#include\s+"(/[^"]+)"', line)
        if m:
            p = ROOT / m.group(1).lstrip('/')
            out.append(f'// >>> {m.group(1)}'); out.append(inline(p, depth+1)); out.append(f'// <<< {m.group(1)}')
        elif re.match(r'\s*#version', line) or re.match(r'\s*#extension', line):
            out.append('// ' + line)
        else:
            out.append(line)
    return '\n'.join(out)
src = inline(ROOT / prog)
iris = ['-DIS_IRIS', '-DMC_VERSION=12111', '-DMC_GL_VENDOR_NVIDIA', '-DMC_GL_RENDERER_GEFORCE', '-DMC_OS_WINDOWS',
        '-DIRIS_VERSION=10800', '-DHZ_PORT', '-DMC_RENDER_QUALITY=1.0', '-DMC_SHADOW_QUALITY=1.0', '-DMC_RENDER_STAGE_NONE=0', '-DMC_RENDER_STAGE_SKY=1', '-DMC_RENDER_STAGE_SUNSET=2', '-DMC_RENDER_STAGE_CUSTOM_SKY=3', '-DMC_RENDER_STAGE_SUN=4', '-DMC_RENDER_STAGE_MOON=5', '-DMC_RENDER_STAGE_STARS=6', '-DMC_RENDER_STAGE_VOID=7', '-DMC_RENDER_STAGE_TERRAIN_SOLID=8', '-DMC_RENDER_STAGE_TERRAIN_CUTOUT_MIPPED=9', '-DMC_RENDER_STAGE_TERRAIN_CUTOUT=10', '-DMC_RENDER_STAGE_ENTITIES=11', '-DMC_RENDER_STAGE_BLOCK_ENTITIES=12', '-DMC_RENDER_STAGE_DESTROY=13', '-DMC_RENDER_STAGE_OUTLINE=14', '-DMC_RENDER_STAGE_DEBUG=15', '-DMC_RENDER_STAGE_HAND_SOLID=16', '-DMC_RENDER_STAGE_TERRAIN_TRANSLUCENT=17', '-DMC_RENDER_STAGE_TRIPWIRE=18', '-DMC_RENDER_STAGE_PARTICLES=19', '-DMC_RENDER_STAGE_CLOUDS=20', '-DMC_RENDER_STAGE_RAIN_SNOW=21', '-DMC_RENDER_STAGE_WORLD_BORDER=22', '-DMC_RENDER_STAGE_HAND_TRANSLUCENT=23']
r = subprocess.run(['cpp', '-P', '-undef', '-nostdinc', '-x', 'c', '-w'] + iris + extra + ['-'],
                   input=src, capture_output=True, text=True)
if r.returncode: print(r.stderr, file=sys.stderr); sys.exit(1)
o = r.stdout
if OPTS:
    used = [n for n in OPTS if re.search(r'\bhzopt_' + n + r'\b', o)]
    # A setting is no constant any more: a const that reads one becomes a plain variable.
    # (and so does a const that reads such a variable, however many steps away).
    ls = o.splitlines(); tainted = {'hzopt_' + n for n in used}; changed = True
    while changed:
        changed = False
        for i, l in enumerate(ls):
            if not re.search(r'\bconst\b', l): continue
            j, stmt = i, l
            while ';' not in stmt and j + 1 < len(ls): j += 1; stmt += ls[j]
            words = set(re.findall(r'\w+', stmt))
            if words & tainted or any(w.startswith('hzopt_') for w in words):
                ls[i] = re.sub(r'\bconst\s+', '', l, count=1)
                for name in re.findall(r'\b(?:const\s+)?(?:highp\s+|mediump\s+|lowp\s+)?\w+\s+(\w+)\s*(?:\[[^\]]*\])?\s*=', stmt):
                    tainted.add(name)
                changed = True
    o = '\n'.join(ls) + '\n'
    decl = ''.join(f"uniform {'float' if OPTS[n]['type'] == 'float' else 'int'} hzopt_{n};\n" for n in used)
    o = decl + o
sys.stdout.write(o)
