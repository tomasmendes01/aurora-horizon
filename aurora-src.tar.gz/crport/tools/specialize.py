# A GLSL function with a sampler parameter (`GetReflection(..., sampler2D depthtex, ...)`) is
# rewritten to use the texture its calls pass (here always one per program), the parameter and the
# argument removed: SPIR-V can't hand a combined sampler to a function in a form naga reads.
import re, sys
src = sys.stdin.read()

def args_span(s, open_idx):
    depth, j = 0, open_idx
    while True:
        c = s[j]
        if c == '(': depth += 1
        elif c == ')':
            depth -= 1
            if depth == 0: return j
        j += 1

def split_args(text):
    out, depth, cur = [], 0, ''
    for c in text:
        if c in '([': depth += 1
        if c in ')]': depth -= 1
        if c == ',' and depth == 0: out.append(cur); cur = ''
        else: cur += c
    out.append(cur)
    return out

sig = re.compile(r'\b(vec[234]|float|void|vec3|bool|int)\s+(\w+)\s*\(')
while True:
    changed = False
    for m in sig.finditer(src):
        name = m.group(2)
        close = args_span(src, m.end() - 1)
        params = split_args(src[m.end():close])
        idx = [i for i, p in enumerate(params) if re.search(r'\bsampler(2D|3D|2DShadow)\b', p)]
        if not idx or src[close + 1:close + 40].lstrip()[:1] != '{':
            continue
        i = idx[0]
        pname = params[i].split()[-1]
        # The calls, other than the definition.
        calls = [c for c in re.finditer(r'\b' + name + r'\s*\(', src) if c.start() != m.start() + m.group(0).index(name)]
        passed = set()
        for c in calls:
            cl = args_span(src, c.end() - 1)
            a = split_args(src[c.end():cl])
            if len(a) == len(params): passed.add(a[i].strip())
        if len(passed) != 1:
            print(f'// specialize: {name} gets {passed}', file=sys.stderr); continue
        glob = passed.pop()
        # The body: the parameter's uses become the global.
        body_open = src.index('{', close)
        depth, j = 0, body_open
        while True:
            if src[j] == '{': depth += 1
            elif src[j] == '}':
                depth -= 1
                if depth == 0: break
            j += 1
        body = re.sub(r'\b' + pname + r'\b', glob, src[body_open:j + 1])
        new_params = ','.join(p for k, p in enumerate(params) if k != i)
        head = src[m.start():m.end()] + new_params + ')'
        rest = src[j + 1:]
        # The calls after the definition (callers come later in GLSL).
        def fix(cm_src):
            out, pos = [], 0
            for c in re.finditer(r'\b' + name + r'\s*\(', cm_src):
                if c.start() < pos: continue
                cl = args_span(cm_src, c.end() - 1)
                a = split_args(cm_src[c.end():cl])
                if len(a) != len(params): continue
                out.append(cm_src[pos:c.end()]); out.append(','.join(x for k, x in enumerate(a) if k != i)); pos = cl
            out.append(cm_src[pos:])
            return ''.join(out)
        src = src[:m.start()] + head + src[close + 1:body_open] + body + fix(rest)
        changed = True
        break
    if not changed: break
sys.stdout.write(src)
