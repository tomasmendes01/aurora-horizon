# Combined GLSL samplers → a texture and a sampler (naga reads only those), each use becoming
# the in-place constructor: `uniform sampler2D tex;` → `uniform texture2D tex_t; uniform sampler
# tex_s;` + `#define tex sampler2D(tex_t, tex_s)`.
import re, sys
src = sys.stdin.read()
# GLSL 1.30's texture functions, by their modern names.
def wrap_vec4(src, fn, new):
    # `fn(args)` → `vec4(new(args))`: GLSL 1.30's shadow2D returned a vec4.
    out, i = [], 0
    pat = re.compile(r'\b' + fn + r'\s*\(')
    while True:
        m = pat.search(src, i)
        if not m: out.append(src[i:]); break
        out.append(src[i:m.start()]); j = m.end(); depth = 1
        while depth:
            depth += {'(': 1, ')': -1}.get(src[j], 0); j += 1
        out.append('vec4(' + new + '(' + src[m.end():j - 1] + '))'); i = j
    return ''.join(out)
src = wrap_vec4(src, 'shadow2DLod', 'textureLod')
src = wrap_vec4(src, 'shadow2D', 'texture')
for old, new in [('texture2DLod', 'textureLod'), ('texture2DGrad', 'textureGrad'), ('texture2D', 'texture'),
                 ('texture3D', 'texture'), ('texelFetch2D', 'texelFetch')]:
    src = re.sub(r'\b' + old + r'\s*\(', new + '(', src)
kinds = {'sampler2D': ('texture2D', 'sampler'), 'sampler3D': ('texture3D', 'sampler'),
         'sampler2DShadow': ('texture2D', 'samplerShadow'), 'usampler2D': ('utexture2D', 'sampler'),
         'isampler2D': ('itexture2D', 'sampler'), 'usampler3D': ('utexture3D', 'sampler')}
names = {}
def rep(m):
    kind, name = m.group(1), m.group(2)
    t, smp = kinds[kind]
    names[name] = kind
    return f'uniform {t} {name}_t; uniform {smp} {name}_s;'
# A function parameter of a sampler type: a texture and a sampler too.
def param(m):
    kind, name = m.group(1), m.group(2)
    t, smp = kinds[kind]
    names[name] = kind
    return f'{t} {name}_t, {smp} {name}_s'
src = re.sub(r'(?<![\w])(sampler2DShadow|sampler2D|sampler3D|usampler2D)\s+(\w+)(?=\s*[,)])', param, src)
src = re.sub(r'\buniform\s+(sampler2DShadow|sampler2D|sampler3D|usampler2D|isampler2D|usampler3D)\s+(\w+)\s*;', rep, src)
# Each use as a texture function's first argument becomes the constructor (a local variable of the
# same name, which Complementary has, e.g. `specular`, is left alone).
fns = r'(texture|textureLod|textureGrad|texelFetch|textureSize|textureGather|textureOffset|textureLodOffset|textureProj|textureQueryLod|texelFetchOffset|textureGatherOffset)'
def call(m):
    name = m.group(2)
    if name not in names: return m.group(0)
    return f'{m.group(1)}({names[name]}({name}_t, {name}_s),'
src = re.sub(fns + r'\s*\(\s*(\w+)\s*,', call, src)
src = re.sub(r'textureSize\s*\(\s*(\w+)\s*\)', lambda m: f'textureSize({names[m.group(1)]}({m.group(1)}_t, {m.group(1)}_s))' if m.group(1) in names else m.group(0), src)
# A sampler passed on to a function: its texture and its sampler.
if names:
    alt = '|'.join(sorted(names, key=len, reverse=True))
    src = re.sub(r'(?<=[(,])(\s*)(' + alt + r')(\s*)(?=[,)])', lambda m: f'{m.group(1)}{m.group(2)}_t, {m.group(2)}_s{m.group(3)}', src)
sys.stdout.write(src)
