# For naga's GLSL frontend: loose uniforms → one block `CrUniforms` (members still read by bare
# name), every texture and sampler given a binding, and initializers on uniforms dropped.
import re, sys
s = sys.stdin.read()
members, out, binding = [], [], 1
for line in s.split('\n'):
    m = re.match(r'^\s*uniform\s+(texture2D|texture3D|utexture2D|itexture2D|utexture3D|sampler|samplerShadow)\s+(\w+)\s*;\s*uniform\s+(sampler|samplerShadow)\s+(\w+)\s*;\s*$', line)
    if m:
        out.append(f'layout(binding={binding}) uniform {m.group(1)} {m.group(2)}; layout(binding={binding+1}) uniform {m.group(3)} {m.group(4)};')
        binding += 2; continue
    m = re.match(r'^\s*uniform\s+(\w+)\s+([\w\[\]]+)\s*(=[^;]*)?;\s*$', line)
    if m:
        members.append(f'    {m.group(1)} {m.group(2)};'); continue
    out.append(line)
body = '\n'.join(out)
block = 'layout(std140, binding=0) uniform CrUniforms {\n' + '\n'.join(dict.fromkeys(members)) + '\n};\n'
# After the structs the compatibility header declares.
k = body.find('struct cr_FogParameters')
i = body.index('\n', k) + 1 if k >= 0 else body.index('\n') + 1
sys.stdout.write(body[:i] + block + body[i:])
