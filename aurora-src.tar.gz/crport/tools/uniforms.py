"""Iris's (and Complementary's own) uniforms as WGSL from Horizon's `frame`, and the code that
fills a translated program's uniform block with them.
Complementary's smoothed uniforms (`smooth(...)` in shaders.properties) take Horizon's eased
values where it has them; a uniform Horizon has nothing for is 0 (listed by `missing`)."""
import re

F = 'frame'
MAP = {
    'hzDimension': f'{F}.dimension',  # merge_dims.py: which dimension's code runs

    # Euphoria Patches' (shaders.properties:575-685) and Iris's player ones, converged; biomes Horizon
    # doesn't give are 0.
    'bedrockLevel': f'select(0i, -64i, {F}.dimension == 0i)', 'currentPlayerArmor': '0.0',
    'eyeBrightnessSmooth': f'vec2<i32>(floor({F}.eye_light_smooth * 240.0))',
    'eyeBrightnessXM': f'{F}.eye_light_smooth.x', 'eyeBrightnessXM2_': f'select(0.0, 1.0, {F}.eye_light_smooth.x > 0.996)',
    'firstPersonCamera': '1u', 'hideGUI': f'i32({F}.hide_gui)', 'isOnGround': '1u', 'isRightHanded': '1u',
    'isShockwave': '0.0', 'isSneaking': '0.0', 'isSprinting': '0.0',
    'inDappledForest': '0.0', 'inForest': '0.0', 'inJungle': '0.0', 'inLushCave': '0.0', 'inRedSand': '0.0', 'inSand': '0.0',
    'inVanillaEnd': f'select(0.0, 1.0, {F}.dimension == 1i)',
    'lightningFlashOptifine': f'select(0.0, 1.0, abs({F}.sky_color.r - {F}.sky_color.g) <= 0.01 && {F}.sky_color.r > 0.3)',
    'shaderStart': f'f32({F}.frame_index)', 'shaderStartSmooth': f'clamp(({F}.time - 4.5) / 20.0, 0.0, 1.0)',
    'texelSize': f'1.0 / {F}.resolution', 'viewSize': f'{F}.resolution', 'thunderFactor': f'{F}.thunder',
    'waterAltitude': f'select(61.9, {F}.camera_position.y - 1.0, {F}.eye_in == 1u)',
    'worldAgeSmooth': f'{F}.day_time * 24000.0', 'worldTimeSmooth': f'{F}.day_time * 24000.0',

    'heavyFog': '0u', 'isElytraFlying': '0u', 'is_invisible': '0u',
    'blockEntityId': '-1i', 'currentRenderedItemId': '0i', 'entityId': '0i',
    'frameCounter': f'i32({F}.frame_index % 720720u)',
    'heldBlockLightValue': '0i', 'heldBlockLightValue2_': '0i', 'heldItemId': '0i', 'heldItemId2_': '0i',
    'isEyeInWater': f'i32({F}.eye_in)',
    'moonPhase': '0i', 'worldDay': '0i',
    'worldTime': f'i32({F}.day_time * 24000.0)',  # Iris: the day's time, 0 at sunrise
    'aspectRatio': f'{F}.resolution.x / {F}.resolution.y',
    'blindness': f'{F}.blindness', 'darknessFactor': f'{F}.darkness', 'darknessLightFactor': '0.0',
    'maxBlindnessDarkness': f'max({F}.blindness, {F}.darkness)',
    'eyeAltitude': f'{F}.camera_position.y',
    'frameTime': f'{F}.delta_time', 'frameTimeCounter': f'{F}.time', 'frameTimeSmooth': f'{F}.delta_time',
    'far': f'{F}.render_distance',  # Iris: the chunk render distance in blocks, not the projection's far plane
    'near': 'hz_near', 'nightVision': f'{F}.night_vision',
    'rainStrength': f'{F}.rain', 'rainFactor': f'{F}.rain', 'wetness': f'{F}.wetness',
    'screenBrightness': f'{F}.brightness',
    'viewWidth': f'{F}.resolution.x', 'viewHeight': f'{F}.resolution.y',
    'sunAngle': 'hz_sun_angle()', 'playerMood': '0.0', 'cloudHeight': '192.0', 'velocity': '0.0', 'starter': '1.0',
    'atlasSize': 'vec2<i32>(16i)',
    'eyeBrightness': f'vec2<i32>({F}.eye_light * 240.0)',
    'eyeBrightnessM': f'{F}.eye_light_smooth.y',
    'eyeBrightnessM2_': f'select(0.0, 1.0, {F}.eye_light_smooth.y > 0.996)',
    'isEyeInCave': f'select(0.0, select(0.0, 1.0 - {F}.eye_light_smooth.y, {F}.camera_position.y < 5.0), {F}.eye_in == 0u)',
    'cameraPosition': f'{F}.camera_position',
    'previousCameraPosition': f'{F}.camera_position - {F}.camera_motion',
    'cameraPositionInt': f'vec3<i32>(floor({F}.camera_position))',
    'cameraPositionFract': f'fract({F}.camera_position)',
    'previousCameraPositionInt': f'vec3<i32>(floor({F}.camera_position - {F}.camera_motion))',
    'previousCameraPositionFract': f'fract({F}.camera_position - {F}.camera_motion)',
    'eyePosition': f'{F}.camera_position', 'relativeEyePosition': 'vec3<f32>(0.0)',
    'playerLookVector': f'({F}.view_inverse * vec4<f32>(0.0, 0.0, -1.0, 0.0)).xyz',
    'fogColor': f'{F}.fog_color', 'skyColor': f'{F}.sky_color',
    'entityColor': 'vec4<f32>(0.0)', 'lightningBoltPosition': 'vec4<f32>(0.0)',
    'gbufferModelView': f'{F}.view', 'gbufferModelViewInverse': f'{F}.view_inverse',
    'gbufferPreviousModelView': f'{F}.view',
    'gbufferProjection': 'hz_projection()', 'gbufferProjectionInverse': 'hz_projection_inverse()',
    'gbufferPreviousProjection': 'hz_projection()',
    'shadowModelView': 'hz_shadow_model_view()', 'shadowModelViewInverse': 'transpose(hz_shadow_model_view())',
    'shadowProjection': 'hz_shadow_projection()', 'shadowProjectionInverse': 'hz_inverse(hz_shadow_projection())',
    'renderStage': '0i', 'endFlashIntensityM': '0.0', 'endFlashPosition': 'vec3<f32>(0.0)',
    'framemod2_': f'f32({F}.frame_index % 2u)', 'framemod4_': f'f32({F}.frame_index % 4u)',
    'framemod8_': f'f32({F}.frame_index % 8u)', 'framemod600_': f'f32({F}.frame_index % 600u)',
    'inDry': f'select(0.0, 1.0, {F}.precipitation == 0u)',
    'inRainy': f'select(0.0, 1.0, {F}.precipitation == 1u)',
    'inSnowy': f'select(0.0, 1.0, {F}.precipitation == 2u)',
    'inBasaltDeltas': 'hz_nether_biome(3i)', 'inCrimsonForest': 'hz_nether_biome(1i)', 'inNetherWastes': 'hz_nether_biome(0i)',
    'inSoulValley': 'hz_nether_biome(4i)', 'inWarpedForest': 'hz_nether_biome(2i)', 'inPaleGarden': '0.0', 'inSulfurCaves': '0.0',
}
NO_HORIZON = ['heldBlockLightValue', 'heldItemId', 'moonPhase', 'worldDay', 'darknessLightFactor', 'playerMood',
              'velocity', 'entityColor', 'lightningBoltPosition', 'inPaleGarden', 'inSulfurCaves']

def fields(src, prefix):
    body = re.search(r'^struct ' + prefix + r'gl_DefaultUniformBlock \{\n(.*?)^\}', src, re.S | re.M).group(1)
    return [(m.group(1), m.group(2).strip()) for m in
            re.finditer(r'^\s*(?:@\w+\(\d+\)\s*)*(\w+): ([^,]+),?\s*$', body, re.M)]

def used(src, prefix, name):
    """Whether the program reads the uniform (naga keeps every member a block declares)."""
    return re.search(r'\b' + prefix + r'unnamed\.' + name + r'\b', src) is not None

def fill(src, prefix, overrides=None, usage=None):
    """`fn {prefix}fill()`: the program's uniform block from the frame (the members it reads)."""
    o = dict(MAP, **(overrides or {}))
    lines = [f'fn {prefix}fill() {{']
    for name, ty in fields(src, prefix):
        if not used(usage if usage is not None else src, prefix, name):
            continue
        if name == 'cr_Fog':
            lines.append(f'    {prefix}unnamed.cr_Fog = {ty}(vec4<f32>({F}.fog_color, 1.0), 0.0, {F}.fog_start, {F}.fog_end, 1.0 / max({F}.fog_end - {F}.fog_start, 0.001));')
            continue
        if name.startswith('hzopt_'):
            lines.append(f'    {prefix}unnamed.{name} = {name[6:]};')
            continue
        if name not in o:
            raise SystemExit(f'{prefix}: no value for the uniform {name}: {ty}')
        lines.append(f'    {prefix}unnamed.{name} = {o[name]};')
    lines.append('}')
    return '\n'.join(lines) + '\n'
