# The vertex program's DoWave alone, as a small vertex shader: the program before `void main()`
# with its own attributes and varyings removed, and a main that moves one corner.
import re, sys
s = open(sys.argv[1]).read()
s = s[:s.index('void main()')]
# Varyings become ordinary globals (the functions read some, like lmCoord); attributes go.
s = re.sub(r'^\s*attribute\s+\w+\s+[\w, ]+;\s*$', '', s, flags=re.M)
s = re.sub(r'^(\s*)(flat\s+)?(out|in|varying)\s+(\w+\s+[\w, ]+;)\s*$', r'\1\4', s, flags=re.M)
s = s.replace('glColorRaw.rgb = min(glColorRaw.rgb, vec3(0.9));', '')
head = '''layout(location=0) in vec3 hz_pos;
layout(location=1) in vec2 hz_uv;
layout(location=2) in int hz_mat;
layout(location=3) in vec2 hz_light;
layout(location=0) out vec3 hz_out;
#define gl_MultiTexCoord0 vec4(hz_uv, 0.0, 1.0)
#define mc_midTexCoord vec4(0.5, 0.5, 0.0, 1.0)
#define gl_TextureMatrix mat4[2](mat4(1.0), mat4(1.0))
#define gl_MultiTexCoord1 vec4(0.0)

'''
tail = '''
void main() {
    lmCoord = hz_light;
    vec3 p = hz_pos;
    DoWave(p, hz_mat);
    hz_out = p;
    gl_Position = vec4(p, 1.0);
}
'''
sys.stdout.write(head + s + tail)
