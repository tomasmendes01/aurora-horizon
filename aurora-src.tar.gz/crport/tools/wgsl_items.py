"""Top-level items of a WGSL module, and pruning to what some roots use."""
import re

def items_of(text):
    # Top-level items start at brace depth 0 with a declaration; comments just above join it.
    items, depth, cur = [], 0, []
    for line in text.split('\n'):
        decl = re.match(r'\s*(fn|struct|const|override|alias|var)\b', line) if depth == 0 else None
        com = line.lstrip().startswith('//')
        if depth == 0 and (decl or com) and cur and not (decl and cur[-1].lstrip().startswith('//')) \
                and not (com and cur[-1].lstrip().startswith('//')):
            items.append('\n'.join(cur)); cur = []
        cur.append(line)
        depth += line.count('{') - line.count('}')
    items.append('\n'.join(cur))
    return [i for i in items if i.strip()]

def item_name(it):
    for line in it.split('\n'):
        if line.lstrip().startswith('//') or not line.strip(): continue
        m = re.match(r'\s*(?:fn|struct|const|override|alias|var(?:<\w+>)?)\s+(\w+)', line)
        return m.group(1) if m else None

def needed(items, roots):
    byname = {item_name(i): i for i in items}
    need, todo = set(roots), list(roots)
    while todo:
        n = todo.pop()
        for w in set(re.findall(r'(?<![.\w])\w+\b', byname[n])):
            if w in byname and w not in need:
                need.add(w); todo.append(w)
    return need

def prune(text, roots):
    items = items_of(text)
    need = needed(items, roots)
    return '\n'.join(i for i in items if item_name(i) in need) + '\n'
