"""Shrinks naga's WGSL from SPIR-V without changing what it computes, to fit Horizon's per-stage
expression limit:
1. A `ptr<function, T>` parameter the function only reads becomes a `T` value (GLSL's `in`
   parameters, which glslang passes by pointer).
2. A call's argument `(&param_N)` for such a parameter becomes the value stored in `param_N`
   just before, when `param_N` has no other use; the temporary goes.
usage: wgsl_slim.py in.wgsl out.wgsl
"""
import re, sys

src = open(sys.argv[1]).read()
FN = re.compile(r'^fn (\w+)\((.*?)\)( -> [^{]+)? \{\n(.*?)^\}\n', re.S | re.M)

def params_of(text):
    out, depth, cur = [], 0, ''
    for c in text:
        if c in '<(': depth += 1
        if c in '>)': depth -= 1
        if c == ',' and depth == 0: out.append(cur.strip()); cur = ''
        else: cur += c
    if cur.strip(): out.append(cur.strip())
    return out

converted = {}   # function → set of parameter indices made values
def rewrite_fn(m):
    name, plist, ret, body = m.group(1), m.group(2), m.group(3) or '', m.group(4)
    params = params_of(plist)
    idx = set()
    for i, p in enumerate(params):
        pm = re.match(r'(\w+): ptr<function, (.+)>$', p)
        if not pm: continue
        pn, ty = pm.groups()
        uses = re.findall(r'(.)\b' + pn + r'\b(.)', body)
        reads = len(re.findall(r'\(\*' + pn + r'\)', body))
        writes = re.search(r'\(\*' + pn + r'\)(\.\w+|\[[^\]]+\])*\s*=[^=]', body)
        if reads == len(uses) and not writes:
            body = body.replace('(*' + pn + ')', pn)
            params[i] = f'{pn}: {ty}'
            idx.add(i)
    if idx: converted[name] = idx
    return f'fn {name}(' + ', '.join(params) + ')' + ret + ' {\n' + body + '}\n'

src = FN.sub(rewrite_fn, src)

# Call sites: `name(args)` with a converted index → the value.
def split_args(text):
    out, depth, cur = [], 0, ''
    for c in text:
        if c in '([': depth += 1
        if c in ')]': depth -= 1
        if c == ',' and depth == 0: out.append(cur.strip()); cur = ''
        else: cur += c
    if cur.strip(): out.append(cur.strip())
    return out

def fix_calls(text):
    out, pos = [], 0
    pat = re.compile(r'\b(' + '|'.join(map(re.escape, converted)) + r')\(') if converted else None
    if not pat: return text
    for m in pat.finditer(text):
        if m.start() < pos: continue
        if text[max(0, m.start() - 3):m.start()] == 'fn ': continue
        j, depth = m.end(), 1
        while depth:
            depth += {'(': 1, ')': -1}.get(text[j], 0); j += 1
        args = split_args(text[m.end():j - 1])
        for i in converted[m.group(1)]:
            if i < len(args):
                a = args[i]
                am = re.fullmatch(r'\(&(\w+)\)', a)
                args[i] = am.group(1) if am else '(*' + a + ')' if a.startswith('(') or re.fullmatch(r'\w+', a) else a
        out.append(text[pos:m.end()] + ', '.join(args) + ')'); pos = j
    out.append(text[pos:])
    return ''.join(out)

src = fix_calls(src)

# Temporaries `param_N` now read once: their stored value in place, the store and declaration gone.
def inline_params(fn_body):
    for v in set(re.findall(r'\bvar (param\w*): ', fn_body)):
        stores = re.findall(r'^\s*' + v + r' = ([^;]+);\n', fn_body, re.M)
        reads = len(re.findall(r'\b' + v + r'\b', fn_body)) - 1 - len(stores)
        taken = re.search(r'&' + v + r'\b', fn_body)
        if not taken and len(stores) == 1 and reads == 1 and re.fullmatch(r'_e\d+|-?[\d.]+f?|[\w.]+', stores[0].strip()):
            fn_body = re.sub(r'^\s*' + v + r' = [^;]+;\n', '', fn_body, flags=re.M)
            fn_body = re.sub(r'^\s*var ' + v + r': [^;]+;\n', '', fn_body, flags=re.M)
            fn_body = re.sub(r'\b' + v + r'\b', stores[0].strip(), fn_body)
    return fn_body

src = FN.sub(lambda m: f'fn {m.group(1)}({m.group(2)}){m.group(3) or ""} {{\n' + inline_params(m.group(4)) + '}\n', src)
open(sys.argv[2], 'w').write(src)

# 3. A global no function writes (an input's copy, a uniform) read more than once in a function:
#    read once at the top of it, and each read refers to that (a `let` costs no expression).
src = open(sys.argv[2]).read()
globals_ = set(re.findall(r'^var(?:<private>|<uniform>)? (\w+): ', src, re.M))
written = set()
for fm in FN.finditer(src):
    if fm.group(1) == 'main':
        continue
    for g in globals_:
        if re.search(r'^\s*\(?\*?' + g + r'\b[^;\n=]*[^=!<>]=[^=]', fm.group(4), re.M):
            written.add(g)
readonly = globals_ - written
def hoist(m):
    name, body = m.group(1), m.group(4)
    if name == 'main':
        return m.group(0)
    lets = []
    for g in sorted(readonly):
        # Whole-value reads `let _eN = g;` and field reads `let _eN = g.field;`.
        for full in sorted(set(re.findall(r'= (' + g + r'(?:\.\w+)?);\n', body))):
            n = len(re.findall(r'= ' + re.escape(full) + r';\n', body))
            if n >= 2:
                h = 'hz_' + full.replace('.', '_')
                lets.append(f'    let {h} = {full};\n')
                body = re.sub(r'= ' + re.escape(full) + r';\n', f'= {h};\n', body)
    if not lets:
        return m.group(0)
    # After the function's own `var` declarations.
    lines = body.split('\n')
    k = 0
    while k < len(lines) and re.match(r'\s*var ', lines[k]):
        k += 1
    body = '\n'.join(lines[:k]) + ('\n' if k else '') + ''.join(lets) + '\n'.join(lines[k:])
    return f'fn {name}({m.group(2)}){m.group(3) or ""} {{\n' + body + '}\n'
src = FN.sub(hoist, src)
open(sys.argv[2], 'w').write(src)
