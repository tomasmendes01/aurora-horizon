"""deferred1, composite and composite1: original vs port, with the gbuffers' outputs both sides
get (Iris: colortex4/6; Horizon: set_surface)."""
import sys
exec(open('cmp_post.py').read().replace("if __name__ == '__main__':", "if False:"))

def surface(sc, hz_depth, normal=(0, 1, 0), smooth=0.3, mask=0.0, skyl=1.0):
    """Iris's colortex4 / colortex6 and Horizon's scene_surface for the ground (GL rows)."""
    H, W = sc.H, sc.W
    ground = hz_depth > 0
    n = np.asarray(normal, np.float32)
    c4 = np.zeros((H, W, 4), np.float32); c6 = np.zeros((H, W, 4), np.float32); c6[..., 3] = 1
    c4[ground] = np.round(np.append(n, 1.0) * 127) / 127
    c6[ground] = [q8(np.array([smooth]))[0], round(mask * 255) / 255, round(skyl * 255) / 255, 1.0]
    # octahedral normal, as Horizon packs it: (x, z) / (|x|+|y|+|z|)
    o = n / np.abs(n).sum()
    ex, ez = (o[0], o[2]) if o[1] >= 0 else ((1 - abs(o[2])) * np.sign(o[0]), (1 - abs(o[0])) * np.sign(o[2]))
    packed = (np.uint32(np.int32(round(np.clip(ex, -1, 1) * 32767)) & 0xffff) | (np.uint32(np.int32(round(np.clip(ez, -1, 1) * 32767)) & 0xffff) << 16))
    s = np.zeros((H, W, 4), np.uint32)
    s[..., 0] = np.where(ground, packed, 0)
    s[..., 1] = np.where(ground, np.float32(smooth).view(np.uint32), 0)
    data = np.float32(round(mask * 255) * 256 + round(skyl * 255))
    s[..., 2] = np.where(ground, data.view(np.uint32), 0)
    s[..., 3] = np.where(ground, hz_depth.astype(np.float32).view(np.uint32), 0)
    return c4, c6, s

def run_pass(sc, prog, wgsl, iris_tex, hz_tex, outputs, idx, fmt, surf, chain=()):
    gl, hz = sc.depths()
    it = dict(depthtex0=(gl, 'depth'), depthtex1=(gl, 'depth'), noisetex=(noise, 'repeat'),
              shadowtex0=(np.ones((2048, 2048), np.float32), 'shadow'), shadowtex1=(np.ones((2048, 2048), np.float32), 'shadow'),
              shadowcolor0=(np.ones((64, 64, 4), np.float32), 'linear'), shadowcolor1=(np.full((64, 64, 4), 0.25, np.float32), 'linear'))
    it.update(iris_tex)
    ref = irisref.run(ROOT, prog, sc.W, sc.H, sc.iris(), it, outputs)
    views = common_views(sc, hz, hz_tex)
    views['scene_surface'] = postrun.tex(flip(surf), wgpu.TextureFormat.rgba32uint)
    for cw_, target in chain:
        views[target] = postrun.tex(postrun.run(cw_, sc.W, sc.H, sc.frame_buf(), views))
    out = flip(postrun.run(wgsl, sc.W, sc.H, sc.frame_buf(), views))
    return fmt(ref[idx]), out, ref

if __name__ == '__main__':
    for ticks in (int(a) for a in (sys.argv[1:] or ['6000', '12300', '18000'])):
        sc = Scene(ticks=ticks)
        H, W = sc.H, sc.W
        gl, hz = sc.depths()
        c4, c6, surf = surface(sc, hz)
        c0 = picture(H, W, 0.6); c0[gl >= 1.0] = [0.4, 0.55, 0.9, 1]
        r11 = lambda a: np.concatenate([np.maximum(a[..., :3], 0), np.ones_like(a[..., :1])], -1)
        it = {'colortex0': (c0, 'linear'), 'colortex3': (cw, 'repeat'), 'colortex4': (c4, 'linear'), 'colortex6': (c6, 'linear'),
              'colortex5': (np.zeros((H, W, 4), np.float32), 'linear'), 'cloudWaterTex': (cw, 'repeat')}
        hzt = {'scene_color': c0}
        r, p, ref = run_pass(sc, DIMDIR + '/deferred1', '/tmp/composed/post/01_d1.wgsl', it, hzt, [0, 5, 4], 0, r11, surf)
        print(f'--- ticks {ticks}')
        compare('deferred1 colortex0', r[..., :3], p[..., :3])
        r5, p5, _ = run_pass(sc, DIMDIR + '/deferred1', '/tmp/composed/post/02_d5.wgsl', it, hzt, [0, 5, 4], 5, q8, surf)
        compare('deferred1 colortex5', r5, p5)
        r4, p4, _ = run_pass(sc, DIMDIR + '/deferred1', '/tmp/composed/post/03_d4.wgsl', it, hzt, [0, 5, 4], 4, lambda a: np.round(np.clip(a, -1, 1) * 127) / 127, surf)
        compare('deferred1 colortex4', r4, p4)
        np.save(f'/tmp/d1_{ticks}.npy', np.stack([r, p]))
        # composite (reflections) and composite1 (light shafts, fog), each from the reference's inputs
        R0 = r11(ref[0]); R5 = q8(ref[5]); R4 = np.round(np.clip(np.nan_to_num(ref[4]), -1, 1) * 127) / 127
        z4 = np.zeros((H, W, 4), np.float32)
        itc = {'colortex0': (R0, 'linear'), 'colortex1': (R4, 'linear'), 'colortex4': (R4, 'linear'), 'colortex5': (R5, 'linear'),
               'colortex6': (c6, 'linear'), 'colortex7': (z4, 'linear'), 'colortex3': (z4, 'linear')}
        rc, pc, refc = run_pass(sc, DIMDIR + '/composite', '/tmp/composed/post/04_c7.wgsl', itc, {'ta': R0, 'tb': R5, 'tc': R4}, [7, 1], 7, lambda a: a, surf)
        compare('composite colortex7', rc, pc)
        np.save(f'/tmp/c7_{ticks}.npy', np.stack([rc, pc]))
        R7 = refc[7]
        it1 = dict(itc); it1['colortex7'] = (R7, 'linear')
        r1, p1, ref1 = run_pass(sc, DIMDIR + '/composite1', '/tmp/composed/post/05_c1.wgsl', it1, {'ta': R0, 'tb': R5, 'tc': R4, 'previous': R7}, [0, 5], 0, r11, surf)
        compare('composite1 colortex0', r1[..., :3], p1[..., :3])
        np.save(f'/tmp/c1_{ticks}.npy', np.stack([r1, p1]))
