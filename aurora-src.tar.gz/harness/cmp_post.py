"""Original program (Iris, OpenGL) vs the port's pass (Horizon, wgpu) on the same scene and buffers."""
import numpy as np, sys, wgpu
from PIL import Image
import irisref, postrun
from scene import Scene
import os
ROOT = os.environ.get('HZ_ROOT', '../cr_full/shaders')
DIMDIR = os.environ.get('HZ_DIM', 'world0')
rng = np.random.default_rng(7)
noise = np.asarray(Image.open(ROOT + '/lib/textures/noise.png').convert('RGBA'), np.float32) / 255
cw = np.asarray(Image.open(ROOT + '/lib/textures/cloud-water.png').convert('RGBA'), np.float32) / 255

def q8(a): return np.floor(np.clip(a, 0, 1) * 255 + 0.5) / 255
def flip(a): return np.ascontiguousarray(a[::-1])

_dp = None
def depth_view(arr):
    """A Depth32Float texture holding arr (rows top first), written by a pass (copies can't)."""
    global _dp
    dev = postrun.dev
    h, w = arr.shape
    src = dev.create_texture(size=(w, h, 1), format=wgpu.TextureFormat.r32float, usage=postrun.TU.TEXTURE_BINDING | postrun.TU.COPY_DST)
    dev.queue.write_texture({'texture': src}, np.ascontiguousarray(arr, np.float32).tobytes(), {'bytes_per_row': w * 4}, (w, h, 1))
    if _dp is None:
        code = """
@group(0) @binding(0) var t: texture_2d<f32>;
@vertex fn vs(@builtin(vertex_index) i: u32) -> @builtin(position) vec4<f32> {
    let p = vec2<f32>(f32((i << 1u) & 2u), f32(i & 2u));
    return vec4<f32>(p * 2.0 - 1.0, 0.0, 1.0);
}
@fragment fn fs(@builtin(position) p: vec4<f32>) -> @builtin(frag_depth) f32 {
    return textureLoad(t, vec2<i32>(p.xy), 0).r;
}"""
        m = dev.create_shader_module(code=code)
        bgl = dev.create_bind_group_layout(entries=[{'binding': 0, 'visibility': wgpu.ShaderStage.FRAGMENT, 'texture': {'sample_type': 'unfilterable-float'}}])
        _dp = (dev.create_render_pipeline(layout=dev.create_pipeline_layout(bind_group_layouts=[bgl]), vertex={'module': m, 'entry_point': 'vs'},
            fragment={'module': m, 'entry_point': 'fs', 'targets': []},
            depth_stencil={'format': wgpu.TextureFormat.depth32float, 'depth_write_enabled': True, 'depth_compare': 'always'}), bgl)
    pipe, bgl = _dp
    t = dev.create_texture(size=(w, h, 1), format=wgpu.TextureFormat.depth32float, usage=postrun.TU.TEXTURE_BINDING | postrun.TU.RENDER_ATTACHMENT)
    bg = dev.create_bind_group(layout=bgl, entries=[{'binding': 0, 'resource': src.create_view()}])
    e = dev.create_command_encoder()
    rp = e.begin_render_pass(color_attachments=[], depth_stencil_attachment={'view': t.create_view(), 'depth_load_op': 'clear', 'depth_store_op': 'store', 'depth_clear_value': 0.0})
    rp.set_pipeline(pipe); rp.set_bind_group(0, bg); rp.draw(3); rp.end()
    dev.queue.submit([e.finish()])
    return t.create_view()

def compare(name, a, b):
    d = np.abs(a - b)
    print(f'{name:28s} max {d.max():.3g}  mean {d.mean():.3g}  >1e-4 {np.mean(d > 1e-4) * 100:.2f}%  >1/255 {np.mean(d > 1.01 / 255) * 100:.2f}%')
    return d

def common_views(sc, hz_depth, extra):
    W, H = sc.W, sc.H
    z = lambda c=4: np.zeros((H, W, c), np.float32)
    v = dict(scene_color=postrun.tex(z()), previous=postrun.tex(z()), history=postrun.tex(z()),
             scene_depth=depth_view(flip(hz_depth)),
             shadow_map=depth_view(np.ones((2048, 2048), np.float32)), shadow_map_translucent=depth_view(np.ones((2048, 2048), np.float32)),
             shadow_color=postrun.tex(np.ones((2048, 2048, 4), np.float32)),
             scene_surface=postrun.tex(np.zeros((H, W, 4), np.uint32), wgpu.TextureFormat.rgba32uint),
             noisetex=postrun.tex((noise * 255).astype(np.uint8), wgpu.TextureFormat.rgba8unorm),
             cloudwater=postrun.tex((cw * 255).astype(np.uint8), wgpu.TextureFormat.rgba8unorm),
             vl=postrun.tex(np.zeros((max(H // 4, 1), max(W // 4, 1), 4), np.float32)), ta=postrun.tex(z()), tb=postrun.tex(z()), tc=postrun.tex(z()))
    for k, a in extra.items():
        v[k] = postrun.tex(flip(a))
    return v

def picture(H, W, hdr=1.0, seed=0):
    """A structured picture (gradients, stripes, a disc, a little noise), like a frame, not white noise:
    white noise puts FXAA's comparisons on exact ties that rounding order flips."""
    r = np.random.default_rng(seed)
    y, x = np.mgrid[0:H, 0:W]
    img = np.zeros((H, W, 4), np.float32)
    img[..., 0] = x / W * 0.8 + 0.1
    img[..., 1] = ((x + y) % 37 < 18) * 0.6 + 0.15 + 0.05 * np.sin(y * 0.3)
    img[..., 2] = (((x - W * 0.3) ** 2 + (y - H * 0.45) ** 2) < (H * 0.28) ** 2) * 0.8 + 0.1
    img[..., :3] += r.random((H, W, 3)) * 0.03
    img[..., :3] *= hdr
    img[..., 3] = 1
    return img.astype(np.float32)

def case(prog, wgsl, sc, iris_tex, hz_tex, outputs, out_index, fmt, mipmapped=None, chain=()):
    gl, hz = sc.depths()
    it = dict(depthtex0=(gl, 'depth'), depthtex1=(gl, 'depth'), noisetex=(noise, 'repeat'))
    it.update(iris_tex)
    ref = irisref.run(ROOT, prog, sc.W, sc.H, sc.iris(), it, outputs, mipmapped=mipmapped)[out_index]
    views = common_views(sc, hz, hz_tex)
    for cw_, target in chain:  # earlier Horizon passes this one needs (rows top first)
        views[target] = postrun.tex(postrun.run(cw_, sc.W, sc.H, sc.frame_buf(), views))
    out = postrun.run(wgsl, sc.W, sc.H, sc.frame_buf(), views)
    port = flip(out)
    return fmt(ref), port

if __name__ == '__main__':
    sc = Scene()
    H, W = sc.H, sc.W
    c0 = (rng.random((H, W, 4)) * 2.0).astype(np.float32); c0[..., 3] = 1
    c3 = q8(rng.random((H, W, 4))).astype(np.float32)
    # composite5: colortex0 (HDR) + colortex3 (bloom tiles) -> colortex3
    r, p = case(DIMDIR + '/composite5', '/tmp/composed/post/09_c5.wgsl', sc, {'colortex0': (c0, 'linear'), 'colortex3': (c3, 'linear')},
                {'previous': c0, 'tc': c3}, [3], 3, lambda a: q8(a))
    compare('composite5 (tonemap, bloom)', r, p)
    # final: colortex3 -> screen
    r, p = case(DIMDIR + '/final', '/tmp/composed/post/11_fin.wgsl', sc, {'colortex3': (c3, 'linear')}, {'previous': c3}, [0], 0, lambda a: a)
    compare('final', r[..., :3], p[..., :3])
    # composite7 (FXAA): colortex3 -> colortex3
    c3p = q8(picture(H, W))
    r, p = case(DIMDIR + '/composite7', '/tmp/composed/post/10_c7f.wgsl', sc, {'colortex3': (c3p, 'linear')}, {'previous': c3p}, [3], 3, q8)
    compare('composite7 (FXAA)', r, p)
    # composite4 (bloom tiles): colortex0 with its mipmaps -> colortex3; Horizon: mipa, mipb, composite4
    c0b = (rng.random((H, W, 4)) ** 4 * 8.0).astype(np.float32); c0b[..., 3] = 1
    r, p = case(DIMDIR + '/composite4', '/tmp/composed/post/08_c4.wgsl', sc, {'colortex0': (c0b, 'linear')}, {'previous': c0b}, [3], 3, q8,
                mipmapped=['colortex0'], chain=[('/tmp/composed/post/06_mipa.wgsl', 'ta'), ('/tmp/composed/post/07_mipb.wgsl', 'tb')])
    compare('composite4 (bloom tiles)', r, p)

def where(d, thr=1.01 / 255):
    ys, xs = np.nonzero(d.max(-1) > thr)
    return list(zip(ys[:10], xs[:10])), (ys.min(), ys.max(), xs.min(), xs.max()) if len(ys) else None
