"""gbuffers_skybasic (Iris, drawn over the screen with vanilla's sky colour) vs the port's sky stage."""
import sys
exec(open('cmp_post.py').read().replace("if __name__ == '__main__':", "if False:"))
SKYCOL = (0.45, 0.6, 0.95, 1.0)
def sky_module():
    s = open('/tmp/composed/sky.wgsl').read()
    s += '''
struct HzOut { @builtin(position) p: vec4<f32> }
@vertex fn horizon_vs_post(@builtin(vertex_index) i: u32) -> HzOut {
    let q = vec2<f32>(f32((i << 1u) & 2u), f32(i & 2u));
    return HzOut(vec4<f32>(q * 2.0 - 1.0, 0.0, 1.0));
}
@fragment fn horizon_fs_post(@builtin(position) p: vec4<f32>) -> @location(0) vec4<f32> {
    let ndc = vec2<f32>(p.x / frame.resolution.x * 2.0 - 1.0, 1.0 - p.y / frame.resolution.y * 2.0);
    let v = frame.projection_inverse * vec4<f32>(ndc, 0.5, 1.0);
    let dir = (frame.view_inverse * vec4<f32>(v.xyz / v.w, 0.0)).xyz;
    return sky(SkyInput(normalize(dir), vec4<f32>(%f, %f, %f, %f)));
}
''' % SKYCOL
    open('/tmp/sky_test.wgsl', 'w').write(s)
    return '/tmp/sky_test.wgsl'

def iris_sky(sc):
    import moderngl
    ctx = irisref.ctx; ctx.__enter__()
    vs = irisref.vertex_patch(irisref.source(ROOT, DIMDIR + '/gbuffers_skybasic.vsh')).replace('gl_Color', 'vec4(%f, %f, %f, %f)' % SKYCOL)
    fs = irisref.source(ROOT, DIMDIR + '/gbuffers_skybasic.fsh')
    p = ctx.program(vertex_shader=vs, fragment_shader=fs)
    u = sc.iris(); u['renderStage'] = 0
    unit = 0
    for name in list(p):
        m = p[name]
        if not isinstance(m, moderngl.Uniform): continue
        if name == 'noisetex':
            t = ctx.texture((128, 128), 4, np.round(noise * 255).astype('u1').tobytes()); t.repeat_x = t.repeat_y = True
            t.use(unit); m.value = unit; unit += 1
        elif name in u:
            v = u[name]
            if isinstance(v, np.ndarray) and v.shape == (4, 4): m.write(np.asarray(v, 'f4').T.tobytes())
            else: m.value = v
        elif m.gl_type in (0x8B5E,):
            z = ctx.texture((1, 1), 4, np.zeros(4, 'f4').tobytes(), dtype='f4'); z.use(unit); m.value = unit; unit += 1
        else:
            print('unset', name)
    o = ctx.texture((sc.W, sc.H), 4, dtype='f4'); fbo = ctx.framebuffer(color_attachments=[o]); fbo.use(); fbo.clear()
    quad = ctx.buffer(np.array([0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 1, 1], 'f4').tobytes())
    ctx.vertex_array(p, [(quad, '2f', 'hzV')]).render(moderngl.TRIANGLES)
    return np.frombuffer(o.read(), 'f4').reshape(sc.H, sc.W, 4)

for ticks in (int(a) for a in (sys.argv[1:] or ['1000', '6000', '12300', '13000', '18000'])):
    for vd in ((-1, 0.15, 0.2), (1, 0.5, 0.0), (0.2, -0.3, -1)):
        sc = Scene(ticks=ticks, view_dir=vd)
        ref = iris_sky(sc)
        hz = flip(postrun.run(sky_module(), sc.W, sc.H, sc.frame_buf(), common_views(sc, sc.depths()[1], {})))
        compare(f'sky t={ticks} v={vd}', ref[..., :3], hz[..., :3])
        np.save(f'/tmp/sky_{ticks}.npy', np.stack([ref, hz]))
