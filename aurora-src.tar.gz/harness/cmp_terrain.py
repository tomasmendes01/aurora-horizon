"""gbuffers_terrain (Iris: the program drawing a ground of blocks) vs the port's material stage
(Horizon: MaterialInput for the same points), on the same scene."""
import sys, re, moderngl
exec(open('cmp_post.py').read().replace("if __name__ == '__main__':", "if False:"))
GROUND = -1.6

def sprite(seed=3):
    r = np.random.default_rng(seed)
    base = np.array([0.45, 0.62, 0.3]) if seed == 3 else np.array([0.5, 0.5, 0.5])
    img = np.clip(base + (r.random((16, 16, 1)) - 0.5) * 0.35, 0, 1)
    img = np.concatenate([img, np.ones((16, 16, 1))], -1)
    levels = [np.round(img * 255) / 255]
    while levels[-1].shape[0] > 1:  # vanilla's mip levels: 2x2 averages
        a = levels[-1]
        levels.append(np.round((a[0::2, 0::2] + a[1::2, 0::2] + a[0::2, 1::2] + a[1::2, 1::2]) / 4 * 255) / 255)
    return [l.astype(np.float32) for l in levels]

def ground_mesh(sc, extent=120):
    """Block-sized quads on the ground plane around the camera (camera-relative)."""
    cx, cz = sc.cam[0], sc.cam[2]
    xs = np.arange(np.floor(cx) - extent, np.floor(cx) + extent)
    zs = np.arange(np.floor(cz) - extent, np.floor(cz) + extent)
    X, Z = np.meshgrid(xs, zs)
    X, Z = X.ravel(), Z.ravel()
    corners = [(0, 0), (1, 0), (1, 1), (0, 0), (1, 1), (0, 1)]
    verts = []
    for dx, dz in corners:
        p = np.stack([X + dx - cx, np.full_like(X, GROUND), Z + dz - cz], -1)
        uv = np.stack([np.full_like(X, dx), np.full_like(X, dz)], -1)
        verts.append(np.concatenate([p, uv], -1))
    v = np.stack(verts, 1).reshape(-1, 5)
    return v.astype('f4')

def iris_terrain(sc, mat, tint, light, levels):
    ctx = irisref.ctx; ctx.__enter__()
    vs = irisref.source(ROOT, DIMDIR + '/gbuffers_terrain.vsh')
    rep = [('gl_TextureMatrix[0] * gl_MultiTexCoord0', 'vec4(hzUV, 0.0, 1.0)'), ('gl_TextureMatrix[0] * mc_midTexCoord', 'vec4(0.5, 0.5, 0.0, 1.0)'),
           ('(gl_TextureMatrix[1] * gl_MultiTexCoord1).xy', 'hzLM'), ('gl_MultiTexCoord0', 'vec4(hzUV, 0.0, 1.0)'),
           ('gl_Color', 'hzColor'), ('gl_NormalMatrix', 'mat3(gbufferModelView)'), ('gl_Normal', 'vec3(0.0, 1.0, 0.0)'),
           ('gl_ModelViewMatrix', 'gbufferModelView'), ('gl_ProjectionMatrix', 'gbufferProjection'), ('gl_Vertex', 'vec4(hzPos, 1.0)')]
    for a, b in rep: vs = vs.replace(a, b)
    v = re.search(r'^#define MC_RENDER_STAGE_HAND_TRANSLUCENT.*$', vs, re.M)
    vs = vs[:v.end()] + '\nin vec3 hzPos; in vec2 hzUV; uniform vec2 hzLM; uniform vec4 hzColor;\n' + vs[v.end():]
    vs = re.sub(r'^attribute vec4 mc_Entity;', 'vec4 mc_Entity = vec4(%d.0, 0.0, 0.0, 0.0);' % mat, vs, flags=re.M)
    vs = re.sub(r'^attribute vec4 mc_midTexCoord;', 'vec4 mc_midTexCoord = vec4(0.5, 0.5, 0.0, 1.0);', vs, flags=re.M)
    fs = irisref.source(ROOT, DIMDIR + '/gbuffers_terrain.fsh')
    p = ctx.program(vertex_shader=vs, fragment_shader=fs)
    u = sc.iris(); u['renderStage'] = 8; u['hzLM'] = (light[0] / 16 * 15 / 15 * 0.9375 + 0.03125, light[1] * 0.9375 + 0.03125); u['hzColor'] = tint
    u['hzLM'] = (light[0] * 0.9375 + 0.03125, light[1] * 0.9375 + 0.03125)
    unit = 0
    tex = ctx.texture((16, 16), 4, (levels[0] * 255).round().astype('u1').tobytes())
    tex.build_mipmaps(0, len(levels) - 1)
    for i, l in enumerate(levels[1:], 1):
        tex.write((l * 255).round().astype('u1').tobytes(), level=i)
    tex.filter = (moderngl.NEAREST_MIPMAP_LINEAR, moderngl.NEAREST); tex.repeat_x = tex.repeat_y = False
    for name in list(p):
        m = p[name]
        if not isinstance(m, moderngl.Uniform): continue
        if name in ('tex', 'gtexture'):
            tex.use(unit); m.value = unit; unit += 1
        elif name == 'noisetex' or name == 'gaux4':
            data = noise if name == 'noisetex' else cw
            t = ctx.texture((data.shape[1], data.shape[0]), 4, np.round(data * 255).astype('u1').tobytes()); t.repeat_x = t.repeat_y = True
            t.use(unit); m.value = unit; unit += 1
        elif name in ('shadowtex0', 'shadowtex1'):
            t = ctx.depth_texture((2048, 2048), np.ones(2048 * 2048, 'f4').tobytes()); t.compare_func = '<=' if m.gl_type == 0x8B62 else ''
            t.use(unit); m.value = unit; unit += 1
        elif m.gl_type in (0x8B5E, 0x8B62, 0x8B5F, 0x8DCA, 0x8DD2):
            z = ctx.texture((1, 1), 4, np.ones(4, 'f4').tobytes() if 'shadowcolor' in name else np.zeros(4, 'f4').tobytes(), dtype='f4') if m.gl_type != 0x8B5F else ctx.texture3d((1, 1, 1), 4, np.zeros(4, 'f4').tobytes(), dtype='f4')
            z.use(unit); m.value = unit; unit += 1
        elif name in u:
            val = u[name]
            if isinstance(val, np.ndarray) and val.shape == (4, 4): m.write(np.asarray(val, 'f4').T.tobytes())
            else: m.value = val
    outs = [ctx.texture((sc.W, sc.H), 4, dtype='f4') for _ in range(3)]
    depth = ctx.depth_renderbuffer((sc.W, sc.H))
    fbo = ctx.framebuffer(color_attachments=outs, depth_attachment=depth); fbo.use(); fbo.clear(0, 0, 0, 0, depth=1.0)
    ctx.enable(moderngl.DEPTH_TEST)
    vb = ctx.buffer(ground_mesh(sc).tobytes())
    ctx.vertex_array(p, [(vb, '3f 2f', 'hzPos', 'hzUV')]).render(moderngl.TRIANGLES)
    ctx.disable(moderngl.DEPTH_TEST)
    return [np.frombuffer(o.read(), 'f4').reshape(sc.H, sc.W, 4) for o in outs]

def port_terrain(sc, mat, tint, light, levels):
    s = open('/tmp/composed/material1.wgsl').read()
    s = s.replace('''fn horizon_block_sample(uv: vec2<f32>, layer: u32, lod: f32) -> vec4<f32> {
    return vec4<f32>(1.0);
}''', '''@group(3) @binding(40) var hz_sprite: texture_2d<f32>;
@group(3) @binding(41) var hz_sprite_s: sampler;
fn horizon_block_sample(uv: vec2<f32>, layer: u32, lod: f32) -> vec4<f32> {
    return textureSampleLevel(hz_sprite, hz_sprite_s, uv, lod);
}''')
    s += '''
struct HzOut { @builtin(position) p: vec4<f32> }
@vertex fn horizon_vs_post(@builtin(vertex_index) i: u32) -> HzOut {
    let q = vec2<f32>(f32((i << 1u) & 2u), f32(i & 2u));
    return HzOut(vec4<f32>(q * 2.0 - 1.0, 0.0, 1.0));
}
@fragment fn horizon_fs_post(@builtin(position) p: vec4<f32>) -> @location(0) vec4<f32> {
    let ndc = vec2<f32>(p.x / frame.resolution.x * 2.0 - 1.0, 1.0 - p.y / frame.resolution.y * 2.0);
    let v = frame.projection_inverse * vec4<f32>(ndc, 0.5, 1.0);
    let dir = (frame.view_inverse * vec4<f32>(v.xyz / v.w, 0.0)).xyz;
    let t = %f / min(dir.y, -1e-6);
    let pos = dir * t;
    let world = pos + frame.camera_position;
    let uv = vec2<f32>(world.x - floor(world.x), world.z - floor(world.z));
    // the mip level, as horizon_material_color finds it
    let texels = world.xz * 16.0;
    let fp = max(dot(dpdx(texels), dpdx(texels)), dot(dpdy(texels), dpdy(texels)));
    horizon_block_lod = max(0.5 * log2(max(fp, 1e-8)), 0.0);
    if dir.y >= -1e-4 || length(pos.xz) > 119.0 || abs(pos.x) > 119.0 || abs(pos.z) > 119.0 { return vec4<f32>(0.0); }
    let input = MaterialInput(horizon_block_sample(uv, 0u, horizon_block_lod), vec4<f32>(%f, %f, %f, %f), vec2<f32>(%f, %f), vec3<f32>(1.0), pos, uv,
        false, 0u, %du, p.xy / frame.resolution, 0u, 0u, 0.0, vec3<f32>(0.0, 1.0, 0.0), vec4<f32>(1.0, 0.0, 0.0, -1.0), vec3<f32>(0.0), 0.0);
    // with the HDR scale the material stage stored in set_surface's smoothness (gen_material.py)
    let r = material(input);
    return vec4<f32>(r.color.rgb * max(floor(horizon_surface.y / 2.0) / 8.0, 1.0), r.color.a);
}
''' % ((GROUND,) + tuple(tint) + tuple(light) + (mat,))
    open('/tmp/terrain_test.wgsl', 'w').write(s)
    views = common_views(sc, sc.depths()[1], {})
    dev = postrun.dev
    t = dev.create_texture(size=(16, 16, 1), format=wgpu.TextureFormat.rgba8unorm, mip_level_count=len(levels), usage=postrun.TU.TEXTURE_BINDING | postrun.TU.COPY_DST)
    for i, l in enumerate(levels):
        h, w = l.shape[:2]
        dev.queue.write_texture({'texture': t, 'mip_level': i}, (l * 255).round().astype(np.uint8).tobytes(), {'bytes_per_row': w * 4}, (w, h, 1))
    views['hz_sprite'] = t.create_view()
    views['hz_sprite_s'] = dev.create_sampler(mag_filter='linear', min_filter='linear', mipmap_filter='linear')
    views['opaque_depth'] = views['scene_depth']; views['opaque_color'] = postrun.tex(np.zeros((sc.H, sc.W, 4), np.float32))
    views['reflection'] = views['opaque_color']; views['reflection_sampler'] = dev.create_sampler()
    views['block_light_colors'] = dev.create_texture(size=(1, 1, 1), dimension='3d', format=wgpu.TextureFormat.rgba16float, usage=postrun.TU.TEXTURE_BINDING).create_view()
    return flip(postrun.run('/tmp/terrain_test.wgsl', sc.W, sc.H, sc.frame_buf(), views))

if __name__ == '__main__':
    lv = sprite()
    for ticks in (int(a) for a in (sys.argv[1:] or ['6000', '12300', '18000'])):
        for mat, name, tint in ((10080, 'stone', (1, 1, 1, 1)), (0, 'grass (no id)', (0.55, 0.8, 0.35, 1))):
            sc = Scene(ticks=ticks, view_dir=(-1, -0.25, 0.3))
            ref = iris_terrain(sc, mat, tint, (0.0, 1.0), lv)
            port = port_terrain(sc, mat, tint, (0.0, 1.0), lv)
            mask = ref[0][..., 3] > 0
            r = np.where(mask[..., None], ref[0], 0)[..., :3]; p = np.where(mask[..., None], port, 0)[..., :3]
            compare(f'terrain {name} t={ticks}', r, p)
            np.save(f'/tmp/ter_{ticks}_{mat}.npy', np.stack([np.concatenate([r, mask[..., None]], -1), np.concatenate([p, mask[..., None]], -1)]))
