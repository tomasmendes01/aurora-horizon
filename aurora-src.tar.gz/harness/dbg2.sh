#!/bin/bash
# usage: dbg2.sh '<glsl vec4 expr>' ['<anchor line>']  → /tmp/composed (pack_dbg2) with composite1's output = expr
set -e
cd /tmp/claude-0/-home-claude/d0fc9658-9d0e-5d7b-9706-5c969bdb9984/scratchpad
cp cr_euph/shaders/program/composite1.glsl cr_dbg2/shaders/program/composite1.glsl
python3 - "$@" <<'PY'
import sys
p='cr_dbg2/shaders/program/composite1.glsl'; s=open(p).read()
anchor = sys.argv[2] if len(sys.argv) > 2 else '    /* DRAWBUFFERS'
i = s.index(anchor) if len(sys.argv) > 2 else None
if i is not None:
    j = s.index('\n', i)
    s = s[:j] + '\n gl_FragData[0] = ' + sys.argv[1] + '; return;' + s[j:]
open(p,'w').write(s)
PY
W=work_dbg2; export HZ_OPTS=$PWD/opts/opts.json
python3 crport/tools/pp.py cr_dbg2/shaders world0/composite1.fsh > $W/post/composite1.fsh.glsl
python3 crport/tools/merge_vsh.py $W/post/composite1.vsh.glsl $W/post/composite1.fsh.glsl $W/post/composite1.glsl
HZ_POST_DIR=$PWD/$W/post crport/tools/post_build.sh composite1 0 c1 >/dev/null 2>&1
rm -rf pack_dbg2; HZ_POST_DIRS="o:$PWD/$W/post,n:$PWD/work_e_world-1/post,e:$PWD/work_e_world1/post" HZ_WORK=$PWD/work_e_all HZ_SRC=$PWD/cr_dbg2/shaders crport/build.sh pack_dbg2 >/dev/null 2>&1
cp /tmp/oldpk/LICENSE.txt /tmp/oldpk/README.md pack_dbg2/
python3 tools/hzcheck.py ext/horizon pack_dbg2 2>&1 | tail -1
