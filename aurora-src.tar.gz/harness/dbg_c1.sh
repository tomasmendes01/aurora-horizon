#!/bin/bash
# usage: dbg_c1.sh '<glsl expression vec4>'  → rebuilds /tmp/dbg_c1.wgsl with gl_FragData[0] = expr
set -e
cd /tmp/claude-0/-home-claude/d0fc9658-9d0e-5d7b-9706-5c969bdb9984/scratchpad
cp cr_full/shaders/program/composite1.glsl cr_dbg/shaders/program/composite1.glsl
python3 - "$@" <<'PY'
import sys
p='cr_dbg/shaders/program/composite1.glsl'; s=open(p).read()
if len(sys.argv) > 2:
    assert s.count(sys.argv[2]) == 1, s.count(sys.argv[2])
    s=s.replace(sys.argv[2], sys.argv[2] + '\n gl_FragData[0] = ' + sys.argv[1] + '; return;', 1)
else:
    s=s.replace('    gl_FragData[0] = vec4(color, 1.0);', '    gl_FragData[0] = ' + sys.argv[1] + ';', 1)
open(p,'w').write(s)
PY
W=work_dbg
python3 crport/tools/pp.py cr_dbg/shaders world0/composite1.fsh > $W/post/composite1.fsh.glsl
python3 crport/tools/merge_vsh.py $W/post/composite1.vsh.glsl $W/post/composite1.fsh.glsl $W/post/composite1.glsl
HZ_POST_DIR=$PWD/$W/post crport/tools/post_build.sh composite1 0 c1 >/dev/null 2>&1
HZ_WORK=$PWD/work_dbg HZ_SRC=$PWD/cr_dbg/shaders crport/build.sh pack_dbg >/dev/null
rm -rf /tmp/composed; python3 tools/hzcheck.py ext/horizon pack_dbg >/dev/null 2>&1 || true
cp /tmp/composed/post/05_c1.wgsl /tmp/dbg_c1.wgsl
rm -rf /tmp/composed; python3 tools/hzcheck.py ext/horizon pack7 >/dev/null 2>&1
