import sys; sys.argv=['x']
src=open('cmp_deferred.py').read().replace("if __name__ == '__main__':", "if False:")
exec(src.replace("exec(open('cmp_post.py').read().replace(\"if __name__ == '__main__':\", \"if False:\"))", "exec(open('cmp_post.py').read().replace(\"if __name__ == '__main__':\", \"if False:\"))"))
ROOT='../cr_dbg/shaders'
sc = Scene(ticks=12300); H, W = sc.H, sc.W
gl, hz = sc.depths(); c4, c6, surf = surface(sc, hz)
c0 = picture(H, W, 0.6); c0[gl >= 1.0] = [0.4, 0.55, 0.9, 1]
z4 = np.zeros((H, W, 4), np.float32)
R5 = z4.copy(); R5[...,3]=1.0
r11 = lambda a: np.concatenate([np.maximum(a[..., :3], 0), np.ones_like(a[..., :1])], -1)
ROOT0 = ROOT; ROOT = '../cr_full/shaders'
it = {'colortex0': (c0, 'linear'), 'colortex3': (cw, 'repeat'), 'colortex4': (c4, 'linear'), 'colortex6': (c6, 'linear'),
      'colortex5': (np.zeros((H, W, 4), np.float32), 'linear'), 'cloudWaterTex': (cw, 'repeat')}
gl_, _ = sc.depths()
itx = dict(depthtex0=(gl_, 'depth'), depthtex1=(gl_, 'depth'), noisetex=(noise, 'repeat'), shadowtex0=(np.ones((2048, 2048), np.float32), 'shadow'), shadowtex1=(np.ones((2048, 2048), np.float32), 'shadow'), shadowcolor0=(np.ones((64, 64, 4), np.float32), 'linear'), shadowcolor1=(np.full((64, 64, 4), 0.25, np.float32), 'linear'))
ref = irisref.run(ROOT, 'world0/deferred1', W, H, sc.iris(), dict(itx, **it), [0, 5, 4])
R0 = r11(ref[0]); R5 = q8(ref[5]); R4 = np.round(np.clip(np.nan_to_num(ref[4]), -1, 1) * 127) / 127
itc = {'colortex0': (R0, 'linear'), 'colortex1': (R4, 'linear'), 'colortex4': (R4, 'linear'), 'colortex5': (R5, 'linear'),
       'colortex6': (c6, 'linear'), 'colortex7': (z4, 'linear'), 'colortex3': (z4, 'linear')}
refc = irisref.run(ROOT, 'world0/composite', W, H, sc.iris(), dict(itx, **itc), [7, 1])
itc['colortex7'] = (refc[7], 'linear')
ROOT = ROOT0
r1, p1, ref1 = run_pass(sc, 'world0/composite1', '/tmp/dbg_c1.wgsl', itc, {'ta': R0, 'tb': R5, 'tc': R4, 'previous': refc[7]}, [0, 5], 0, lambda a: a, surf)
for (y,x) in [(100,96),(35,16),(40,160),(20,96)]:
    print((y,x),'ref', r1[y,x], 'port', p1[y,x])
