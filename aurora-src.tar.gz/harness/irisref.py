"""Runs an original Complementary program as Iris would (OpenGL, the pack's own GLSL with Iris's
defines, a fullscreen quad), on llvmpipe."""
import moderngl, numpy as np, re, pathlib
ctx = moderngl.create_standalone_context(backend='egl')
IRIS_DEFINES = ['IS_IRIS', 'MC_VERSION 12111', 'MC_GL_VENDOR_NVIDIA', 'MC_GL_RENDERER_GEFORCE', 'MC_OS_WINDOWS',
    'IRIS_VERSION 10800', 'MC_RENDER_QUALITY 1.0', 'MC_SHADOW_QUALITY 1.0', 'MC_RENDER_STAGE_NONE 0', 'MC_RENDER_STAGE_SKY 1', 'MC_RENDER_STAGE_SUNSET 2', 'MC_RENDER_STAGE_CUSTOM_SKY 3', 'MC_RENDER_STAGE_SUN 4', 'MC_RENDER_STAGE_MOON 5', 'MC_RENDER_STAGE_STARS 6', 'MC_RENDER_STAGE_VOID 7', 'MC_RENDER_STAGE_TERRAIN_SOLID 8', 'MC_RENDER_STAGE_TERRAIN_CUTOUT_MIPPED 9', 'MC_RENDER_STAGE_TERRAIN_CUTOUT 10', 'MC_RENDER_STAGE_ENTITIES 11', 'MC_RENDER_STAGE_BLOCK_ENTITIES 12', 'MC_RENDER_STAGE_DESTROY 13', 'MC_RENDER_STAGE_OUTLINE 14', 'MC_RENDER_STAGE_DEBUG 15', 'MC_RENDER_STAGE_HAND_SOLID 16', 'MC_RENDER_STAGE_TERRAIN_TRANSLUCENT 17', 'MC_RENDER_STAGE_TRIPWIRE 18', 'MC_RENDER_STAGE_PARTICLES 19', 'MC_RENDER_STAGE_CLOUDS 20', 'MC_RENDER_STAGE_RAIN_SNOW 21', 'MC_RENDER_STAGE_WORLD_BORDER 22', 'MC_RENDER_STAGE_HAND_TRANSLUCENT 23']

def source(root, prog):
    root = pathlib.Path(root)
    def inline(p):
        out = []
        for line in p.read_text(errors='replace').splitlines():
            m = re.match(r'\s*#include\s+"(/[^"]+)"', line)
            if m and not (root / m.group(1).lstrip('/')).exists():
                out.append('// (missing include: ' + m.group(1) + ')'); continue
            out.append(inline(root / m.group(1).lstrip('/')) if m else line)
        return '\n'.join(out)
    s = inline(root / prog)
    s = re.sub(r'(//[^\n]*?)#include', r'\1include', s)  # moderngl reads #include even in comments
    v = re.search(r'^#version.*$', s, re.M)
    # #extension lines go first, as Iris moves them
    exts = re.findall(r'^\s*#extension.*$', s, re.M)
    s = re.sub(r'^\s*#extension.*$', '', s, flags=re.M)
    v = re.search(r'^#version.*$', s, re.M)
    head = v.group(0) + '\n' + ''.join(e.strip() + '\n' for e in exts) + ''.join(f'#define {d}\n' for d in IRIS_DEFINES)
    # Mesa's shadow2D gives (r, 0, 0, 1) (GL 3 depth texture mode RED); the drivers Iris runs on give
    # (r, r, r, 1) (LUMINANCE), which Complementary relies on (`shadow2D(shadowtex1, p).z`).
    head += '#define shadow2D(s, c) vec4(texture(s, c))\n'
    return head + s[:v.start()] + s[v.end():]

def vertex_patch(s):
    # Iris draws composite passes as a quad over 0..1 with an orthographic projection.
    s = s.replace('ftransform()', 'vec4(hzV * 2.0 - 1.0, 0.0, 1.0)')
    s = s.replace('gl_MultiTexCoord0', 'vec4(hzV, 0.0, 1.0)')
    s = re.sub(r'gl_TextureMatrix\[0\]', 'mat4(1.0)', s)
    v = re.search(r'^#define MC_RENDER_STAGE_HAND_TRANSLUCENT.*$', s, re.M)
    return s[:v.end()] + '\nin vec2 hzV;\n' + s[v.end():]

def run(root, prog, W, H, uniforms, textures, outputs, filters=None, mipmapped=None):
    """textures: name -> (array HxWxC float32 (GL rows: bottom first), kind) ; outputs: list of
    colortex indices gl_FragData[i] writes. Returns {index: HxWx4 float32, bottom row first}."""
    ctx.__enter__()
    vs = vertex_patch(source(root, prog + '.vsh'))
    fs = source(root, prog + '.fsh')
    p = ctx.program(vertex_shader=vs, fragment_shader=fs)
    unit = 0
    for name in list(p):
        m = p[name]
        if not isinstance(m, moderngl.Uniform): continue
        if name in textures:
            data, kind = textures[name]
            h, w = data.shape[:2]
            if kind == 'depth':
                t = ctx.depth_texture((w, h), data.astype('f4').tobytes())
                t.compare_func = ''
                filters = dict(filters or {}, **{name: 'nearest'})  # Iris's depth textures filter nearest
            elif kind == 'shadow':
                t = ctx.depth_texture((w, h), data.astype('f4').tobytes())
                # Iris turns comparison on only for the shadow samplers a program declares as such
                t.compare_func = '<=' if m.gl_type == 0x8B62 else ''
            else:
                c = data.shape[2]
                if name in ('noisetex', 'colortex3', 'cloudWaterTex') and np.all(np.abs(data * 255 - np.round(data * 255)) < 1e-3) and data.max() <= 1:
                    t = ctx.texture((w, h), c, np.round(data * 255).astype('u1').tobytes(), dtype='f1')  # 8-bit, like the PNG
                else:
                    t = ctx.texture((w, h), c, data.astype('f4').tobytes(), dtype='f4')
            filt = (filters or {}).get(name, kind if kind in ('linear', 'nearest', 'repeat') else 'linear')
            f = moderngl.LINEAR if filt in ('linear', 'repeat') else moderngl.NEAREST
            import os
            if os.environ.get('HZ_NEAREST') and name in ('colortex3', 'cloudWaterTex', 'noisetex'): f = moderngl.NEAREST
            t.filter = (f, f)
            t.repeat_x = t.repeat_y = (filt == 'repeat') or name in ('noisetex',)
            if name == 'noisetex' and not os.environ.get('HZ_NEAREST'): t.filter = (moderngl.LINEAR, moderngl.LINEAR)
            if name in (mipmapped or ()):
                t.build_mipmaps()
                t.filter = (moderngl.LINEAR_MIPMAP_LINEAR, moderngl.LINEAR)
            t.use(unit); m.value = unit; unit += 1
        elif m.gl_type in (0x8B5E, 0x8B62, 0x8B5F, 0x8DCA, 0x8DD2):  # an unbound sampler: a cleared buffer
            z = ctx.texture((1, 1), 4, np.zeros(4, 'f4').tobytes(), dtype='f4') if m.gl_type != 0x8B5F else ctx.texture3d((1, 1, 1), 4, np.zeros(4, 'f4').tobytes(), dtype='f4')
            z.use(unit); m.value = unit; unit += 1
        elif name in uniforms:
            v = uniforms[name]
            if isinstance(v, np.ndarray) and v.shape == (4, 4):
                m.write(np.asarray(v, 'f4').T.tobytes())  # column-major
            else:
                m.value = v
    outs = [ctx.texture((W, H), 4, dtype='f4') for _ in outputs]
    fbo = ctx.framebuffer(color_attachments=outs)
    fbo.use(); fbo.clear(0, 0, 0, 0)
    quad = ctx.buffer(np.array([0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 1, 1], 'f4').tobytes())
    vao = ctx.vertex_array(p, [(quad, '2f', 'hzV')])
    vao.render(moderngl.TRIANGLES)
    res = {}
    for i, o in zip(outputs, outs):
        res[i] = np.frombuffer(o.read(), 'f4').reshape(H, W, 4).copy()
    p.release(); fbo.release()
    for o in outs: o.release()
    return res

def missing_uniforms(root, prog, have):
    ctx.__enter__()
    p = ctx.program(vertex_shader=vertex_patch(source(root, prog + '.vsh')), fragment_shader=source(root, prog + '.fsh'))
    r = [n for n in p if isinstance(p[n], moderngl.Uniform) and n not in have]
    p.release(); return r
