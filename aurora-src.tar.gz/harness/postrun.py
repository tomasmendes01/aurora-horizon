"""Runs one composed Horizon post module (hzcheck's /tmp/composed/post/*.wgsl) on lavapipe with
synthetic resources, the way native_post.rs binds them."""
import wgpu, numpy as np, math, re
from PIL import Image
adapter = wgpu.gpu.request_adapter_sync(power_preference="high-performance")
dev = adapter.request_device_sync(required_limits={'max_bind_groups': 4, 'max_sampled_textures_per_shader_stage': 32,
    'max_samplers_per_shader_stage': 16})
TU = wgpu.TextureUsage

def norm(v): v = np.asarray(v, np.float64); return v / np.linalg.norm(v)
def look(f, up=(0, 1, 0)):
    f = norm(f); r = norm(np.cross(f, up)); u = np.cross(r, f)
    m = np.eye(4); m[0, :3] = r; m[1, :3] = u; m[2, :3] = -f
    return m
def persp_rev(fovy, aspect, n):
    t = 1 / math.tan(fovy / 2); m = np.zeros((4, 4))
    m[0, 0] = t / aspect; m[1, 1] = t; m[2, 3] = n; m[3, 2] = -1
    return m  # reversed infinite: z = n / -zv

def frame(W, H, sun_dir, view_dir, day_time, far=256.0, dist=192.0):
    F = np.zeros(192, np.float32)
    def put(off, vals): F[off // 4: off // 4 + len(vals)] = vals
    def mat(off, m): put(off, np.asarray(m, np.float32).T.reshape(-1))  # column-major
    V = look(view_dir); P = persp_rev(math.radians(70), W / H, 0.05)
    mat(0, V); mat(64, P); mat(128, np.linalg.inv(V)); mat(192, np.linalg.inv(P))
    put(256, [0, 80, 0]); put(268, [10.0]); put(272, norm(sun_dir)); put(284, [day_time])
    put(288, -norm(sun_dir)); put(300, [day_time]); put(304, [0.5, 0.7, 1.0]); put(316, [0.0])
    put(320, [0.7, 0.8, 1.0]); put(336, [W, H]); put(344, [0, 1]); put(352, [far * 0.9, far]); put(360, [far, far])
    put(380, [0.5]); F.view(np.uint32)[392 // 4] = 100
    put(412, [0.0]); put(496, [0, 1])
    L = norm(sun_dir); put(656, L); F.view(np.uint32)[668 // 4] = 1
    S = look(-L); S2 = np.diag([1 / dist, 1 / dist, 1 / 512, 1.0]) @ S; S2[2, 3] = 0.5
    mat(672, S2); put(736, [dist, 0.8333, 2048, 2 * dist / 2048])
    return F

def tex(data, fmt=wgpu.TextureFormat.rgba16float):
    data = np.ascontiguousarray(data)
    if fmt == wgpu.TextureFormat.rgba16float: data = data.astype(np.float16)
    h, w = data.shape[:2]
    t = dev.create_texture(size=(w, h, 1), format=fmt, usage=TU.TEXTURE_BINDING | TU.COPY_DST)
    bpp = data.dtype.itemsize * (data.shape[2] if data.ndim == 3 else 1)
    dev.queue.write_texture({'texture': t}, data.tobytes(), {'bytes_per_row': w * bpp}, (w, h, 1))
    return t.create_view()

def run(path, W, H, F, views):
    src = open(path).read()
    mod = dev.create_shader_module(code=src)
    decl = [(int(m.group(1)), m.group(3), m.group(4) if not m.group(2) else 'uniform') for m in re.finditer(r'@group\(3\) @binding\((\d+)\) var(<uniform>)? (\w+): ([\w<>]+)', src)]
    V = wgpu.ShaderStage.FRAGMENT | wgpu.ShaderStage.VERTEX
    le = []
    for b, name, ty in decl:
        if ty == 'uniform': le.append({'binding': b, 'visibility': V, 'buffer': {'type': 'uniform'}})
        elif ty == 'texture_3d<f32>': le.append({'binding': b, 'visibility': V, 'texture': {'sample_type': 'float', 'view_dimension': '3d'}})
        elif ty == 'sampler': le.append({'binding': b, 'visibility': V, 'sampler': {'type': 'filtering'}})
        elif ty == 'sampler_comparison': le.append({'binding': b, 'visibility': V, 'sampler': {'type': 'comparison'}})
        elif ty == 'texture_depth_2d': le.append({'binding': b, 'visibility': V, 'texture': {'sample_type': 'depth'}})
        elif ty == 'texture_2d<u32>': le.append({'binding': b, 'visibility': V, 'texture': {'sample_type': 'uint'}})
        else: le.append({'binding': b, 'visibility': V, 'texture': {'sample_type': 'float'}})
    bgl = dev.create_bind_group_layout(entries=le)
    empty = dev.create_bind_group_layout(entries=[])
    layout = dev.create_pipeline_layout(bind_group_layouts=[empty, empty, empty, bgl])
    pipe = dev.create_render_pipeline(layout=layout, vertex={'module': mod, 'entry_point': 'horizon_vs_post'},
        fragment={'module': mod, 'entry_point': 'horizon_fs_post', 'targets': [{'format': wgpu.TextureFormat.rgba32float}]},
        primitive={'topology': wgpu.PrimitiveTopology.triangle_list})
    fb = dev.create_buffer_with_data(data=F.tobytes() + bytes(64), usage=wgpu.BufferUsage.UNIFORM)
    lin = dev.create_sampler(mag_filter='linear', min_filter='linear')
    near = dev.create_sampler()
    import os
    _f = 'nearest' if os.environ.get('HZ_NEAREST') else 'linear'
    rep = dev.create_sampler(mag_filter=_f, min_filter=_f, address_mode_u='repeat', address_mode_v='repeat')
    cmp = dev.create_sampler(mag_filter='linear', min_filter='linear', compare='less-equal')
    entries = []
    for b, name, ty in decl:
        if name == 'frame': r = {'buffer': fb}
        elif ty == 'uniform': r = {'buffer': dev.create_buffer_with_data(data=np.zeros(4, np.float32).tobytes(), usage=wgpu.BufferUsage.UNIFORM)}
        elif ty == 'sampler' and name in views: r = views[name]
        elif ty == 'sampler': r = rep if b >= 24 else (lin if name == 'linear_sampler' else near)
        elif ty == 'sampler_comparison': r = cmp
        else: r = views[name]
        entries.append({'binding': b, 'resource': r})
    bg = dev.create_bind_group(layout=bgl, entries=entries)
    empties = [dev.create_bind_group(layout=empty, entries=[]) for i in range(3)]
    out = dev.create_texture(size=(W, H, 1), format=wgpu.TextureFormat.rgba32float, usage=TU.RENDER_ATTACHMENT | TU.COPY_SRC)
    e = dev.create_command_encoder()
    rp = e.begin_render_pass(color_attachments=[{'view': out.create_view(), 'load_op': 'clear', 'store_op': 'store', 'clear_value': (0, 0, 0, 0)}])
    rp.set_pipeline(pipe)
    for i, g in enumerate(empties): rp.set_bind_group(i, g)
    rp.set_bind_group(3, bg); rp.draw(3); rp.end()
    dev.queue.submit([e.finish()])
    data = dev.queue.read_texture({'texture': out}, {'bytes_per_row': W * 16}, (W, H, 1))
    return np.frombuffer(data, np.float32).reshape(H, W, 4)
