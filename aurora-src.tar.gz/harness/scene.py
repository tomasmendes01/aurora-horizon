"""One synthetic scene, given to both sides: Iris's uniforms (from Iris's and Horizon's own
compatibility semantics, pack_uniforms.rs) and Horizon's Frame."""
import numpy as np, math

def norm(v): v = np.asarray(v, np.float64); return v / np.linalg.norm(v)
def look(f, up=(0, 1, 0)):
    f = norm(f)
    if abs(np.dot(f, up)) > 0.999: up = (0, 0, 1)
    r = norm(np.cross(f, up)); u = np.cross(r, f)
    m = np.eye(4); m[0, :3] = r; m[1, :3] = u; m[2, :3] = -f
    return m

class Scene:
    def __init__(s, W=192, H=108, ticks=12300, view_dir=(-1, 0.15, 0.2), cam=(100.3, 70.7, -50.2), rd=256.0,
                 rain=0.0, eye_light=(0.0, 1.0), frame=1234, time=321.5, fov=70.0, eye_in=0):
        s.W, s.H, s.ticks, s.cam, s.rd, s.rain, s.eye_light, s.frame, s.time, s.eye_in = W, H, ticks, np.array(cam), rd, rain, eye_light, frame, time, eye_in
        s.depth_far = rd * 4.0
        s.V = look(view_dir)
        t = 1 / math.tan(math.radians(fov) / 2); a = W / H; n, f = 0.05, s.depth_far
        P = np.zeros((4, 4)); P[0, 0] = t / a; P[1, 1] = t; P[2, 2] = -(f + n) / (f - n); P[2, 3] = -2 * f * n / (f - n); P[3, 2] = -1
        s.P_gl = P
        Ph = np.zeros((4, 4)); Ph[0, 0] = t / a; Ph[1, 1] = t; Ph[2, 2] = n / (f - n); Ph[2, 3] = n * f / (f - n); Ph[3, 2] = -1
        s.P_hz = Ph  # reversed, wgpu z 0..1 (far 0)
        d = (ticks / 24000.0 - 0.25) % 1.0
        ang = (d + (math.cos(d * math.pi) * -0.5 + 0.5 - d) / 3.0) * 2 * math.pi
        s.sun = norm([-math.sin(ang), math.cos(ang), 0.0])
        s.day_time = (ticks % 24000) / 24000.0

    def iris(s):
        V, P = s.V, s.P_gl
        u = dict(viewWidth=float(s.W), viewHeight=float(s.H), aspectRatio=s.W / s.H, near=0.05, far=s.rd,
                 frameCounter=s.frame % 720720, frameTime=1 / 60, frameTimeCounter=s.time % 3600, worldTime=s.ticks % 24000,
                 worldDay=0, moonPhase=0, sunAngle=0.0, rainStrength=s.rain, wetness=s.rain, isEyeInWater=s.eye_in,
                 eyeBrightness=(int(s.eye_light[0] * 240), int(s.eye_light[1] * 240)),
                 eyeBrightnessSmooth=(int(s.eye_light[0] * 240), int(s.eye_light[1] * 240)),
                 cameraPosition=tuple(s.cam), previousCameraPosition=tuple(s.cam), eyeAltitude=float(s.cam[1]),
                 gbufferModelView=V, gbufferModelViewInverse=np.linalg.inv(V), gbufferProjection=P,
                 gbufferProjectionInverse=np.linalg.inv(P), gbufferPreviousModelView=V, gbufferPreviousProjection=P,
                 nightVision=0.0, blindness=0.0, darknessFactor=0.0, darknessLightFactor=0.0, screenBrightness=0.5,
                 skyColor=(0.5, 0.7, 1.0), fogColor=(0.7, 0.8, 1.0), heavyFog=False, isElytraFlying=False, cloudHeight=192.0,
                 blockEntityId=-1, entityId=0, currentRenderedItemId=0, heldItemId=0, heldItemId2=0,
                 heldBlockLightValue=0, heldBlockLightValue2=0, playerMood=0.0, is_invisible=False,
                 cameraPositionInt=tuple(int(x) for x in np.floor(s.cam)), cameraPositionFract=tuple(s.cam - np.floor(s.cam)),
                 previousCameraPositionInt=tuple(int(x) for x in np.floor(s.cam)), previousCameraPositionFract=tuple(s.cam - np.floor(s.cam)),
                 atlasSize=(16, 16), renderStage=0, relativeEyePosition=(0.0, 0.0, 0.0), eyePosition=tuple(s.cam),
                 playerLookVector=tuple((np.linalg.inv(V) @ [0, 0, -1, 0])[:3]),
                 # Complementary's custom uniforms (shaders.properties:242-279), converged
                 framemod2=float(s.frame % 2), framemod4=float(s.frame % 4), framemod8=float(s.frame % 8), framemod600=float(s.frame % 600),
                 isEyeInCave=(1.0 - (s.eye_light[1] if s.cam[1] < 5.0 else 1.0)) if s.eye_in == 0 else 0.0,
                 inDry=0.0, inRainy=1.0, inSnowy=0.0, starter=1.0, frameTimeSmooth=1 / 60, eyeBrightnessM=s.eye_light[1],
                 eyeBrightnessM2=1.0 if s.eye_light[1] * 240 > 239 else 0.0, rainFactor=s.rain,
                 inNetherWastes=0.0, inCrimsonForest=0.0, inWarpedForest=0.0, inBasaltDeltas=0.0, inSoulValley=0.0,
                 inPaleGarden=0.0, inSulfurCaves=0.0, maxBlindnessDarkness=0.0, endFlashIntensityM=0.0, velocity=0.0,
                 endFlashPosition=(0.0, 0.0, 0.0), lightningBoltPosition=(0.0, 0.0, 0.0, 0.0), entityColor=(0.0, 0.0, 0.0, 0.0))
        # Iris's shadow camera (ShadowMatrices): from the light, 100 blocks back, an ortho box of
        # the shadow distance over -100.05..156 along the light around the camera
        L = s.sun if s.sun[1] > 0 else -s.sun
        T = np.eye(4); T[2, 3] = -100.0
        SV = T @ look(-L)
        hd, n, f = 192.0, 0.05, 256.0
        SP = np.diag([1 / hd, 1 / hd, -2 / (f - n), 1.0]); SP[2, 3] = -(f + n) / (f - n)
        u.update(shadowModelView=SV, shadowModelViewInverse=np.linalg.inv(SV), shadowProjection=SP,
                 shadowProjectionInverse=np.linalg.inv(SP), shadowLightPosition=tuple((s.V @ np.append(L * 100, 0))[:3]),
                 sunPosition=tuple((s.V @ np.append(s.sun * 100, 0))[:3]), moonPosition=tuple((s.V @ np.append(-s.sun * 100, 0))[:3]),
                 upPosition=tuple((s.V @ np.array([0, 100, 0, 0]))[:3]))
        # Euphoria Patches' (shaders.properties:575-685), converged
        import os
        dim = {'world0': 0, 'world-1': -1, 'world1': 1}[os.environ.get('HZ_DIM', 'world0')]
        u.update(bedrockLevel=-64 if dim == 0 else 0, currentPlayerArmor=0.0, eyeBrightnessXM=s.eye_light[0],
                 eyeBrightnessXM2=1.0 if s.eye_light[0] * 240 > 239 else 0.0, firstPersonCamera=True, hideGUI=0,
                 isOnGround=True, isRightHanded=True, isShockwave=0.0, isSneaking=0.0, isSprinting=0.0,
                 inDappledForest=0.0, inForest=0.0, inJungle=0.0, inLushCave=0.0, inRedSand=0.0, inSand=0.0,
                 inVanillaEnd=1.0 if dim == 1 else 0.0, lightningFlashOptifine=0.0, shaderStart=float(s.frame),
                 shaderStartSmooth=min(max((s.time % 3600 - 4.5) / 20.0, 0.0), 1.0), texelSize=(1 / s.W, 1 / s.H),
                 viewSize=(float(s.W), float(s.H)), thunderFactor=0.0, waterAltitude=61.9,
                 worldAgeSmooth=float(s.ticks % 24000), worldTimeSmooth=float(s.ticks % 24000))
        # sunAngle (Iris): the vanilla celestial angle + 0.25
        d = (s.ticks / 24000.0 - 0.25) % 1.0; e = 0.5 - math.cos(d * math.pi) / 2
        u['sunAngle'] = ((d * 2 + e) / 3 + 0.25) % 1.0
        return u

    def frame_buf(s, dist=192.0):
        F = np.zeros(192, np.float32)
        def put(off, vals): F[off // 4: off // 4 + len(vals)] = vals
        def mat(off, m): put(off, np.asarray(m, np.float32).T.reshape(-1))
        mat(0, s.V); mat(64, s.P_hz); mat(128, np.linalg.inv(s.V)); mat(192, np.linalg.inv(s.P_hz))
        put(256, s.cam); put(268, [s.time % 3600]); put(272, s.sun); put(284, [s.day_time])
        put(288, -s.sun); put(300, [s.day_time]); put(304, [0.5, 0.7, 1.0]); put(316, [s.rain])
        put(320, [0.7, 0.8, 1.0]); put(332, [0.0]); put(336, [s.W, s.H]); put(344, list(s.eye_light))
        put(352, [s.rd * 0.9, s.rd]); put(360, [s.rd, s.depth_far]); put(380, [0.5])
        F.view(np.uint32)[384 // 4] = s.eye_in
        import os
        F.view(np.int32)[388 // 4] = {'world0': 0, 'world-1': -1, 'world1': 1}[os.environ.get('HZ_DIM', 'world0')]
        F.view(np.uint32)[392 // 4] = s.frame
        F.view(np.uint32)[400 // 4] = 1
        put(412, [s.rain]); put(492, [1 / 60]); put(496, list(s.eye_light))
        L = s.sun if s.sun[1] > 0 else -s.sun
        put(656, L); F.view(np.uint32)[668 // 4] = 1
        S = look(-L); S2 = np.diag([1 / dist, 1 / dist, -1 / 512, 1.0]) @ S; S2[2, 3] = 0.5  # z: 0 toward the light
        mat(672, S2); put(736, [dist, 0.8333, 2048, 2 * dist / 2048])
        return F

    def view_positions(s):
        """For each pixel (GL rows, bottom first), the view-space ray direction (z = -1)."""
        y, x = np.mgrid[0:s.H, 0:s.W]
        ndc = np.stack([(x + 0.5) / s.W * 2 - 1, (y + 0.5) / s.H * 2 - 1], -1)
        return np.stack([ndc[..., 0] / s.P_gl[0, 0], ndc[..., 1] / s.P_gl[1, 1], -np.ones_like(ndc[..., 0])], -1)

    def depths(s, ground_y=-1.6, box=None):
        """A ground plane ground_y below the camera (camera-relative world) and sky; GL depth (0..1)
        and Horizon's reversed depth, GL rows (bottom first)."""
        rays = s.view_positions()
        Vi = np.linalg.inv(s.V)
        wr = rays @ Vi[:3, :3].T
        t = np.where(wr[..., 1] < -1e-4, ground_y / np.minimum(wr[..., 1], -1e-4), np.inf)
        t = np.where(t * np.linalg.norm(wr, axis=-1) > s.rd * 0.95, np.inf, t)
        zv = -t  # view z
        n, f = 0.05, s.depth_far
        gl = np.where(np.isinf(t), 1.0, ((-(f + n) / (f - n)) * zv - 2 * f * n / (f - n)) / (-zv) * 0.5 + 0.5)
        hz = np.where(np.isinf(t), 0.0, (n / (f - n) * zv + n * f / (f - n)) / (-zv))
        return gl.astype(np.float32), hz.astype(np.float32)
