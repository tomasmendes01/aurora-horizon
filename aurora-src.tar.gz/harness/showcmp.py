import numpy as np, sys
from PIL import Image
a = np.load(sys.argv[1]); r, p = a[0], a[1]
def im(x): x = np.nan_to_num(x[::-1, :, :3]); return Image.fromarray((np.clip(x / (1 + x), 0, 1) * 255).astype(np.uint8)).resize((384, 216), Image.NEAREST)
d = np.abs(np.nan_to_num(r) - np.nan_to_num(p))[..., :3].max(-1)
c = Image.new('RGB', (384 * 3, 216))
c.paste(im(r), (0, 0)); c.paste(im(p), (384, 0)); c.paste(Image.fromarray((np.clip(d[::-1] * 4, 0, 1) * 255).astype(np.uint8)).convert('RGB').resize((384, 216)), (768, 0))
c.save(sys.argv[2])
