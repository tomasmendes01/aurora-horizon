import wgpu, numpy as np, subprocess, tempfile, os
adapter = wgpu.gpu.request_adapter_sync(power_preference="high-performance")
print(adapter.info["device"], adapter.info["backend_type"])
dev = adapter.request_device_sync(required_features=["spirv-shader-passthrough"] if "spirv-shader-passthrough" in adapter.features else [])
def run(module, n, inp):
    ib = dev.create_buffer_with_data(data=inp.tobytes(), usage=wgpu.BufferUsage.STORAGE)
    ob = dev.create_buffer(size=n*16, usage=wgpu.BufferUsage.STORAGE|wgpu.BufferUsage.COPY_SRC)
    p = dev.create_compute_pipeline(layout="auto", compute={"module": module, "entry_point": "main"})
    bg = dev.create_bind_group(layout=p.get_bind_group_layout(0), entries=[{"binding":0,"resource":{"buffer":ib}},{"binding":1,"resource":{"buffer":ob}}])
    e = dev.create_command_encoder(); c = e.begin_compute_pass(); c.set_pipeline(p); c.set_bind_group(0,bg); c.dispatch_workgroups((n+63)//64); c.end(); dev.queue.submit([e.finish()])
    return np.frombuffer(dev.queue.read_buffer(ob), dtype=np.float32).reshape(n,4)
n=1000; x=np.random.default_rng(1).random((n,4),dtype=np.float32)
wgsl = dev.create_shader_module(code="""
@group(0) @binding(0) var<storage, read> i: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read_write> o: array<vec4<f32>>;
@compute @workgroup_size(64) fn main(@builtin(global_invocation_id) g: vec3<u32>) { if g.x < arrayLength(&i) { o[g.x] = pow(i[g.x], vec4(2.2)); } }""")
glsl = """#version 450
layout(local_size_x=64) in;
layout(std430, binding=0) readonly buffer I { vec4 i[]; };
layout(std430, binding=1) buffer O { vec4 o[]; };
void main(){ uint g=gl_GlobalInvocationID.x; if(g<i.length()) o[g]=pow(i[g], vec4(2.2)); }"""
d=tempfile.mkdtemp(); open(d+'/a.comp','w').write(glsl)
subprocess.check_call(['glslangValidator','-V','--target-env','vulkan1.1','-o',d+'/a.spv',d+'/a.comp'],stdout=subprocess.DEVNULL)
sp = dev.create_shader_module(code=open(d+'/a.spv','rb').read())
a=run(wgsl,n,x); b=run(sp,n,x)
print('max diff', np.abs(a-b).max(), 'vs numpy', np.abs(a-x**2.2).max())
