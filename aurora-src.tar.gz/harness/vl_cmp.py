"""composite1 with its light shafts: original (one pass) vs port (vl pass, then c1).
usage: vl_cmp.py water|cave"""
import sys
exec(open('cmp_deferred.py').read().replace("if __name__ == '__main__':", "if False:"))
case_ = sys.argv[1] if len(sys.argv) > 1 else 'water'
water = case_ == 'water'
sc = Scene(ticks=3000, view_dir=(-1, 0.6, 0.2), eye_in=1 if water else 0, eye_light=(0.0, 1.0 if water else 0.3))
H, W = sc.H, sc.W
gl, hz = sc.depths(ground_y=-12.0)
c4, c6, surf = surface(sc, hz)
c0 = picture(H, W, 0.3); c0[gl >= 1.0] = [0.2, 0.3, 0.6, 1]
z4 = np.zeros((H, W, 4), np.float32)
c5 = np.zeros((H, W, 4), np.float32); c5[..., 3] = 1.0  # vlFactor (deferred1 writes it in the corner)
# shadow maps: half of the map (x < 0.5) open sky, the rest under a roof (cave) / water surface
S = 2048
sm = np.ones((S, S), np.float32); st = np.ones((S, S), np.float32)
if water:
    st[:, :] = 0.0         # a water surface between every point and the light
else:
    sm[:, S // 2:] = 0.0   # rock over half the map
    st = sm.copy()
sc_col = np.zeros((64, 64, 4), np.float32); sc_col[...] = [57/255, 66/255, 87/255, 1.0]
it = {'colortex0': (c0, 'linear'), 'colortex1': (c4, 'linear'), 'colortex4': (c4, 'linear'), 'colortex5': (c5, 'linear'),
      'colortex6': (c6, 'linear'), 'colortex7': (z4, 'linear'), 'colortex3': (z4, 'linear'),
      'shadowtex0': (np.minimum(sm, st), 'shadow'), 'shadowtex1': (sm, 'shadow'), 'shadowcolor1': (sc_col, 'linear')}
gl_, hz_ = gl, hz
ref = irisref.run(ROOT, DIMDIR + '/composite1', W, H, sc.iris(), dict(depthtex0=(gl, 'depth'), depthtex1=(gl, 'depth'), noisetex=(noise, 'repeat'), **it), [0])
views = common_views(sc, hz, {'ta': c0, 'tb': c5, 'tc': c4, 'previous': z4})
views['scene_surface'] = postrun.tex(flip(surf), wgpu.TextureFormat.rgba32uint)
# Horizon: depth 0 at the light; Iris 0..1 the same way round here (both maps are 0 or 1)
views['shadow_map'] = depth_view(sm); views['shadow_map_translucent'] = depth_view(st)
views['shadow_color'] = postrun.tex(np.broadcast_to(np.array([0.25, 0.4, 0.5, 1.0], np.float32), (S, S, 4)).copy())
views['vl'] = postrun.tex(postrun.run('/tmp/composed/post/00_vl.wgsl', W, H, sc.frame_buf(), views))
out = flip(postrun.run('/tmp/composed/post/05_c1.wgsl', W, H, sc.frame_buf(), views))
r = ref[0][..., :3]; p = out[..., :3]
print(case_, 'iris mean', r.mean(axis=(0, 1)), 'port mean', p.mean(axis=(0, 1)), 'input mean', c0[..., :3].mean(axis=(0, 1)))
compare('composite1 colortex0', r, p)
np.save(f'/tmp/vl_{case_}.npy', np.stack([r, p]))
vlv = postrun.run('/tmp/composed/post/00_vl.wgsl', W, H, sc.frame_buf(), views)
print('vl pass mean', vlv.mean(axis=(0, 1)))
views['vl'] = postrun.tex(np.zeros((H // 4, W // 4, 4), np.float32))
o2 = flip(postrun.run('/tmp/composed/post/05_c1.wgsl', W, H, sc.frame_buf(), views))
print('port c1 with vl=0 mean', o2[..., :3].mean(axis=(0, 1)))
