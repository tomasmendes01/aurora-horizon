import numpy as np, math, sys
from postrun import *
from PIL import Image
W, H = 160, 90
def rgba(v, fmt=np.float32): return np.ascontiguousarray(np.broadcast_to(np.asarray(v, fmt), (H, W, 4)))
noise = np.asarray(Image.open('../cr_src/shaders/lib/textures/noise.png').convert('RGBA'), np.uint8)
cw = np.asarray(Image.open('../cr_src/shaders/lib/textures/cloud-water.png').convert('RGBA'), np.uint8)
day = float(sys.argv[1]) if len(sys.argv) > 1 else 12300 / 24000
lit = float(sys.argv[2]) if len(sys.argv) > 2 else 1.0
# the sun (vanilla, eased) toward -x
d = (day - 0.25) % 1; e = 0.5 - math.cos(d * math.pi) / 2; c = (d * 2 + e) / 3
ang = c * 2 * math.pi
sun = (-math.sin(ang), math.cos(ang), 0.0)
F = frame(W, H, sun, (sun[0], max(sun[1], 0.05), 0.0), day)
views = dict(scene_color=tex(rgba([0.5, 0.5, 0.5, 1])), scene_depth=tex(np.zeros((H, W), np.float32), wgpu.TextureFormat.depth32float) if False else None,
             previous=tex(rgba([0, 0, 0, 0])), history=tex(rgba([0, 0, 0, 0])),
             shadow_color=tex(np.ones((64, 64, 4), np.float32)),
             scene_surface=tex(np.zeros((H, W, 4), np.uint32), wgpu.TextureFormat.rgba32uint),
             noisetex=tex(noise, wgpu.TextureFormat.rgba8unorm), cloudwater=tex(cw, wgpu.TextureFormat.rgba8unorm),
             vl=tex(rgba([0, 0, 0, 0.0])), ta=tex(rgba([0.55, 0.6, 0.75, 1])), tb=tex(rgba([0, 0, 0, 1.0])), tc=tex(rgba([0, 0, 0, 0])))
def depth_view(w, h, v):
    t = dev.create_texture(size=(w, h, 1), format=wgpu.TextureFormat.depth32float, usage=TU.TEXTURE_BINDING | TU.RENDER_ATTACHMENT)
    e = dev.create_command_encoder()
    rp = e.begin_render_pass(color_attachments=[], depth_stencil_attachment={'view': t.create_view(), 'depth_load_op': 'clear', 'depth_store_op': 'store', 'depth_clear_value': v})
    rp.end(); dev.queue.submit([e.finish()])
    return t.create_view()
views['scene_depth'] = depth_view(W, H, 0.0)
views['shadow_map'] = depth_view(256, 256, lit)
views['shadow_map_translucent'] = depth_view(256, 256, lit)
out = run(sys.argv[3] if len(sys.argv) > 3 else '/tmp/composed/post/05_c1.wgsl', W, H, F, views)
print('day', day, 'sun', np.round(sun, 3), 'lit', lit)
print('out mean', out[..., :3].mean((0, 1)), 'centre', out[H // 2, W // 2, :3], 'max', out[..., :3].max())
np.save('/tmp/vl_out_%s.npy' % lit, out)
