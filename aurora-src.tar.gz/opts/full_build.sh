#!/bin/bash
# Full pack build with the settings: translations of the three dimensions, the merged terrain, pk_all.
set -e
cd $(dirname $0)/..
export HZ_OPTS=$PWD/opts/opts.json HZ_OPTS_MAT=$PWD/opts/opts_mat.json
for d in world0 world-1 world1; do (HZ_DIM=$d crport/make_all.sh cr_euph/shaders work_e_$d x > /tmp/mk_$d.log 2>&1 || echo "FAILED $d") & done; wait
rm -rf work_e_all && cp -r work_e_world0 work_e_all
python3 crport/tools/merge_dims.py work_e_all/terrain.fsh.glsl work_e_world0/terrain.fsh.glsl -1:work_e_world-1/terrain.fsh.glsl 1:work_e_world1/terrain.fsh.glsl
T=crport/tools W=work_e_all
HZ_OPTS=$HZ_OPTS_MAT $T/build_stage.sh $W/terrain.fsh.glsl frag $W/w_t.wgsl
python3 $T/wgsl_slim.py $W/w_t.wgsl $W/slim_t.wgsl >/dev/null
HZ_OPTS=$HZ_OPTS_MAT python3 $T/hzify.py $W/slim_t.wgsl t_ $W/hz_t.wgsl
python3 $T/dedupe.py $W/merged.wgsl t_:$W/hz_t.wgsl w_:$W/hz_w.wgsl v_:$W/hz_v.wgsl
rm -rf pk_all
HZ_POST_DIRS="o:$PWD/work_e_world0/post,n:$PWD/work_e_world-1/post,e:$PWD/work_e_world1/post" HZ_WORK=$PWD/work_e_all HZ_SRC=$PWD/cr_euph/shaders crport/build.sh pk_all
cp /tmp/oldpk/LICENSE.txt /tmp/oldpk/README.md pk_all/
python3 tools/hzcheck.py ext/horizon pk_all 2>&1 | grep -v "^  post" | tail -6
