# Writes opts/opts.json: the pack's options, their slider ranges taken from the original's value lists.
import json, re
d = json.load(open('opts/defs.json'))
exec(open('opts/pick.py').read().split('print(len(pick))')[0])
drop_outliers = {'BLOOM_STRENGTH': 1, 'WAVING_I': 1, 'NETHER_VIEW_LIMIT': 1}
orig_default = {'NETHER_STORM_I': '0.40', 'BORDER_FOG_DENSITY_NETHER': '1.00', 'BORDER_FOG_DENSITY_END': '1.00'}
out = {}
for n in pick:
    x = d[n]; vals = x['values'][:len(x['values']) - drop_outliers.get(n, 0)]
    isint = re.fullmatch(r'-?\d+', x['default']) is not None
    nums = sorted(float(v) for v in vals)
    deltas = sorted({round(b - a, 6) for a, b in zip(nums, nums[1:]) if b > a})
    step = deltas[0] if deltas else 1
    ifs = __import__('subprocess').run(['grep', '-rhE', r'#\s*(if|elif).*\b' + n + r'\b', 'cr_euph/shaders'],
                                       capture_output=True, text=True).stdout
    out[n] = dict(type='int' if isint else 'float', default=float(x['default']), min=min(nums), max=max(nums),
                  step=step, sentinel=(int(float(x['default'])) + 1 if ifs.strip() else None),
                  original_default=float(orig_default.get(n, x['default'])))
# Choices (the override is the value's index); their #if tests see a non-default index.
out['PROFILE'] = dict(type='choice', values=['Potato', 'Very Low', 'Low', 'Medium', 'High', 'Very High', 'Ultra'],
                      default=4, sentinel=5, original_default=4)
out['LENSFLARE_MODE'] = dict(type='choice', values=['Off', 'Sun Only - Circle', 'Sun & Moon - Circle', 'Sun Only - Square', 'Sun & Moon - Square'],
                             default=1, sentinel=2, original_default=0)
out['SHADOW_DISTANCE'].update(min=64.0, max=512.0)
out['AURORA_SNOWY_ONLY'] = dict(type='choice', values=['Every Night', 'Snowy Biome'], default=1, sentinel=None, original_default=1)
# Port-only (the adapter reads it): how far past white light-emitting blocks go (1: as the original).
out['HZ_EMISSIVE_BRIGHTNESS'] = dict(type='float', default=0.2, min=0.0, max=1.0, step=0.05, sentinel=None, original_default=1.0, port_only=True)
json.dump(out, open('opts/opts.json', 'w'), indent=1)
print(len(out))
