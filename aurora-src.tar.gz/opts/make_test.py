# Writes opts/opts_test.json: the pack's options, their slider ranges taken from the original's value lists.
import json, re
d = json.load(open('opts/defs.json'))
exec(open('opts/pick_test.py').read().split('print(len(pick))')[0])
drop_outliers = {'BLOOM_STRENGTH': 1, 'WAVING_I': 1, 'NETHER_VIEW_LIMIT': 1}
orig_default = {'NETHER_STORM_I': '0.40', 'BORDER_FOG_DENSITY_NETHER': '1.00', 'BORDER_FOG_DENSITY_END': '1.00'}
out = {}
for n in pick:
    x = d[n]; vals = x['values'][:len(x['values']) - drop_outliers.get(n, 0)]
    isint = re.fullmatch(r'-?\d+', x['default']) is not None
    nums = [float(v) for v in vals]
    deltas = sorted({round(b - a, 6) for a, b in zip(nums, nums[1:]) if b > a})
    step = deltas[0] if deltas else 1
    ifs = __import__('subprocess').run(['grep', '-rhE', r'#\s*(if|elif).*\b' + n + r'\b', 'cr_euph/shaders'],
                                       capture_output=True, text=True).stdout
    out[n] = dict(type='int' if isint else 'float', default=float(x['default']), min=min(nums), max=max(nums),
                  step=step, sentinel=(int(float(x['default'])) + 1 if ifs.strip() else None),
                  original_default=float(orig_default.get(n, x['default'])))
json.dump(out, open('opts/opts_test.json', 'w'), indent=1)
print(len(out))
