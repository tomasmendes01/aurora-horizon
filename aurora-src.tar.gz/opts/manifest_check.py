# Horizon's manifest rules for [[options]], [[pages]] and [shadow] (manifest.rs), mirrored.
import tomllib, re, sys
m = tomllib.load(open(sys.argv[1], 'rb'))
ids = [o['id'] for o in m['options']]; assert len(ids) == len(set(ids)) and len(ids) <= 64
ident = lambda s: re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*', s) and len(s) <= 64 and not s.startswith('horizon_')
for o in m['options']:
    assert ident(o['id']) and o['name'].strip(), o
    t = o['type']
    if t == 'float':
        st = o.get('step', (o['max'] - o['min']) / 100)
        assert o['min'] < o['max'] and o['min'] <= o['default'] <= o['max'] and 0 < st <= o['max'] - o['min'] and 'values' not in o, o
    elif t == 'int':
        assert all(isinstance(o[k], int) for k in ('min', 'max', 'default')) and 'step' not in o and o['min'] < o['max'] and o['min'] <= o['default'] <= o['max'], o
    elif t == 'choice':
        v = o['values']; assert 2 <= len(v) <= 32 and len(set(v)) == len(v) and all(x.strip() for x in v) and o['default'] in v
        assert not any(k in o for k in ('min', 'max', 'step')), o
    else: raise SystemExit(f'type {t}')
    assert set(o) <= {'id', 'name', 'description', 'type', 'default', 'min', 'max', 'step', 'values'}, o
sh = m.get('shadow', {})
if 'distance_option' in sh:
    o = next(o for o in m['options'] if o['id'] == sh['distance_option'])
    assert o['type'] == 'int' and 32 <= o['min'] and o['max'] <= 512, o
pages = m['pages']; pid = [p['id'] for p in pages]; assert len(pages) <= 32 and len(set(pid)) == len(pid)
seen = set(); reach = {0}; stack = [0]
while stack:
    i = stack.pop(); p = pages[i]
    assert p['name'].strip() and p.get('columns', 2) in (1, 2) and len(p['items']) <= 64 and ident(p['id'])
    ne = [x for x in p['items'] if x]; assert len(ne) == len(set(ne)), p['id']
    for it in ne:
        if it.startswith('page:'):
            j = pid.index(it[5:]); assert j != i
            if j not in reach: reach.add(j); stack.append(j)
        else: assert it in ids, it; seen.add(it)
assert len(reach) == len(pages) and seen == set(ids), (len(reach), set(ids) - seen)
print('manifest options/pages/shadow OK', len(ids), 'options', len(pages), 'pages')
