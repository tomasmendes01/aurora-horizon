#!/bin/bash
# usage: mat_test.sh "EXCLUDED OPTIONS..."  → material expression count
cd $(dirname $0)/..
python3 - "$1" <<'P'
import json,sys
o=json.load(open('opts/opts_mat.json')); ex=sys.argv[1].split()
json.dump({k:v for k,v in o.items() if k not in ex},open('opts/opts_mt.json','w'))
P
T=crport/tools; export HZ_OPTS=$PWD/opts/opts_mt.json
for d in world0 world-1 world1; do (
  W=/tmp/mt_$d; rm -rf $W; mkdir -p $W
  python3 $T/pp.py cr_euph/shaders $d/gbuffers_terrain.fsh > $W/terrain.fsh.glsl
  python3 $T/pp.py cr_euph/shaders $d/gbuffers_water.fsh > $W/water.fsh.glsl
  python3 $T/pp.py cr_euph/shaders $d/gbuffers_terrain.vsh > $W/terrain.vsh.glsl ) & done; wait
W=/tmp/mt_all; rm -rf $W; mkdir -p $W; cp /tmp/mt_world0/* $W/
python3 $T/merge_dims.py $W/terrain.fsh.glsl /tmp/mt_world0/terrain.fsh.glsl -1:/tmp/mt_world-1/terrain.fsh.glsl 1:/tmp/mt_world1/terrain.fsh.glsl >/dev/null
python3 $T/vertex_wrap.py $W/terrain.vsh.glsl > $W/vwrap.glsl
$T/build_stage.sh $W/terrain.fsh.glsl frag $W/w_t.wgsl & $T/build_stage.sh $W/water.fsh.glsl frag $W/w_w.wgsl & $T/build_stage.sh $W/vwrap.glsl vert $W/w_v.wgsl & wait
for x in t w v; do python3 $T/wgsl_slim.py $W/w_$x.wgsl $W/slim_$x.wgsl >/dev/null; python3 $T/hzify.py $W/slim_$x.wgsl ${x}_ $W/hz_$x.wgsl; done
python3 $T/dedupe.py $W/merged.wgsl t_:$W/hz_t.wgsl w_:$W/hz_w.wgsl v_:$W/hz_v.wgsl >/dev/null
mkdir -p $W/sky $W/post; cp work_e_all/sky/sky.wgsl $W/sky/; cp -r work_e_all/post/* $W/post/
rm -rf /tmp/mt_pk; HZ_POST_DIRS="o:$PWD/work_e_world0/post,n:$PWD/work_e_world-1/post,e:$PWD/work_e_world1/post" HZ_WORK=$W HZ_SRC=$PWD/cr_euph/shaders HZ_OPTS=$PWD/opts/opts.json crport/build.sh /tmp/mt_pk >/dev/null 2>&1
cp /tmp/oldpk/LICENSE.txt /tmp/oldpk/README.md /tmp/mt_pk/
python3 tools/hzcheck.py ext/horizon /tmp/mt_pk 2>&1 | grep "material1"
