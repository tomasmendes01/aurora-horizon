import json, subprocess, glob, sys, os, tempfile
o = json.load(open('opts/opts.json'))
def fmt(v, t): return str(int(round(v))) if t in ('int', 'choice') else repr(float(v))
for x in o.values():
    if x['type'] == 'choice': x['min'], x['max'] = 0, len(x['values']) - 1
sets = {k: ','.join(f"{n}={fmt(x[k], x['type'])}" for n, x in o.items()) for k in ('default', 'min', 'max')}
files = sorted(glob.glob('/tmp/composed/*.wgsl') + glob.glob('/tmp/composed/post/*.wgsl'))
bad = 0
def run(f, s, ext):
    out = tempfile.mktemp(suffix=ext)
    r = subprocess.run(['naga', '--override', sets[s], f, out], capture_output=True, text=True)
    return f, s, ext, r.returncode, (r.stderr or r.stdout)[-600:]
from concurrent.futures import ThreadPoolExecutor
jobs = [(f, s, e) for f in files for s in sets for e in ('.spv', '.hlsl', '.metal')]
with ThreadPoolExecutor(os.cpu_count()) as ex:
    for f, s, e, rc, msg in ex.map(lambda j: run(*j), jobs):
        if rc: bad += 1; print('FAIL', os.path.basename(f), s, e, msg.strip().splitlines()[-3:])
print('jobs', len(jobs), 'failures', bad)
