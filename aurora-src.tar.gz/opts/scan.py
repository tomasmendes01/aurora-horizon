import re,pathlib,json,sys
root=pathlib.Path('cr_euph/shaders')
defs={}; ifuse={}
for p in list(root.rglob('*.glsl'))+list(root.rglob('*.fsh'))+list(root.rglob('*.vsh')):
    for l in p.read_text(errors='replace').splitlines():
        m=re.match(r'\s*#define\s+(\w+)\s+(-?[\d.]+)\s*//\s*\[([^\]]*)\]',l)
        if m: defs.setdefault(m.group(1),(m.group(2),m.group(3).split(),str(p)))
        m=re.match(r'\s*#\s*(if|elif|ifdef|ifndef)\b(.*)',l)
        if m:
            for w in re.findall(r'\w+',m.group(2)): ifuse[w]=ifuse.get(w,0)+1
props=(root/'shaders.properties').read_text()
out={}
for n,(v,vals,f) in defs.items():
    out[n]=dict(default=v,values=vals,file=f,in_if=ifuse.get(n,0),on_screen=bool(re.search(r'\b'+n+r'\b',props)))
json.dump(out,open('opts/defs.json','w'),indent=1)
ok=[n for n,d in out.items() if d['in_if']==0 and d['on_screen']]
print(len(out),'numeric', len(ok),'usable'); print(' '.join(sorted(ok)))
print('IF-USED:',' '.join(sorted(n for n,d in out.items() if d['in_if'] and d['on_screen'])))
